/**
 * Affiliate Theme — the settings page.
 *
 * A domain or email action can take up to a minute while the server talks
 * to Resend. While its form is sent, its button says so and cannot be
 * clicked again.
 *
 * The setup panel of "Your email sequences" sets up the emails in Resend
 * one step per request to admin-ajax.php, and shows each landing page's
 * progress. It starts by itself when the page says so, or when Finish
 * setting up emails is clicked. Without JavaScript, that button runs every
 * step in one request instead. The panel sends a nonce. Nothing about the
 * API key reaches this script.
 */
( function () {
	'use strict';

	function busyForms() {
		var forms = document.querySelectorAll( 'form[data-affiliate-theme-busy]' );

		Array.prototype.forEach.call( forms, function ( form ) {
			form.addEventListener( 'submit', function ( event ) {
				var button = form.querySelector( 'button[type="submit"]' );

				if ( form.dataset.sent === '1' ) {
					event.preventDefault();
					return;
				}

				form.dataset.sent = '1';

				if ( button ) {
					button.textContent = 'Working\u2026';
					button.setAttribute( 'aria-busy', 'true' );
					button.disabled = true;
				}
			} );
		} );

		// Back to this page from the result, the browser can restore it as it
		// was left, with the button still off. Turn it back on.
		window.addEventListener( 'pageshow', function ( event ) {
			if ( event.persisted ) {
				window.location.reload();
			}
		} );
	}

	function setupPanel() {
		var panel = document.getElementById( 'affiliate-theme-setup' );

		if ( ! panel ) {
			return;
		}

		var form = panel.querySelector( 'form[data-affiliate-theme-setup]' );
		var button = form ? form.querySelector( 'button[type="submit"]' ) : null;
		var status = panel.querySelector( '.affiliate-theme-setup__status' );
		var running = false;

		function say( text, isError ) {
			if ( status ) {
				status.textContent = text;
				status.style.color = isError ? '#b32d2e' : '';
				status.style.fontWeight = isError ? '600' : '';
			}
		}

		// Each row shows "Step 3 of 8" from the first reply's count.
		function progress( remaining, totals ) {
			Object.keys( totals ).forEach( function ( seq ) {
				var cell = panel.querySelector( '[data-affiliate-theme-progress="' + seq + '"]' );
				var left = remaining[ seq ] || 0;

				if ( left > totals[ seq ] ) {
					totals[ seq ] = left;
				}

				if ( cell && totals[ seq ] > 0 ) {
					cell.textContent = left === 0 ? 'Done.' : 'Step ' + ( totals[ seq ] - left + 1 ) + ' of ' + totals[ seq ] + '\u2026';
				}
			} );
		}

		// Load the page again, without settings-updated, so a reload never
		// starts another run.
		function reload() {
			var base = window.location.pathname + '?page=affiliate-theme-settings';

			if ( window.location.pathname + window.location.search === base ) {
				window.location.hash = 'affiliate-theme-sequences';
				window.location.reload();
			} else {
				window.location.assign( base + '#affiliate-theme-sequences' );
			}
		}

		function run() {
			var token = '';
			var totals = null;

			if ( running ) {
				return;
			}

			running = true;

			if ( button ) {
				button.disabled = true;
				button.setAttribute( 'aria-busy', 'true' );
			}

			say( 'Setting up your emails in Resend\u2026' );

			function stop( text ) {
				running = false;
				say( text, true );

				if ( button ) {
					button.disabled = false;
					button.removeAttribute( 'aria-busy' );
				}
			}

			function step() {
				var body = new URLSearchParams();

				body.append( 'action', 'affiliate-theme_setup_step' );
				body.append( '_ajax_nonce', panel.dataset.nonce );
				body.append( 'token', token );

				window.fetch( panel.dataset.ajax, {
					method: 'POST',
					credentials: 'same-origin',
					body: body,
				} )
					.then( function ( response ) {
						return response.json();
					} )
					.then( function ( reply ) {
						// WordPress answers -1 to a nonce that is out of date.
						if ( ! reply || typeof reply !== 'object' ) {
							stop( 'WordPress refused the request. Reload this page and try again.' );
							return;
						}

						token = reply.token || token;

						if ( reply.error ) {
							stop( reply.error );
							return;
						}

						if ( ! totals ) {
							totals = {};
							( reply.remaining || [] ).forEach( function ( left, seq ) {
								if ( seq > 0 ) {
									totals[ seq ] = left;
								}
							} );
						}

						progress( reply.remaining || [], totals );

						if ( reply.done ) {
							say( 'Done. Loading the results\u2026' );
							reload();
							return;
						}

						say( 'Setting up your emails in Resend\u2026 ' + ( reply.label ? 'Done: ' + reply.label + '.' : '' ) );
						step();
					} )
					.catch( function () {
						stop( 'The connection to WordPress dropped. Click Finish setting up emails to pick up where it stopped.' );
					} );
			}

			step();
		}

		if ( form ) {
			form.addEventListener( 'submit', function ( event ) {
				event.preventDefault();
				run();
			} );
		}

		if ( panel.dataset.autostart === '1' ) {
			run();
		}
	}

	function start() {
		busyForms();
		setupPanel();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
} )();
