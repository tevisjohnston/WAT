/**
 * Affiliate Theme — the settings page.
 *
 * The Check list button asks the theme to test the list token against
 * GetResponse. The API key never comes back from the server.
 */
( function () {
	'use strict';

	function start() {
		var button = document.getElementById( 'affiliate-theme-check-list' );
		var keyField = document.getElementById( 'affiliate-theme-gr-api-key' );
		var tokenField = document.getElementById( 'affiliate-theme-gr-token' );
		var select = document.getElementById( 'affiliate-theme-gr-list' );
		var note = document.getElementById( 'affiliate-theme-list-note' );

		if ( ! button || ! keyField || ! tokenField || ! select || ! note ) {
			return;
		}

		if ( typeof window.affiliateThemeAdmin === 'undefined' ) {
			return;
		}

		var config = window.affiliateThemeAdmin;

		function fill( ok, name, token ) {
			while ( select.options.length ) {
				select.remove( 0 );
			}

			var option = document.createElement( 'option' );

			if ( ok ) {
				option.value = token;
				option.textContent = name + ' (' + token + ')';
				option.selected = true;
				select.disabled = false;
			} else {
				option.value = '';
				option.textContent = 'No list is available';
				select.disabled = true;
			}

			select.add( option );
		}

		button.addEventListener( 'click', function () {
			var token = tokenField.value.trim();
			var key = keyField.value.trim();

			// An unchanged field still holds the mask. Send nothing, and the
			// server uses the key that it has.
			if ( key === config.mask ) {
				key = '';
			}

			button.disabled = true;
			note.textContent = 'Checking the list with GetResponse…';

			fetch( config.restUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': config.nonce
				},
				body: JSON.stringify( { api_key: key, token: token } )
			} )
				.then( function ( response ) {
					return response.json();
				} )
				.then( function ( data ) {
					fill( !! data.ok, data.name || '', data.token || token );
					note.textContent = data.message || '';
				} )
				.catch( function () {
					fill( false, '', '' );
					note.textContent = 'The check did not finish. Save the page and try again.';
				} )
				.then( function () {
					button.disabled = false;
				} );
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
} )();
