/**
 * Affiliate Theme — the opt-in form, front end.
 *
 * The form posts to the theme REST route. The route talks to GetResponse.
 * The affiliate URL arrives in the reply. It is never in the page HTML.
 */
( function () {
	'use strict';

	function status( form, message, state ) {
		var box = form.querySelector( '.affiliate-theme-optin__status' );

		if ( ! box ) {
			return;
		}

		box.textContent = message;

		if ( state ) {
			box.setAttribute( 'data-state', state );
		} else {
			box.removeAttribute( 'data-state' );
		}
	}

	function submit( event ) {
		event.preventDefault();

		var form = event.currentTarget;
		var button = form.querySelector( '.affiliate-theme-optin__button' );
		var endpoint = form.getAttribute( 'data-endpoint' );
		var nonce = form.getAttribute( 'data-nonce' );

		if ( ! endpoint || form.dataset.busy === '1' ) {
			return;
		}

		function field( name ) {
			var input = form.querySelector( '[name="' + name + '"]' );
			return input ? input.value : '';
		}

		form.dataset.busy = '1';

		if ( button ) {
			button.disabled = true;
		}

		status( form, 'One moment…' );

		var headers = { 'Content-Type': 'application/json' };

		// The route is public. The nonce helps, but the route never needs it,
		// because a page cache can hand out an old nonce.
		if ( nonce ) {
			headers['X-WP-Nonce'] = nonce;
		}

		fetch( endpoint, {
			method: 'POST',
			headers: headers,
			body: JSON.stringify( {
				email: field( 'email' ),
				name: field( 'name' ),
				website: field( 'website' )
			} )
		} )
			.then( function ( response ) {
				return response.json().then( function ( data ) {
					return { ok: response.ok, data: data };
				} );
			} )
			.then( function ( result ) {
				var data = result.data || {};

				if ( data.ok && data.redirect ) {
					status( form, data.message || 'Thank you.' );
					window.location.assign( data.redirect );
					return;
				}

				if ( data.ok ) {
					status( form, data.message || 'Thank you.' );
					form.reset();
					return;
				}

				status( form, data.message || 'Something went wrong. Please try again.', 'error' );
			} )
			.catch( function () {
				status( form, 'Service unavailable. Please try again shortly.', 'error' );
			} )
			.then( function () {
				form.dataset.busy = '0';

				if ( button ) {
					button.disabled = false;
				}
			} );
	}

	function start() {
		var forms = document.querySelectorAll( '[data-affiliate-theme-optin]' );

		Array.prototype.forEach.call( forms, function ( form ) {
			form.addEventListener( 'submit', submit );
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
} )();
