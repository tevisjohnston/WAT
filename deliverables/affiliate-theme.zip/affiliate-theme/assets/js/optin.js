/**
 * Affiliate Theme — the opt-in form, front end.
 *
 * The form posts to the theme REST route. The route talks to GetResponse.
 * The affiliate URL arrives in the reply. It is never in the page HTML.
 */
( function () {
	'use strict';

	function status( form, message, state ) {
		var box = form.querySelector( '.affiliate-theme-optin__status' );

		if ( ! box ) {
			return;
		}

		box.textContent = message;

		if ( state ) {
			box.setAttribute( 'data-state', state );
		} else {
			box.removeAttribute( 'data-state' );
		}
	}

	function submit( event ) {
		event.preventDefault();

		var form = event.currentTarget;
		var button = form.querySelector( '.affiliate-theme-optin__button' );
		var endpoint = form.getAttribute( 'data-endpoint' );

		if ( ! endpoint || form.dataset.busy === '1' ) {
			return;
		}

		var leaving = false;

		function field( name ) {
			var input = form.querySelector( '[name="' + name + '"]' );
			return input ? input.value : '';
		}

		form.dataset.busy = '1';

		if ( button ) {
			button.disabled = true;
		}

		status( form, 'One moment…' );

		// Send no X-WP-Nonce. The route is public, and WordPress answers 403 to
		// an expired nonce before the route runs, even for a visitor who is not
		// logged in. A page cache hands out old nonces.
		fetch( endpoint, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify( {
				email: field( 'email' ),
				name: field( 'name' ),
				website: field( 'website' )
			} )
		} )
			.then( function ( response ) {
				return response.json().then( function ( data ) {
					return { ok: response.ok, data: data };
				} );
			} )
			.then( function ( result ) {
				var data = result.data || {};

				if ( data.ok && data.redirect ) {
					status( form, data.message || 'Thank you.' );
					window.location.assign( data.redirect );
					leaving = true;
					return;
				}

				if ( data.ok ) {
					status( form, data.message || 'Thank you.' );
					form.reset();
					return;
				}

				status( form, data.message || 'Something went wrong. Please try again.', 'error' );
			} )
			.catch( function () {
				status( form, 'Service unavailable. Please try again shortly.', 'error' );
			} )
			.then( function () {
				// The page is on its way to the affiliate link. Keep the button
				// off, so a second click cannot send the form again.
				if ( ! leaving ) {
					release( form );
				}
			} );
	}

	function release( form ) {
		var button = form.querySelector( '.affiliate-theme-optin__button' );

		form.dataset.busy = '0';

		if ( button ) {
			button.disabled = false;
		}
	}

	function start() {
		var forms = document.querySelectorAll( '[data-affiliate-theme-optin]' );

		Array.prototype.forEach.call( forms, function ( form ) {
			form.addEventListener( 'submit', submit );
		} );

		// Back from the affiliate page, the browser can restore this page as
		// it was left, with the button still off. Turn it back on.
		window.addEventListener( 'pageshow', function ( event ) {
			if ( event.persisted ) {
				Array.prototype.forEach.call( forms, release );
			}
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}
} )();
