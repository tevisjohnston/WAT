<?php
/**
 * Affiliate Theme — DFY affiliate marketing block theme.
 */

if ( ! defined( 'AFFILIATE_THEME_VERSION' ) ) {
    define( 'AFFILIATE_THEME_VERSION', wp_get_theme()->get( 'Version' ) );
}

require_once get_template_directory() . '/inc/affiliate-theme-getresponse.php';
require_once get_template_directory() . '/inc/affiliate-theme-legal.php';
require_once get_template_directory() . '/inc/affiliate-theme-seo.php';

function Affiliate_Theme_Theme_wp_enqueue_scripts() {
    wp_enqueue_style('affiliate-theme', get_stylesheet_uri(), array(), AFFILIATE_THEME_VERSION, 'all' );

    wp_enqueue_style('affiliate-theme-styles', get_template_directory_uri() . '/assets/css/styles.css', array(), AFFILIATE_THEME_VERSION, 'all' );

}
add_action('wp_enqueue_scripts', 'Affiliate_Theme_Theme_wp_enqueue_scripts');

function Affiliate_Theme_Theme_theme_setup() {
    add_theme_support('editor-styles');

    add_editor_style('assets/css/styles.css');

    add_theme_support('automatic-feed-links');

    add_theme_support('post-thumbnails');

    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'script',
        'style',
    ));
}
add_action('after_setup_theme', 'Affiliate_Theme_Theme_theme_setup');
