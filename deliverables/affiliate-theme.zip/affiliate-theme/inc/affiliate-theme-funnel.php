<?php
/**
 * Affiliate Theme — the funnel.
 *
 * Contains the settings page, the landing patterns, the activation seeder,
 * the sign-up route and the opt-in block registration. The Resend client,
 * the API key check and the state that the theme keeps about the buyer's
 * Resend account are in inc/affiliate-theme-resend.php.
 *
 * @package affiliate-theme
 */

defined( 'ABSPATH' ) || exit;

const AFFILIATE_THEME_OPTION       = 'affiliate-theme_settings';
const AFFILIATE_THEME_SEED_FLAG    = 'affiliate-theme_pages_created';
const AFFILIATE_THEME_KEY_MASK     = '••••••••';
const AFFILIATE_THEME_REST_NS      = 'affiliate-theme/v1';
const AFFILIATE_THEME_HOLD_SECONDS = 60;
const AFFILIATE_THEME_IP_WINDOW    = 600;

/* -------------------------------------------------------------------------
 * Shared helpers
 * ---------------------------------------------------------------------- */

/**
 * Read the theme settings with the defaults applied.
 *
 * Only the keys in the defaults come back. A key that an older version
 * stored is left out, so the next save drops it from the option.
 *
 * This option holds what the settings form writes, plus the seeded page
 * IDs. What the theme learns from Resend, such as its template IDs, lives
 * in AFFILIATE_THEME_STATE instead: the sanitizer runs at every
 * update_option() of this option and copies back the old value of every
 * key that the form does not own, so a write here would be thrown away.
 *
 * @return array
 */
function Affiliate_Theme_Theme_get_settings() {
    $defaults = array(
        'resend_api_key'  => '',
        'sending_domain'  => '',
        'from_name'       => '',
        'from_local'      => 'hello',
        'reply_to'        => '',
        'mailing_address' => '',
        'redirect_url'    => '',
        'success_message' => 'Thanks! Check your inbox for the next step.',
        'page_ids'        => array(),
        'legal_page_ids'  => array(),
    );

    $settings = get_option( AFFILIATE_THEME_OPTION, array() );

    if ( ! is_array( $settings ) ) {
        $settings = array();
    }

    return array_intersect_key( wp_parse_args( $settings, $defaults ), $defaults );
}

/**
 * Tell if a URL can be the affiliate redirect.
 *
 * This checks the form of the URL only: http or https, and a host made of
 * dot-separated labels, which catches a typo such as a space. Do not
 * use wp_http_validate_url() here. It guards URLs that the server fetches,
 * so it looks the host up in DNS. A DNS fault then dropped the redirect
 * after a real sign-up, and erased a stored URL at a save that did not
 * touch it. The visitor's browser follows this URL. The server never does.
 *
 * @param string $url The URL.
 * @return bool
 */
function Affiliate_Theme_Theme_is_redirect_url( $url ) {
    if ( ! is_string( $url ) || '' === $url ) {
        return false;
    }

    $parts = wp_parse_url( $url );

    return is_array( $parts )
        && isset( $parts['scheme'], $parts['host'] )
        && in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true )
        && 1 === preg_match( '/^[a-z0-9\x80-\xff-]+(\.[a-z0-9\x80-\xff-]+)+$/i', $parts['host'] );
}

/**
 * Give the Resend API key that wp-config.php sets, or an empty string.
 *
 * A buyer who can edit wp-config.php can keep the key out of the database,
 * and so out of every copy of it:
 * define( 'AFFILIATE_THEME_RESEND_API_KEY', 're_...' );
 *
 * @return string
 */
function Affiliate_Theme_Theme_key_from_config() {
    if ( ! defined( 'AFFILIATE_THEME_RESEND_API_KEY' ) || ! is_string( AFFILIATE_THEME_RESEND_API_KEY ) ) {
        return '';
    }

    return trim( AFFILIATE_THEME_RESEND_API_KEY );
}

/**
 * Give the Resend API key that the theme uses: the one in wp-config.php
 * first, then the stored one.
 *
 * Never print it, log it or send it to the browser.
 *
 * @return string
 */
function Affiliate_Theme_Theme_resend_key() {
    $key = Affiliate_Theme_Theme_key_from_config();

    if ( '' === $key ) {
        $settings = Affiliate_Theme_Theme_get_settings();
        $key      = $settings['resend_api_key'];
    }

    return $key;
}

/**
 * Make the masked form of an API key: dots and its last four characters.
 *
 * @param string $key The API key.
 * @return string
 */
function Affiliate_Theme_Theme_mask_key( $key ) {
    if ( '' === $key ) {
        return '';
    }

    return AFFILIATE_THEME_KEY_MASK . substr( $key, -4 );
}

/**
 * Give the name that the emails go out under: the Site Title, else the
 * site's host.
 *
 * @return string
 */
function Affiliate_Theme_Theme_email_site_name() {
    $name = trim( wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES ) );

    if ( '' === $name ) {
        $name = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
    }

    return $name;
}

/**
 * Tell which landing page a post is, 1 to 3, or 0 for none.
 *
 * The seeded page IDs decide while all three are there, so a buyer who
 * renames or re-slugs a landing page keeps its emails. The seeder records
 * only the pages that it made, so with fewer than three IDs a position no
 * longer gives the number, and the slug decides instead.
 *
 * @param int $post_id The post ID.
 * @return int
 */
function Affiliate_Theme_Theme_landing_index_for_post( $post_id ) {
    $post = get_post( (int) $post_id );

    if ( ! $post instanceof WP_Post ) {
        return 0;
    }

    $settings = Affiliate_Theme_Theme_get_settings();
    $page_ids = array_values( array_map( 'intval', (array) $settings['page_ids'] ) );

    if ( 3 === count( $page_ids ) ) {
        $position = array_search( (int) $post->ID, $page_ids, true );

        if ( false !== $position ) {
            return (int) $position + 1;
        }
    }

    foreach ( Affiliate_Theme_Theme_landing_pages() as $index => $page ) {
        if ( $page['slug'] === $post->post_name ) {
            return (int) $index;
        }
    }

    return 0;
}

/**
 * Give the landing page whose emails an opt-in form starts, 1 to 3.
 *
 * The block's Sequence choice decides when it names one. "auto" takes the
 * landing page that the form is on. A form anywhere else, such as on a
 * blog post, takes the only live sequence when exactly one is live, else
 * landing page 1.
 *
 * @param mixed $attribute The block's sequence attribute: auto, 1, 2 or 3.
 * @param int   $post_id   The post that shows the form.
 * @return int
 */
function Affiliate_Theme_Theme_optin_sequence( $attribute, $post_id ) {
    if ( is_scalar( $attribute ) && in_array( (string) $attribute, array( '1', '2', '3' ), true ) ) {
        return (int) $attribute;
    }

    $index = Affiliate_Theme_Theme_landing_index_for_post( $post_id );

    if ( $index ) {
        return $index;
    }

    // In inc/affiliate-theme-resend.php.
    $live = array_values( array_filter( array_keys( Affiliate_Theme_Theme_landing_pages() ), 'Affiliate_Theme_Theme_sequence_live' ) );

    return 1 === count( $live ) ? (int) $live[0] : 1;
}

/* -------------------------------------------------------------------------
 * The settings page
 * ---------------------------------------------------------------------- */

/**
 * Register the setting and its fields.
 *
 * @return void
 */
function Affiliate_Theme_Theme_register_settings() {
    register_setting(
        'affiliate-theme_settings_group',
        AFFILIATE_THEME_OPTION,
        array(
            'type'              => 'array',
            'sanitize_callback' => 'Affiliate_Theme_Theme_sanitize_settings',
            'show_in_rest'      => false,
            'default'           => array(),
        )
    );

    // Each field: its title, the function that prints it, and its input's id.
    $sections = array(
        'affiliate-theme_section_resend' => array(
            'Resend',
            array(
                'resend_api_key' => array( 'Resend API key', 'Affiliate_Theme_Theme_field_api_key', 'affiliate-theme-resend-api-key' ),
            ),
        ),
        'affiliate-theme_section_sender' => array(
            'Sender',
            array(
                'sending_domain'  => array( 'Sending domain', 'Affiliate_Theme_Theme_field_sending_domain', 'affiliate-theme-sending-domain' ),
                'from_name'       => array( 'From name', 'Affiliate_Theme_Theme_field_from_name', 'affiliate-theme-from-name' ),
                'from_local'      => array( 'From address', 'Affiliate_Theme_Theme_field_from_local', 'affiliate-theme-from-local' ),
                'reply_to'        => array( 'Reply-to address', 'Affiliate_Theme_Theme_field_reply_to', 'affiliate-theme-reply-to' ),
                'mailing_address' => array( 'Mailing address', 'Affiliate_Theme_Theme_field_mailing_address', 'affiliate-theme-mailing-address' ),
            ),
        ),
        'affiliate-theme_section_funnel' => array(
            'Funnel',
            array(
                'redirect_url'    => array( 'Affiliate link', 'Affiliate_Theme_Theme_field_redirect_url', 'affiliate-theme-redirect-url' ),
                'success_message' => array( 'Success message', 'Affiliate_Theme_Theme_field_success_message', 'affiliate-theme-success-message' ),
            ),
        ),
    );

    foreach ( $sections as $section => $spec ) {
        // No section prints an introduction. A field has one line of help at
        // most. Step-by-step help belongs in the setup guide.
        add_settings_section( $section, $spec[0], '', 'affiliate-theme-settings' );

        foreach ( $spec[1] as $key => $field ) {
            add_settings_field(
                $key,
                $field[0],
                $field[1],
                'affiliate-theme-settings',
                $section,
                array( 'label_for' => $field[2] )
            );
        }
    }
}
add_action( 'admin_init', 'Affiliate_Theme_Theme_register_settings' );

/**
 * Clean the submitted settings.
 *
 * A value that is not usable raises a notice and keeps the stored value.
 * An emptied field takes its default. This makes no call to Resend:
 * WordPress runs it at every update_option() of the setting, sometimes
 * twice in one save. Its only write is a new cache generation, so the
 * settings page checks the key again.
 *
 * The values arrive unslashed: options.php unslashes them before it calls
 * this. Never unslash them again. A second pass strips a real backslash.
 *
 * @param mixed $input The submitted values.
 * @return array
 */
function Affiliate_Theme_Theme_sanitize_settings( $input ) {
    $old = Affiliate_Theme_Theme_get_settings();
    $new = $old;

    if ( ! is_array( $input ) ) {
        $input = array();
    }

    // A value that is not a string counts as empty, as sanitize_text_field()
    // treats it; trim() on an array is a fatal error in PHP 8.
    $text = static function ( $key ) use ( $input ) {
        return isset( $input[ $key ] ) && is_string( $input[ $key ] ) ? trim( $input[ $key ] ) : '';
    };

    // Say why a value was refused, and give back the stored one.
    $reject = static function ( $key, $message, $noun ) use ( $old ) {
        add_settings_error(
            AFFILIATE_THEME_OPTION,
            'affiliate-theme_bad_' . $key,
            $message . ' ' . ( '' === $old[ $key ] ? 'No ' . $noun . ' is saved.' : 'The theme kept the ' . $noun . ' that was there.' )
        );

        return $old[ $key ];
    };

    // The API key. The field shows a mask, never the key, so a mask or an
    // empty field keeps the stored key, safe from browser autofill and from
    // an accidental save. A key in wp-config.php wins and makes the field
    // read-only, but Remove key still clears a copy left in the database.
    if ( ! empty( $input['remove_key'] ) ) {
        $new['resend_api_key'] = '';
    } elseif ( '' === Affiliate_Theme_Theme_key_from_config() ) {
        $key = sanitize_text_field( $text( 'resend_api_key' ) );

        if ( '' !== $key && Affiliate_Theme_Theme_mask_key( $old['resend_api_key'] ) !== $key ) {
            $new['resend_api_key'] = preg_match( '/^re_[A-Za-z0-9_-]{8,124}$/', $key )
                ? $key
                : $reject( 'resend_api_key', 'That is not a Resend API key. A Resend API key starts with re_.', 'key' );
        }
    }

    // The sending domain. The field suggests the site's own domain as its
    // placeholder, which is never saved: only a domain that the buyer typed
    // is ever added to Resend.
    if ( isset( $input['sending_domain'] ) ) {
        // A pasted name can carry what nobody sees: a zero-width space or
        // a byte-order mark anywhere, a non-breaking space, quotes or
        // backticks around it, a dash that only looks like a hyphen. Each
        // made a real domain fail. A space inside the name is still refused.
        $domain = (string) preg_replace(
            array( '/\p{Cf}+/u', '/^[\p{Z}\s`"\'\x{2018}\x{2019}\x{201C}\x{201D}]+|[\p{Z}\s`"\'\x{2018}\x{2019}\x{201C}\x{201D}]+$/u', '/[\x{2010}-\x{2015}\x{2212}]/u' ),
            array( '', '', '-' ),
            $text( 'sending_domain' )
        );
        $domain = strtolower( sanitize_text_field( $domain ) );
        $domain = preg_replace( array( '~^[a-z][a-z0-9+.-]*://~', '~[/:?#].*$~', '~^www\.~', '~\.$~' ), '', $domain );

        // WordPress prints a settings error as HTML, so the name is escaped.
        $new['sending_domain'] = '' === $domain || Affiliate_Theme_Theme_is_domain( $domain )
            ? $domain
            : $reject( 'sending_domain', sprintf( 'The sending domain <code>%s</code> is not a domain name. Type it like example.com.', esc_html( $domain ) ), 'domain' );
    }

    // The From name. Quotes, angle brackets and backslashes would break the
    // From line. A name that is too long is refused rather than cut, so the
    // buyer sees it.
    if ( isset( $input['from_name'] ) ) {
        $name = sanitize_text_field( str_replace( array( '"', '<', '>', '\\' ), '', $text( 'from_name' ) ) );

        $new['from_name'] = mb_strlen( $name ) <= 20
            ? $name
            : $reject( 'from_name', 'The From name can be 20 characters at most.', 'name' );
    }

    // The part of the From address before the @. Empty goes back to hello.
    if ( isset( $input['from_local'] ) ) {
        $local = strtolower( sanitize_text_field( $text( 'from_local' ) ) );

        if ( '' === $local ) {
            $new['from_local'] = 'hello';
        } elseif ( preg_match( '/^[a-z0-9][a-z0-9._+-]{0,63}$/', $local ) ) {
            $new['from_local'] = $local;
        } else {
            $new['from_local'] = $reject( 'from_local', 'The From address can use only letters, numbers, dots, dashes, plus signs and underscores before the @, and must start with a letter or a number.', 'address' );
        }
    }

    // The Reply-to address. Empty uses the administration email address.
    if ( isset( $input['reply_to'] ) ) {
        $reply = sanitize_text_field( $text( 'reply_to' ) );

        if ( '' === $reply ) {
            $new['reply_to'] = '';
        } elseif ( is_email( $reply ) ) {
            $new['reply_to'] = sanitize_email( $reply );
        } else {
            $new['reply_to'] = $reject( 'reply_to', 'The Reply-to address is not an email address.', 'address' );
        }
    }

    // The postal address that every email shows, which CAN-SPAM requires.
    // Its line breaks stay. An address that is too long is refused rather
    // than cut, so it never loses its ZIP code unseen.
    if ( isset( $input['mailing_address'] ) ) {
        $address = str_replace( array( "\r\n", "\r" ), "\n", sanitize_textarea_field( $text( 'mailing_address' ) ) );

        $new['mailing_address'] = mb_strlen( $address ) <= 200
            ? $address
            : $reject( 'mailing_address', 'The mailing address can be 200 characters at most.', 'address' );
    }

    // The affiliate link. An empty field removes it. A URL that is
    // not usable keeps the stored one. The emails carry it in a Resend
    // template variable, which holds 2,000 characters at most.
    $raw_url = $text( 'redirect_url' );
    $url     = esc_url_raw( $raw_url );

    if ( '' !== $raw_url && ! Affiliate_Theme_Theme_is_redirect_url( $url ) ) {
        $url = $reject( 'redirect_url', 'The affiliate link is not a usable address. Start it with https://.', 'address' );
    } elseif ( mb_strlen( $url ) > 2000 ) {
        $url = $reject( 'redirect_url', 'The affiliate link can be 2,000 characters at most.', 'address' );
    }

    $new['redirect_url'] = $url;

    // The success message.
    if ( isset( $input['success_message'] ) ) {
        $new['success_message'] = sanitize_text_field( $input['success_message'] );
    }

    // Never let the form write the seeded page IDs.
    $new['page_ids']       = isset( $old['page_ids'] ) && is_array( $old['page_ids'] ) ? $old['page_ids'] : array();
    $new['legal_page_ids'] = isset( $old['legal_page_ids'] ) && is_array( $old['legal_page_ids'] ) ? $old['legal_page_ids'] : array();

    // In inc/affiliate-theme-resend.php.
    Affiliate_Theme_Theme_flush_cache();

    return $new;
}

/**
 * Print the API key field, with what Resend said about the key.
 *
 * The field never prints the key back. It shows a mask: dots and the last
 * four characters. Nothing about the key reaches JavaScript, not even the
 * mask.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_api_key() {
    $settings = Affiliate_Theme_Theme_get_settings();
    $config   = Affiliate_Theme_Theme_key_from_config();

    if ( '' !== $config ) {
        // No name, so the browser sends nothing back. The sanitizer would
        // ignore it anyway.
        printf(
            '<input type="text" id="affiliate-theme-resend-api-key" class="regular-text code" value="%s" readonly="readonly" />',
            esc_attr( Affiliate_Theme_Theme_mask_key( $config ) )
        );
        echo '<p class="description">Set in wp-config.php.</p>';
    } else {
        printf(
            '<input type="password" id="affiliate-theme-resend-api-key" class="regular-text code" name="%s[resend_api_key]" value="%s" maxlength="127" autocomplete="off" spellcheck="false" />',
            esc_attr( AFFILIATE_THEME_OPTION ),
            esc_attr( Affiliate_Theme_Theme_mask_key( $settings['resend_api_key'] ) )
        );
        printf(
            '<p class="description">%s</p>',
            '' === $settings['resend_api_key'] ? 'Use a key with Full access.' : 'Leave this as it is to keep the stored key.'
        );
    }

    if ( '' !== $settings['resend_api_key'] ) {
        printf(
            '<p><label><input type="checkbox" name="%s[remove_key]" value="1" /> %s</label></p>',
            esc_attr( AFFILIATE_THEME_OPTION ),
            '' !== $config ? 'Remove the key saved in the database' : 'Remove key'
        );
    }

    // In inc/affiliate-theme-resend.php.
    $check  = Affiliate_Theme_Theme_check_key();
    $colors = array(
        'ok'          => '#008a20',
        'unreachable' => '#996800',
    );

    if ( 'missing' !== $check['status'] ) {
        printf(
            '<p class="description"><strong style="color:%s">%s</strong></p>',
            esc_attr( isset( $colors[ $check['status'] ] ) ? $colors[ $check['status'] ] : '#b32d2e' ),
            esc_html( $check['message'] )
        );
    }
}

/**
 * Print the sending domain field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_sending_domain() {
    $settings = Affiliate_Theme_Theme_get_settings();
    $suggest  = Affiliate_Theme_Theme_domain_suggestion();

    printf(
        '<input type="text" id="affiliate-theme-sending-domain" class="regular-text code" name="%s[sending_domain]" value="%s" placeholder="%s" maxlength="253" autocomplete="off" spellcheck="false" />',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $settings['sending_domain'] ),
        esc_attr( '' !== $suggest ? $suggest : 'example.com' )
    );

    echo '<p class="description">The domain your emails come from, such as example.com.</p>';
}

/**
 * Print the From name field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_from_name() {
    $settings = Affiliate_Theme_Theme_get_settings();

    printf(
        '<input type="text" id="affiliate-theme-from-name" class="regular-text" name="%s[from_name]" value="%s" placeholder="%s" maxlength="20" />',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $settings['from_name'] ),
        esc_attr( Affiliate_Theme_Theme_email_site_name() )
    );

    echo '<p class="description">Up to 20 characters. Leave it empty to use your Site Title.</p>';
}

/**
 * Print the From address field: the part before the @, then the domain.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_from_local() {
    $settings = Affiliate_Theme_Theme_get_settings();

    printf(
        '<input type="text" id="affiliate-theme-from-local" class="code" style="width:12em" name="%s[from_local]" value="%s" maxlength="64" autocomplete="off" spellcheck="false" /> <code>%s</code>',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $settings['from_local'] ),
        esc_html( '' !== $settings['sending_domain'] ? '@' . $settings['sending_domain'] : '@ your sending domain' )
    );
}

/**
 * Print the Reply-to address field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_reply_to() {
    $settings = Affiliate_Theme_Theme_get_settings();

    printf(
        '<input type="email" id="affiliate-theme-reply-to" class="regular-text" name="%s[reply_to]" value="%s" placeholder="%s" />',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $settings['reply_to'] ),
        esc_attr( get_option( 'admin_email' ) )
    );

    echo '<p class="description">Replies go here. Leave it empty to use your administration email address.</p>';
}

/**
 * Print the mailing address field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_mailing_address() {
    $settings = Affiliate_Theme_Theme_get_settings();

    printf(
        '<textarea id="affiliate-theme-mailing-address" class="large-text" rows="3" name="%s[mailing_address]" maxlength="200" placeholder="123 Main Street, Springfield, IL 62701, USA">%s</textarea>',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_textarea( $settings['mailing_address'] )
    );

    echo '<p class="description">Every email shows it at the bottom. U.S. law requires a postal address in marketing email.</p>';
}

/**
 * Print the affiliate URL field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_redirect_url() {
    $settings = Affiliate_Theme_Theme_get_settings();

    printf(
        '<input type="url" id="affiliate-theme-redirect-url" class="regular-text" name="%s[redirect_url]" value="%s" placeholder="https://" maxlength="2000" />',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $settings['redirect_url'] )
    );

    echo '<p class="description">Leave this empty to show the success message on the page instead.</p>';
}

/**
 * Print the success message field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_success_message() {
    $settings = Affiliate_Theme_Theme_get_settings();

    printf(
        '<input type="text" id="affiliate-theme-success-message" class="large-text" name="%s[success_message]" value="%s" />',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $settings['success_message'] )
    );
}

/**
 * Add the settings page under Settings.
 *
 * @return void
 */
function Affiliate_Theme_Theme_admin_menu() {
    add_options_page(
        'Affiliate Theme Settings',
        'Affiliate Theme Settings',
        'manage_options',
        'affiliate-theme-settings',
        'Affiliate_Theme_Theme_render_settings_page'
    );
}
add_action( 'admin_menu', 'Affiliate_Theme_Theme_admin_menu' );

/**
 * Load the settings page script.
 *
 * It marks a button busy while its form is sent, and it runs the setup
 * panel of "Your email sequences". Nothing about the API key reaches
 * JavaScript, not even the mask.
 *
 * @param string $hook The current admin page.
 * @return void
 */
function Affiliate_Theme_Theme_admin_enqueue( $hook ) {
    if ( 'settings_page_affiliate-theme-settings' !== $hook ) {
        return;
    }

    wp_enqueue_script(
        'affiliate-theme-admin-settings',
        get_theme_file_uri( '/assets/js/admin-settings.js' ),
        array(),
        AFFILIATE_THEME_VERSION,
        true
    );
}
add_action( 'admin_enqueue_scripts', 'Affiliate_Theme_Theme_admin_enqueue' );

/**
 * Print the settings page.
 *
 * @return void
 */
function Affiliate_Theme_Theme_render_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $settings = Affiliate_Theme_Theme_get_settings();

    echo '<div class="wrap">';
    echo '<h1>Affiliate Theme Settings</h1>';

    // No settings_errors() here. WordPress prints the notices of every page
    // under Settings itself (wp-admin/options-head.php), so a call here
    // showed each notice twice. The theme's own notices are different:
    // WordPress knows nothing of them. In inc/affiliate-theme-resend.php.
    Affiliate_Theme_Theme_resend_render_notices();

    echo '<form action="options.php" method="post">';
    settings_fields( 'affiliate-theme_settings_group' );
    do_settings_sections( 'affiliate-theme-settings' );
    submit_button();
    echo '</form>';

    // In inc/affiliate-theme-resend.php.
    Affiliate_Theme_Theme_domain_render_section();

    // In inc/affiliate-theme-resend.php.
    Affiliate_Theme_Theme_sequences_render_section();

    if ( ! empty( $settings['page_ids'] ) ) {
        echo '<h2>Your landing pages</h2>';
        echo '<p>The theme made these pages as drafts. Publish the page that you want.</p>';
        Affiliate_Theme_Theme_render_page_list( $settings['page_ids'] );
    }

    if ( ! empty( $settings['legal_page_ids'] ) ) {
        echo '<h2>Your legal pages</h2>';
        echo '<p>The theme made these pages as drafts too. Replace every <code>[bracketed placeholder]</code> on all four pages and then publish.</p>';
        echo '<p><strong>This text is a starting template, not legal advice.</strong></p>';
        Affiliate_Theme_Theme_render_page_list( $settings['legal_page_ids'] );
    }

    // In inc/affiliate-theme-seo.php.
    Affiliate_Theme_Theme_seo_render_settings_section();

    echo '</div>';
}

/**
 * Print a list of seeded pages with their edit links and their status.
 *
 * @param array $page_ids The page IDs.
 * @return void
 */
function Affiliate_Theme_Theme_render_page_list( $page_ids ) {
    echo '<ul>';

    foreach ( (array) $page_ids as $page_id ) {
        $page = get_post( (int) $page_id );

        if ( ! $page ) {
            continue;
        }

        printf(
            '<li><a href="%s">%s</a> &mdash; %s</li>',
            esc_url( get_edit_post_link( $page->ID ) ),
            esc_html( get_the_title( $page->ID ) ),
            esc_html( $page->post_status )
        );
    }

    echo '</ul>';
}

/* -------------------------------------------------------------------------
 * The landing patterns
 *
 * One function makes the markup. The pattern files echo it and the
 * activation seeder copies it. Thus the two can never disagree.
 * ---------------------------------------------------------------------- */

/**
 * Give the list of landing pages that the theme makes.
 *
 * @return array
 */
function Affiliate_Theme_Theme_landing_pages() {
    return array(
        1 => array(
            'slug'  => 'landing-1',
            'title' => 'Landing Page — Centered',
        ),
        2 => array(
            'slug'  => 'landing-2',
            'title' => 'Landing Page — Split',
        ),
        3 => array(
            'slug'  => 'landing-3',
            'title' => 'Landing Page — Long Form',
        ),
    );
}

/**
 * Make the block markup of one landing page.
 *
 * The markup uses real values for the spacing and the colors. Pattern
 * markup is copied into post_content at activation and frozen there, so a
 * preset redefined in a later theme version could never reach it. Real
 * values cannot be invalidated that way. Theme files use presets;
 * frozen content uses real values.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return string
 */
function Affiliate_Theme_Theme_landing_pattern( $index ) {
    $form = '<!-- wp:affiliate-theme/optin-form {"lock":{"move":false,"remove":false}} /-->';

    switch ( (int) $index ) {
        case 2:
            return Affiliate_Theme_Theme_landing_pattern_split( $form );

        case 3:
            return Affiliate_Theme_Theme_landing_pattern_long( $form );

        default:
            return Affiliate_Theme_Theme_landing_pattern_centered( $form );
    }
}

/**
 * The fine print under the form in every landing pattern.
 *
 * An earnings disclaimer and an affiliate-commission disclosure, in a group
 * with a muted text color. The color is a real value, not a preset, because
 * this markup is frozen into post_content with the rest of the pattern.
 *
 * @param string $color The literal text color, chosen for the band behind it.
 * @return string
 */
function Affiliate_Theme_Theme_landing_fineprint( $color ) {
    return <<<MARKUP
<!-- wp:group {"style":{"color":{"text":"{$color}"},"spacing":{"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group has-text-color" style="color:{$color}"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">Results vary. There is no guarantee that you will earn any money. Your results depend on your own effort, skill and circumstances.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">When you buy through our links, the seller may pay us a commission. It adds nothing to what you pay.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
MARKUP;
}

/**
 * Landing page 1. A centered hero above a benefit list.
 *
 * @param string $form The opt-in form block markup.
 * @return string
 */
function Affiliate_Theme_Theme_landing_pattern_centered( $form ) {
    $fineprint = Affiliate_Theme_Theme_landing_fineprint( '#9aa3b5' );

    return <<<MARKUP
<!-- wp:group {"style":{"spacing":{"padding":{"top":"6rem","right":"1.5rem","bottom":"6rem","left":"1.5rem"}},"color":{"text":"#f5f7fb","background":"#0b1220"}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group has-text-color has-background" style="color:#f5f7fb;background-color:#0b1220;padding-top:6rem;padding-right:1.5rem;padding-bottom:6rem;padding-left:1.5rem"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.875rem"}}} -->
<p class="has-text-align-center" style="font-size:0.875rem">FREE INSTANT ACCESS</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"3rem"}}} -->
<h1 class="wp-block-heading has-text-align-center" style="font-size:3rem">The Simple System That Puts Commissions On Autopilot</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.25rem"}}} -->
<p class="has-text-align-center" style="font-size:1.25rem">Enter your best email below and I will send you the exact steps I use to promote offers and get paid — no list, no product, and no experience needed.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"templateLock":"insert","style":{"spacing":{"padding":{"top":"1rem","right":"0rem","bottom":"0rem","left":"0rem"}}},"layout":{"type":"constrained","contentSize":"420px"}} -->
<div class="wp-block-group" style="padding-top:1rem;padding-right:0rem;padding-bottom:0rem;padding-left:0rem">{$form}</div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">We respect your privacy. Unsubscribe at any time.</p>
<!-- /wp:paragraph -->

{$fineprint}</div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"4.5rem","right":"1.5rem","bottom":"4.5rem","left":"1.5rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group" style="padding-top:4.5rem;padding-right:1.5rem;padding-bottom:4.5rem;padding-left:1.5rem"><!-- wp:heading {"textAlign":"center","level":2,"style":{"typography":{"fontSize":"1.875rem"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:1.875rem">Here Is What You Get</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>The one-page plan that turns traffic into commissions.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The offers that pay the most for the least work.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The first email to send, word for word.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The mistake that costs new affiliates their first 90 days.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->
MARKUP;
}

/**
 * Landing page 2. Copy at the left, a form card at the right.
 *
 * @param string $form The opt-in form block markup.
 * @return string
 */
function Affiliate_Theme_Theme_landing_pattern_split( $form ) {
    $fineprint = Affiliate_Theme_Theme_landing_fineprint( '#5b6577' );

    return <<<MARKUP
<!-- wp:group {"style":{"spacing":{"padding":{"top":"5rem","right":"1.5rem","bottom":"5rem","left":"1.5rem"}},"color":{"text":"#111827","background":"#f4f6fb"}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group has-text-color has-background" style="color:#111827;background-color:#f4f6fb;padding-top:5rem;padding-right:1.5rem;padding-bottom:5rem;padding-left:1.5rem"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%"><!-- wp:paragraph {"style":{"typography":{"fontSize":"0.875rem"}}} -->
<p style="font-size:0.875rem">FREE 5-DAY EMAIL COURSE</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"style":{"typography":{"fontSize":"2.75rem"}}} -->
<h1 class="wp-block-heading" style="font-size:2.75rem">Get Your First Affiliate Commission In The Next 30 Days</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"1.125rem"}}} -->
<p style="font-size:1.125rem">One short email each day. Each one gives you a single step to do. By day five you have a live offer, a page that captures leads, and traffic on the way to it.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Day 1 — Pick the offer that pays.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Day 2 — Put your page up.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Day 3 — Write the email that sells.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Day 4 — Send your first traffic.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Day 5 — Do it again, and again.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:group {"templateLock":"insert","style":{"spacing":{"padding":{"top":"2.25rem","right":"2rem","bottom":"2.25rem","left":"2rem"}},"color":{"text":"#111827","background":"#ffffff"}},"layout":{"type":"constrained","contentSize":"360px"}} -->
<div class="wp-block-group has-text-color has-background" style="color:#111827;background-color:#ffffff;padding-top:2.25rem;padding-right:2rem;padding-bottom:2.25rem;padding-left:2rem"><!-- wp:heading {"textAlign":"center","level":2,"style":{"typography":{"fontSize":"1.375rem"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:1.375rem">Start Day 1 Now</h2>
<!-- /wp:heading -->

{$form}

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">No spam. Unsubscribe at any time.</p>
<!-- /wp:paragraph -->

{$fineprint}</div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
MARKUP;
}

/**
 * Landing page 3. A long sales page with the form at the top and the bottom.
 *
 * @param string $form The opt-in form block markup.
 * @return string
 */
function Affiliate_Theme_Theme_landing_pattern_long( $form ) {
    $fineprint = Affiliate_Theme_Theme_landing_fineprint( '#9aa3b5' );

    return <<<MARKUP
<!-- wp:group {"style":{"spacing":{"padding":{"top":"4.5rem","right":"1.5rem","bottom":"3rem","left":"1.5rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group" style="padding-top:4.5rem;padding-right:1.5rem;padding-bottom:3rem;padding-left:1.5rem"><!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"2.75rem"}}} -->
<h1 class="wp-block-heading has-text-align-center" style="font-size:2.75rem">Read This Before You Promote One More Offer</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.25rem"}}} -->
<p class="has-text-align-center" style="font-size:1.25rem">Most affiliates send traffic straight to a sales page, and they never see that visitor again. Here is what to do instead.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"templateLock":"insert","style":{"spacing":{"padding":{"top":"1.5rem","right":"0rem","bottom":"0rem","left":"0rem"}}},"layout":{"type":"constrained","contentSize":"420px"}} -->
<div class="wp-block-group" style="padding-top:1.5rem;padding-right:0rem;padding-bottom:0rem;padding-left:0rem">{$form}</div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","right":"1.5rem","bottom":"3rem","left":"1.5rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group" style="padding-top:3rem;padding-right:1.5rem;padding-bottom:3rem;padding-left:1.5rem"><!-- wp:heading {"level":2,"style":{"typography":{"fontSize":"1.875rem"}}} -->
<h2 class="wp-block-heading" style="font-size:1.875rem">The Traffic Is Not The Problem</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"1.0625rem"}}} -->
<p style="font-size:1.0625rem">You can buy clicks. You can post all day. But if the visitor leaves without giving you an email address, you paid for one look at your offer and nothing more.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"1.0625rem"}}} -->
<p style="font-size:1.0625rem">The affiliates who make real money keep the lead first. They send the offer second, then a third time, then a fourth. The same click is worth many times more.</p>
<!-- /wp:paragraph -->

<!-- wp:separator {"className":"is-style-wide"} -->
<hr class="wp-block-separator has-alpha-channel-opacity is-style-wide"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":2,"style":{"typography":{"fontSize":"1.875rem"}}} -->
<h2 class="wp-block-heading" style="font-size:1.875rem">What Is In The Guide</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>How to choose an offer that pays you again each month.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The page layout that turns traffic into subscribers.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The seven emails that do the selling for you.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Where to get your first 100 clicks for very little money.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>How to read your numbers, so you know what to do next.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"4.5rem","right":"1.5rem","bottom":"4.5rem","left":"1.5rem"}},"color":{"text":"#f5f7fb","background":"#0b1220"}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group has-text-color has-background" style="color:#f5f7fb;background-color:#0b1220;padding-top:4.5rem;padding-right:1.5rem;padding-bottom:4.5rem;padding-left:1.5rem"><!-- wp:heading {"textAlign":"center","level":2,"style":{"typography":{"fontSize":"2rem"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:2rem">Send Me The Guide</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.0625rem"}}} -->
<p class="has-text-align-center" style="font-size:1.0625rem">Enter your best email address. The guide arrives in the next few minutes.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"templateLock":"insert","style":{"spacing":{"padding":{"top":"1rem","right":"0rem","bottom":"0rem","left":"0rem"}}},"layout":{"type":"constrained","contentSize":"420px"}} -->
<div class="wp-block-group" style="padding-top:1rem;padding-right:0rem;padding-bottom:0rem;padding-left:0rem">{$form}</div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">We respect your privacy. Unsubscribe at any time.</p>
<!-- /wp:paragraph -->

{$fineprint}</div>
<!-- /wp:group -->
MARKUP;
}

/**
 * Add the pattern category that the pattern files use.
 *
 * @return void
 */
function Affiliate_Theme_Theme_register_pattern_category() {
    register_block_pattern_category(
        'affiliate-theme',
        array( 'label' => 'Affiliate Theme' )
    );
}
add_action( 'init', 'Affiliate_Theme_Theme_register_pattern_category', 8 );

/* -------------------------------------------------------------------------
 * The activation seeder
 * ---------------------------------------------------------------------- */

/**
 * Make one seeded page as a draft.
 *
 * Both halves of the seeder share this. An existing page at the slug is
 * taken as it is, never copied, and its content is left alone.
 *
 * @param string $slug     The page slug.
 * @param string $title    The page title.
 * @param string $content  The block markup for a page that does not exist yet.
 * @param string $template A page template to stamp, or an empty string for none.
 * @return int The page ID, or 0.
 */
function Affiliate_Theme_Theme_seed_page( $slug, $title, $content, $template = '' ) {
    $existing = get_page_by_path( $slug, OBJECT, 'page' );

    if ( $existing instanceof WP_Post ) {
        // Take the page that is there. Never make a copy of it.
        $page_id = $existing->ID;
    } else {
        $page_id = wp_insert_post(
            array(
                'post_type'    => 'page',
                'post_status'  => 'draft',
                'post_title'   => $title,
                'post_name'    => $slug,
                'post_content' => wp_slash( $content ),
            )
        );
    }

    if ( is_wp_error( $page_id ) || ! $page_id ) {
        return 0;
    }

    if ( '' !== $template ) {
        update_post_meta( $page_id, '_wp_page_template', $template );
    }

    return (int) $page_id;
}

/**
 * Make the landing pages and the legal pages one time, when the buyer
 * activates the theme.
 *
 * The routine is idempotent. The hook runs at every theme switch.
 *
 * This is the one hooked seeder. Both sets of pages share
 * AFFILIATE_THEME_SEED_FLAG, so a second hooked handler would race this
 * one: whichever ran first would set the flag and the other would return
 * early, silently seeding nothing. Affiliate_Theme_Theme_seed_legal_pages()
 * is therefore called from here and never hooked.
 *
 * @return void
 */
function Affiliate_Theme_Theme_seed_pages() {
    if ( get_option( AFFILIATE_THEME_SEED_FLAG ) ) {
        return;
    }

    $settings = Affiliate_Theme_Theme_get_settings();
    $page_ids = array();

    foreach ( Affiliate_Theme_Theme_landing_pages() as $index => $page ) {
        $page_id = Affiliate_Theme_Theme_seed_page(
            $page['slug'],
            $page['title'],
            Affiliate_Theme_Theme_landing_pattern( $index ),
            'page-blank'
        );

        if ( $page_id ) {
            $page_ids[] = $page_id;
        }
    }

    $settings['page_ids'] = $page_ids;

    // The legal pages take no page template, which leaves them on page.html.
    $settings['legal_page_ids'] = Affiliate_Theme_Theme_seed_legal_pages();

    update_option( AFFILIATE_THEME_OPTION, $settings );
    update_option( AFFILIATE_THEME_SEED_FLAG, 1 );
}
add_action( 'after_switch_theme', 'Affiliate_Theme_Theme_seed_pages' );

/* -------------------------------------------------------------------------
 * The sign-up route
 *
 * POST affiliate-theme/v1/subscribe takes one opt-in form submission and
 * sends one event to the buyer's Resend account, which starts the landing
 * page's automation. Its reply carries the affiliate URL, which is never in
 * the page. The route reads no nonce: see the warning in
 * blocks/optin-form/render.php.
 * ---------------------------------------------------------------------- */

/**
 * Register the sign-up route.
 *
 * It declares no args. The handler reads its four values itself, so none
 * of WordPress's own validation messages ever reaches a visitor.
 *
 * @return void
 */
function Affiliate_Theme_Theme_register_rest_routes() {
    register_rest_route(
        AFFILIATE_THEME_REST_NS,
        '/subscribe',
        array(
            'methods'             => 'POST',
            'callback'            => 'Affiliate_Theme_Theme_subscribe_handler',
            'permission_callback' => '__return_true',
        )
    );
}
add_action( 'rest_api_init', 'Affiliate_Theme_Theme_register_rest_routes' );

/**
 * Clean the first name that a visitor typed, for the email greeting.
 *
 * Resend escapes nothing: the name goes into the email's HTML as it is. So
 * markup, braces, & and " go. A blank name gives '', and the sign-up then
 * sends no name, so the template's fallback reads "Hi there,".
 *
 * @param string $name The name from the form.
 * @return string
 */
function Affiliate_Theme_Theme_clean_first_name( $name ) {
    $name = str_replace( array( '<', '>', '{', '}', '&', '"' ), '', sanitize_text_field( (string) $name ) );
    $name = trim( (string) preg_replace( '/\s+/', ' ', $name ) );

    return trim( mb_substr( $name, 0, 50 ) );
}

/**
 * Make the success reply, with the redirect when there is one.
 *
 * Never check the URL with wp_http_validate_url(): see
 * Affiliate_Theme_Theme_is_redirect_url().
 *
 * @param array $settings The theme settings.
 * @return WP_REST_Response
 */
function Affiliate_Theme_Theme_success_response( $settings ) {
    $payload = array(
        'ok'      => true,
        'message' => $settings['success_message'],
    );

    if ( Affiliate_Theme_Theme_is_redirect_url( $settings['redirect_url'] ) ) {
        $payload['redirect'] = $settings['redirect_url'];
    }

    return new WP_REST_Response( $payload, 200 );
}

/**
 * Make a reply that tells the visitor what went wrong.
 *
 * @param string $message The message, in plain words.
 * @param int    $status  The HTTP status.
 * @return WP_REST_Response
 */
function Affiliate_Theme_Theme_signup_error( $message, $status ) {
    return new WP_REST_Response(
        array(
            'ok'      => false,
            'message' => $message,
        ),
        $status
    );
}

/**
 * Give the transient that keeps the visitor's IP address's sign-ups.
 *
 * Only REMOTE_ADDR counts. X-Forwarded-For is never read: a visitor can
 * send any value in it, and so could reset the limit at each request. The
 * address is kept as a hash only.
 *
 * @return string
 */
function Affiliate_Theme_Theme_signup_ip_key() {
    return 'affiliate-theme_ip_' . Affiliate_Theme_Theme_signup_ip_hash();
}

/**
 * Give the hash of the visitor's IP address, REMOTE_ADDR only.
 *
 * @return string
 */
function Affiliate_Theme_Theme_signup_ip_hash() {
    $ip = isset( $_SERVER['REMOTE_ADDR'] ) && is_string( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '';

    return substr( wp_hash( $ip ), 0, 32 );
}

/**
 * Give the times of the sign-ups that Resend took, or is being asked to
 * take, from the visitor's IP address in the last
 * AFFILIATE_THEME_IP_WINDOW seconds.
 *
 * Read under the IP lock only. WordPress keeps the copy this request last
 * read or wrote for the rest of the request, so that copy is refreshed
 * first: another request may have counted one since. With an object cache
 * the copy is fetched again from it; without one it is dropped, and the
 * times come from the database.
 *
 * @return array
 */
function Affiliate_Theme_Theme_signup_ip_times() {
    $key = Affiliate_Theme_Theme_signup_ip_key();

    if ( wp_using_ext_object_cache() ) {
        wp_cache_get( $key, 'transient', true );
    } else {
        wp_cache_delete( '_transient_' . $key, 'options' );
        wp_cache_delete( '_transient_timeout_' . $key, 'options' );
    }

    $times = get_transient( $key );
    $since = time() - AFFILIATE_THEME_IP_WINDOW;

    return array_values(
        array_filter(
            is_array( $times ) ? $times : array(),
            static function ( $time ) use ( $since ) {
                return is_int( $time ) && $time > $since;
            }
        )
    );
}

/**
 * Take the lock on the visitor's IP address's sign-up times, so two
 * sign-ups from one address never read the same times and both pass.
 *
 * One INSERT IGNORE of the row affiliate-theme_ip_lock_<hash>, as
 * Affiliate_Theme_Theme_setup_lock() does (in inc/affiliate-theme-resend.php),
 * so of two requests at the same moment only one gets it. The lock is held
 * only while the times are read and written, never during the call to
 * Resend, so a request waits up to a second for it. A lock left for 5
 * seconds, by a request that died, is taken over.
 *
 * @return string The lock row's value, to let go of it, or '' when it stayed taken.
 */
function Affiliate_Theme_Theme_signup_ip_lock() {
    global $wpdb;

    $name  = 'affiliate-theme_ip_lock_' . Affiliate_Theme_Theme_signup_ip_hash();
    $value = wp_generate_password( 12, false ) . '|' . time();

    for ( $try = 0; $try < 20; $try++ ) {
        if ( $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO `$wpdb->options` ( `option_name`, `option_value`, `autoload` ) VALUES ( %s, %s, 'off' ) /* LOCK */", $name, $value ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A lock must skip the cache.
            return $value;
        }

        $held = $wpdb->get_var( $wpdb->prepare( "SELECT `option_value` FROM `$wpdb->options` WHERE `option_name` = %s", $name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A lock must skip the cache.

        if ( null !== $held ) {
            $time = array_pad( explode( '|', (string) $held, 2 ), 2, '0' );

            // Only the request whose UPDATE still finds the old row wins.
            if ( time() - (int) $time[1] > 5 && $wpdb->query( $wpdb->prepare( "UPDATE `$wpdb->options` SET `option_value` = %s WHERE `option_name` = %s AND `option_value` = %s", $value, $name, $held ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A lock must skip the cache.
                return $value;
            }
        }

        usleep( 50000 );
    }

    return '';
}

/**
 * Let go of the lock on the visitor's IP address's sign-up times.
 *
 * @param string $value From Affiliate_Theme_Theme_signup_ip_lock().
 * @return void
 */
function Affiliate_Theme_Theme_signup_ip_unlock( $value ) {
    global $wpdb;

    $wpdb->query( $wpdb->prepare( "DELETE FROM `$wpdb->options` WHERE `option_name` = %s AND `option_value` = %s", 'affiliate-theme_ip_lock_' . Affiliate_Theme_Theme_signup_ip_hash(), $value ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A lock must skip the cache.
}

/**
 * Count a sign-up from the visitor's IP address before its call to Resend,
 * so sign-ups sent at the same moment count against each other and cannot
 * all pass.
 *
 * @param int $limit The most sign-ups in the window, above 0.
 * @return int The time it was counted at, for
 *             Affiliate_Theme_Theme_signup_ip_release(), or 0 when the
 *             address is at its limit or its lock stayed taken.
 */
function Affiliate_Theme_Theme_signup_ip_reserve( $limit ) {
    $lock = Affiliate_Theme_Theme_signup_ip_lock();

    if ( '' === $lock ) {
        return 0;
    }

    $times = Affiliate_Theme_Theme_signup_ip_times();
    $time  = 0;

    if ( count( $times ) < $limit ) {
        $time    = time();
        $times[] = $time;
        set_transient( Affiliate_Theme_Theme_signup_ip_key(), $times, AFFILIATE_THEME_IP_WINDOW );
    }

    Affiliate_Theme_Theme_signup_ip_unlock( $lock );

    return $time;
}

/**
 * Give back a sign-up that Resend did not take, so only the ones it took
 * count. When the lock stays taken, it stays counted until the window ends.
 *
 * @param int $time From Affiliate_Theme_Theme_signup_ip_reserve().
 * @return void
 */
function Affiliate_Theme_Theme_signup_ip_release( $time ) {
    $lock = Affiliate_Theme_Theme_signup_ip_lock();

    if ( '' === $lock ) {
        return;
    }

    $times = Affiliate_Theme_Theme_signup_ip_times();
    $at    = array_search( $time, $times, true );

    if ( false !== $at ) {
        unset( $times[ $at ] );
    }

    if ( $times ) {
        set_transient( Affiliate_Theme_Theme_signup_ip_key(), array_values( $times ), AFFILIATE_THEME_IP_WINDOW );
    } else {
        delete_transient( Affiliate_Theme_Theme_signup_ip_key() );
    }

    Affiliate_Theme_Theme_signup_ip_unlock( $lock );
}

/**
 * Take one opt-in form submission.
 *
 * In this order: the honeypot, the email address, the landing page number,
 * the hold on this address and landing page, the limit on this IP address,
 * the live check, then the one call to Resend. Nothing before that call
 * makes one, and the call never waits or tries again.
 *
 * @param WP_REST_Request $request The request.
 * @return WP_REST_Response
 */
function Affiliate_Theme_Theme_subscribe_handler( WP_REST_Request $request ) {
    $settings = Affiliate_Theme_Theme_get_settings();
    $generic  = 'Something went wrong. Please try again.';

    // A value that is not a string counts as empty.
    $param = static function ( $name ) use ( $request ) {
        $value = $request->get_param( $name );

        return is_string( $value ) ? trim( $value ) : '';
    };

    // Step 1. The honeypot. A robot filled it. Report success and do nothing.
    if ( '' !== $param( 'website' ) ) {
        return new WP_REST_Response(
            array(
                'ok'      => true,
                'message' => $settings['success_message'],
            ),
            200
        );
    }

    // Step 2. The email address.
    $email = sanitize_email( $param( 'email' ) );

    if ( ! is_email( $email ) ) {
        return Affiliate_Theme_Theme_signup_error( 'Please enter a valid email address.', 400 );
    }

    // Step 3. The landing page whose emails the form starts. The page
    // printed it, so anything else came from somewhere else.
    $sequence = $param( 'sequence' );

    if ( ! in_array( $sequence, array( '1', '2', '3' ), true ) ) {
        return Affiliate_Theme_Theme_signup_error( $generic, 400 );
    }

    $index = (int) $sequence;

    // Step 4. The hold on this address and landing page. An address that
    // Resend took a moment ago gets the success reply again, with no second
    // call: a visitor who pressed Back and sent the form once more must
    // still reach the affiliate link, not an error. The landing page is in
    // the key, so the same address on another page still starts its emails.
    // In inc/affiliate-theme-resend.php.
    $hold_key = 'affiliate-theme_hold_' . md5( strtolower( $email ) . '|' . Affiliate_Theme_Theme_sequence_event( $index ) );
    $held     = get_transient( $hold_key );

    if ( 'accepted' === $held ) {
        return Affiliate_Theme_Theme_success_response( $settings );
    }

    if ( 'busy' === $held ) {
        return Affiliate_Theme_Theme_signup_error( 'Please try again in a moment.', 429 );
    }

    // Step 5. The limit on this IP address: 5 sign-ups in 10 minutes. It
    // stops one robot from sending the buyer's emails to a list of
    // strangers. A filter value of 0 means no limit. The sign-up counts now,
    // before the call, so sign-ups sent at the same moment cannot all pass,
    // and it is given back when Resend does not take the address.
    $limit = (int) apply_filters( 'affiliate-theme_signup_ip_limit', 5 );
    $slot  = 0;

    if ( $limit > 0 ) {
        $slot = Affiliate_Theme_Theme_signup_ip_reserve( $limit );

        if ( 0 === $slot ) {
            return Affiliate_Theme_Theme_signup_error( 'Please try again in a few minutes.', 429 );
        }
    }

    // Step 6. The live check. The form shows only while its emails are
    // live, but a cached page can still post after they were turned off.
    // An event with nothing listening would still make the contact in
    // Resend, who then gets nothing, so none is sent.
    if ( '' === Affiliate_Theme_Theme_resend_key() || ! Affiliate_Theme_Theme_sequence_live( $index ) ) {
        error_log( sprintf( 'Affiliate Theme: a visitor sent the %s form, but its emails are not live.', Affiliate_Theme_Theme_sequence_label( $index ) ) );

        if ( $slot ) {
            Affiliate_Theme_Theme_signup_ip_release( $slot );
        }

        return Affiliate_Theme_Theme_signup_error( $generic, 503 );
    }

    // Step 7. The one call.
    $reply = Affiliate_Theme_Theme_resend_request(
        'POST',
        '/events/send',
        Affiliate_Theme_Theme_body_signup( $index, $email, Affiliate_Theme_Theme_clean_first_name( $param( 'name' ) ) ),
        Affiliate_Theme_Theme_signup_idem( $index, $email )
    );

    // Map the reply. The hold is set only after Resend took the address
    // ("accepted") or itself said 429 ("busy"). Every other reply tells the
    // visitor to try again, and the retry reaches Resend again.
    //
    // A 2xx means queued, not sent, so the success copy never claims
    // delivery. A 409 is a reused Idempotency-Key with a changed payload:
    // the same visitor sent a corrected name, and the first event counts.
    if ( Affiliate_Theme_Theme_resend_ok( $reply ) || 409 === $reply['code'] ) {
        if ( 409 === $reply['code'] ) {
            Affiliate_Theme_Theme_resend_log( $reply );
        }

        set_transient( $hold_key, 'accepted', AFFILIATE_THEME_HOLD_SECONDS );

        return Affiliate_Theme_Theme_success_response( $settings );
    }

    if ( $slot ) {
        Affiliate_Theme_Theme_signup_ip_release( $slot );
    }

    // Resend's own limit: hold the address as long as Resend asks, 1 to 10
    // seconds, so the visitor can try again in a moment.
    if ( 429 === $reply['code'] ) {
        set_transient( $hold_key, 'busy', max( 1, min( 10, $reply['retry_after'] ) ) );

        return Affiliate_Theme_Theme_signup_error( 'Please try again in a moment.', 429 );
    }

    // The log line holds neither the key nor the visitor's address.
    Affiliate_Theme_Theme_resend_log( $reply );

    if ( 0 === $reply['code'] ) {
        return Affiliate_Theme_Theme_signup_error( 'Service unavailable. Please try again shortly.', 502 );
    }

    return Affiliate_Theme_Theme_signup_error( $generic, 400 );
}

/* -------------------------------------------------------------------------
 * The opt-in block
 * ---------------------------------------------------------------------- */

/**
 * Register the block scripts and then the block.
 *
 * The scripts must have their handles before register_block_type() runs,
 * because block.json names the handles.
 *
 * @return void
 */
function Affiliate_Theme_Theme_register_optin_block() {
    wp_register_script(
        'affiliate-theme-optin-editor',
        get_theme_file_uri( '/blocks/optin-form/index.js' ),
        array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ),
        AFFILIATE_THEME_VERSION,
        true
    );

    wp_register_script(
        'affiliate-theme-optin',
        get_theme_file_uri( '/assets/js/optin.js' ),
        array(),
        AFFILIATE_THEME_VERSION,
        true
    );

    register_block_type( get_theme_file_path( '/blocks/optin-form' ) );
}
add_action( 'init', 'Affiliate_Theme_Theme_register_optin_block' );
