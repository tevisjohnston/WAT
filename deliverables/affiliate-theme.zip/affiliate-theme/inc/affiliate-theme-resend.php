<?php
/**
 * Affiliate Theme — Resend.
 *
 * Contains the Resend client, the API key check, the state that the theme
 * keeps about the buyer's Resend account, every request body, the sending
 * domain (adding it to Resend, its DNS records and the "Your sending domain"
 * section), setting up the emails in Resend (the planner, the one-step
 * runner and its lock, Finish setting up emails, Turn off, Turn on and
 * Reset), the "Your email sequences" section, and the theme's own notices.
 *
 * The buyer's own Resend account does all the sending. The theme talks to
 * it with the buyer's API key, which never leaves PHP.
 *
 * @package affiliate-theme
 */

defined( 'ABSPATH' ) || exit;

const AFFILIATE_THEME_RESEND_BASE = 'https://api.resend.com';
const AFFILIATE_THEME_CACHE_GEN   = 'affiliate-theme_cache_gen';
const AFFILIATE_THEME_STATE       = 'affiliate-theme_resend';
const AFFILIATE_THEME_SETUP_LOCK  = 'affiliate-theme_setup_lock';

/* -------------------------------------------------------------------------
 * The Resend client
 * ---------------------------------------------------------------------- */

/**
 * Send one request to the Resend API.
 *
 * The API key stays in PHP. No caller sends it to the browser. WordPress
 * sends a User-Agent of its own, which Resend requires. This never waits
 * and never tries again, so the opt-in form can use it as it is. An
 * administrator's action goes through Affiliate_Theme_Theme_resend_admin_call().
 *
 * @param string     $method The HTTP method.
 * @param string     $path   The path, such as /domains.
 * @param array|null $body   The body to encode as JSON, or null.
 * @param string     $idem   An idempotency key, or ''.
 * @return array The reply: method, path, code (0 when no reply came back),
 *               body (the decoded JSON), retry_after (the seconds that
 *               Resend asks for) and error (why no reply came back, or '').
 */
function Affiliate_Theme_Theme_resend_request( $method, $path, $body = null, $idem = '' ) {
    $reply = array(
        'method'      => $method,
        'path'        => $path,
        'code'        => 0,
        'body'        => array(),
        'retry_after' => 0,
        'error'       => '',
    );

    // In inc/affiliate-theme-funnel.php.
    $api_key = Affiliate_Theme_Theme_resend_key();

    if ( '' === $api_key ) {
        $reply['error'] = 'No Resend API key is set.';
        return $reply;
    }

    $args = array(
        'method'  => $method,
        'timeout' => 15,
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        ),
    );

    if ( '' !== $idem ) {
        $args['headers']['Idempotency-Key'] = substr( $idem, 0, 256 );
    }

    if ( null !== $body ) {
        $args['body'] = wp_json_encode( $body );
    }

    $response = wp_remote_request( AFFILIATE_THEME_RESEND_BASE . $path, $args );

    if ( is_wp_error( $response ) ) {
        $reply['error'] = $response->get_error_message();
        return $reply;
    }

    $decoded = json_decode( wp_remote_retrieve_body( $response ), true );

    $reply['code']        = (int) wp_remote_retrieve_response_code( $response );
    $reply['body']        = is_array( $decoded ) ? $decoded : array();
    $reply['retry_after'] = (int) wp_remote_retrieve_header( $response, 'retry-after' );

    return $reply;
}

/**
 * Tell if a Resend reply is a success.
 *
 * @param array $reply A reply from Affiliate_Theme_Theme_resend_request().
 * @return bool
 */
function Affiliate_Theme_Theme_resend_ok( $reply ) {
    return $reply['code'] >= 200 && $reply['code'] < 300;
}

/**
 * Give what went wrong, as plain text: Resend's "name: message", or why no
 * reply came back.
 *
 * Resend answers an error with {"name": "...", "message": "..."}. This text
 * is for the error log and for administrators. Never show it to a visitor.
 *
 * @param array $reply A reply from Affiliate_Theme_Theme_resend_request().
 * @return string
 */
function Affiliate_Theme_Theme_resend_error( $reply ) {
    if ( 0 === $reply['code'] ) {
        return $reply['error'];
    }

    $body = $reply['body'];
    $text = isset( $body['message'] ) && is_string( $body['message'] ) ? $body['message'] : '';

    if ( isset( $body['name'] ) && is_string( $body['name'] ) ) {
        $text = trim( $body['name'] . ': ' . $text, ': ' );
    }

    return $text;
}

/**
 * Write a failed reply to the error log.
 *
 * The line names the request and Resend's answer, such as "Resend POST
 * /templates returned HTTP 422. validation_error: The alias is already in
 * use by another template." It never holds the API key or a visitor's
 * email address: anything that looks like either is replaced first, so
 * nothing that Resend's message repeats can put one there.
 *
 * @param array $reply A reply from Affiliate_Theme_Theme_resend_request().
 * @return void
 */
function Affiliate_Theme_Theme_resend_log( $reply ) {
    if ( 0 === $reply['code'] ) {
        $line = sprintf( 'Resend %s %s got no reply. %s', $reply['method'], $reply['path'], $reply['error'] );
    } else {
        $line = sprintf( 'Resend %s %s returned HTTP %d. %s', $reply['method'], $reply['path'], $reply['code'], Affiliate_Theme_Theme_resend_error( $reply ) );
    }

    $line = preg_replace( '/\bre_[A-Za-z0-9_-]{4,}/', 're_[key]', $line );
    $line = preg_replace( '~[^\s"\'<>(),;:/]+(?:@|%40)[^\s"\'<>(),;:/]+~i', '[email]', $line );

    error_log( trim( $line ) );
}

/**
 * Turn a failed reply into a WP_Error for an administrator, and log it.
 *
 * @param array  $reply A reply from Affiliate_Theme_Theme_resend_request().
 * @param string $doing What the theme was doing, such as "add the template".
 * @return WP_Error
 */
function Affiliate_Theme_Theme_resend_fail( $reply, $doing ) {
    Affiliate_Theme_Theme_resend_log( $reply );

    if ( 0 === $reply['code'] ) {
        $message = sprintf( 'WordPress could not reach Resend to %s: %s', $doing, $reply['error'] );
    } else {
        $message = sprintf( 'Resend did not %s (HTTP %d). %s', $doing, $reply['code'], Affiliate_Theme_Theme_resend_error( $reply ) );
    }

    return new WP_Error( 'affiliate_theme_resend', trim( $message ) );
}

/**
 * Send one request from an administrator's action, at a pace that Resend
 * accepts.
 *
 * Resend takes 10 requests a second. Each call starts at least 110 ms after
 * the one before it: 100 ms plus a margin, because one call can take a few
 * milliseconds longer than the next to reach Resend, and calls spaced at
 * exactly 100 ms can then land 10 inside one second.
 *
 * After a 429 this waits as long as Resend asks, one to three seconds, and
 * tries again, twice at most. After a fault at Resend (5xx) it waits a
 * second and tries once more, except for a POST that creates something:
 * Resend may have made it before the fault, and automation names are not
 * unique, so a second try could make a second automation. The next run
 * finds what the first try made. A request that got no reply is not tried
 * again.
 *
 * The opt-in form never waits: it uses Affiliate_Theme_Theme_resend_request().
 *
 * @param string     $method The HTTP method.
 * @param string     $path   The path.
 * @param array|null $body   The body to encode as JSON, or null.
 * @return array The reply, as Affiliate_Theme_Theme_resend_request() gives it.
 */
function Affiliate_Theme_Theme_resend_admin_call( $method, $path, $body = null ) {
    static $last = 0.0;

    $creates = 'POST' === $method && 1 === preg_match( '#^/[a-z-]+$#', $path );
    $retried = false;

    for ( $attempt = 0; $attempt < 3; $attempt++ ) {
        $wait = $last + 0.11 - microtime( true );

        if ( $wait > 0 ) {
            usleep( (int) ceil( $wait * 1000000 ) );
        }

        $last  = microtime( true );
        $reply = Affiliate_Theme_Theme_resend_request( $method, $path, $body );

        if ( 429 === $reply['code'] && $attempt < 2 ) {
            sleep( max( 1, min( 3, $reply['retry_after'] ) ) );
            continue;
        }

        if ( $reply['code'] >= 500 && ! $creates && ! $retried ) {
            $retried = true;
            sleep( 1 );
            continue;
        }

        break;
    }

    return $reply;
}

/* -------------------------------------------------------------------------
 * The API key check
 * ---------------------------------------------------------------------- */

/**
 * Check the API key against Resend.
 *
 * GET /domains needs a key with Full access, which the theme needs too: a
 * key with Sending access gets 401 restricted_api_key. The reply also
 * lists the account's domains, for the sending domain.
 *
 * The answer is kept for 10 minutes when Resend accepts the key, and for a
 * minute when it refuses it. No reply, a 429 or a fault at Resend says
 * nothing about the key, so that answer is never kept, and the next page
 * load asks again.
 *
 * @param bool $force True asks Resend past the cache.
 * @return array status (missing, ok, sending_only, invalid or unreachable),
 *               message (plain text for an administrator) and domains.
 */
function Affiliate_Theme_Theme_check_key( $force = false ) {
    $api_key = Affiliate_Theme_Theme_resend_key();
    $result  = array(
        'status'  => 'missing',
        'message' => 'No key is saved yet.',
        'domains' => array(),
    );

    if ( '' === $api_key ) {
        return $result;
    }

    // The generation number changes at every settings save, which retires
    // every cached check at once. See Affiliate_Theme_Theme_flush_cache().
    $cache_key = 'affiliate-theme_resend_key_' . md5( (int) get_option( AFFILIATE_THEME_CACHE_GEN, 0 ) . '|' . Affiliate_Theme_Theme_key_fingerprint( $api_key ) );

    if ( ! $force ) {
        $cached = get_transient( $cache_key );

        if ( is_array( $cached ) ) {
            return $cached;
        }
    }

    $reply = Affiliate_Theme_Theme_resend_request( 'GET', '/domains?limit=100' );

    if ( Affiliate_Theme_Theme_resend_ok( $reply ) ) {
        $result = array(
            'status'  => 'ok',
            'message' => 'Resend accepted this key.',
            'domains' => isset( $reply['body']['data'] ) && is_array( $reply['body']['data'] ) ? $reply['body']['data'] : array(),
        );

        set_transient( $cache_key, $result, 10 * MINUTE_IN_SECONDS );

        return $result;
    }

    Affiliate_Theme_Theme_resend_log( $reply );

    if ( 0 === $reply['code'] || 429 === $reply['code'] || $reply['code'] >= 500 ) {
        $result['status'] = 'unreachable';

        if ( 0 === $reply['code'] ) {
            $result['message'] = 'WordPress could not reach Resend. Reload this page in a minute.';
        } elseif ( 429 === $reply['code'] ) {
            $result['message'] = 'Resend is busy. Reload this page in a minute.';
        } else {
            $result['message'] = sprintf( 'Resend had a fault (HTTP %d). Reload this page in a minute.', $reply['code'] );
        }

        return $result;
    }

    if ( isset( $reply['body']['name'] ) && 'restricted_api_key' === $reply['body']['name'] ) {
        $result['status']  = 'sending_only';
        $result['message'] = 'This key can only send email. The theme needs a key with Full access.';
    } else {
        $result['status']  = 'invalid';
        $result['message'] = 'Resend did not accept this key.';
    }

    set_transient( $cache_key, $result, MINUTE_IN_SECONDS );

    return $result;
}

/**
 * Retire every cached check.
 *
 * The checks are transients. On a host with a persistent object cache, such
 * as Redis or Memcached, a transient never reaches wp_options, so a DELETE
 * there retired nothing. Every cache key carries this generation number
 * instead. A new number orphans the old entries on every kind of host, and
 * they expire on their own.
 *
 * @return void
 */
function Affiliate_Theme_Theme_flush_cache() {
    update_option( AFFILIATE_THEME_CACHE_GEN, (int) get_option( AFFILIATE_THEME_CACHE_GEN, 0 ) + 1, false );
}

/* -------------------------------------------------------------------------
 * The state
 *
 * What the theme learned from Resend. It is a separate option because the
 * settings sanitizer copies back the old value of every key that the form
 * does not own, so a write to the settings option would be thrown away.
 * ---------------------------------------------------------------------- */

/**
 * Read the state, with its defaults.
 *
 * - site_key:  8 hex characters, made once. Every name that the theme gives
 *              to an object in Resend carries it, so two sites on one
 *              Resend account never start each other's emails.
 * - key_fp:    the fingerprint of the API key that the IDs below belong to.
 * - domain:    the sending domain: id, name, status (the last one that
 *              Resend gave) and error (the last refusal, shown until the
 *              next save). See Affiliate_Theme_Theme_domain_step().
 * - sequences: per landing page, its objects in Resend.
 *
 * A new key can belong to another Resend account, where the stored IDs mean
 * nothing. So when the key changes, in the settings or in wp-config.php,
 * the state forgets every ID and keeps only the site key. The next setup
 * run finds this site's objects again by their names, or makes them.
 * Without a key, the state is left as it is.
 *
 * Before 2.0.0 was published, the fingerprint was wp_hash() of the key, which
 * changes with WordPress's salts. A state that holds that older fingerprint
 * for the same key only has it rewritten, and keeps its IDs.
 *
 * @return array
 */
function Affiliate_Theme_Theme_get_state() {
    $defaults = array(
        'site_key'  => '',
        'key_fp'    => '',
        'domain'    => array(),
        'sequences' => array(),
    );

    $state = get_option( AFFILIATE_THEME_STATE, array() );
    $state = wp_parse_args( is_array( $state ) ? $state : array(), $defaults );

    $api_key = Affiliate_Theme_Theme_resend_key();

    if ( '' !== $api_key ) {
        $fingerprint = Affiliate_Theme_Theme_key_fingerprint( $api_key );

        if ( $fingerprint !== $state['key_fp'] && hash_equals( (string) $state['key_fp'], wp_hash( $api_key ) ) ) {
            $state['key_fp'] = $fingerprint;
            Affiliate_Theme_Theme_update_state( $state );
        } elseif ( $fingerprint !== $state['key_fp'] ) {
            $state = array_merge(
                $defaults,
                array(
                    'site_key' => $state['site_key'],
                    'key_fp'   => $fingerprint,
                )
            );
            Affiliate_Theme_Theme_update_state( $state );
        }
    }

    return $state;
}

/**
 * Save the state.
 *
 * @param array $state The full state.
 * @return void
 */
function Affiliate_Theme_Theme_update_state( $state ) {
    update_option( AFFILIATE_THEME_STATE, $state );
}

/**
 * Give this site's key, and make it the first time.
 *
 * It is stored, so a move to a new address keeps it, and the objects that
 * the site made in Resend stay its own.
 *
 * @return string
 */
function Affiliate_Theme_Theme_site_key() {
    $state = Affiliate_Theme_Theme_get_state();

    if ( ! preg_match( '/^[a-f0-9]{8}$/', (string) $state['site_key'] ) ) {
        $state['site_key'] = substr( md5( home_url( '/' ) ), 0, 8 );
        Affiliate_Theme_Theme_update_state( $state );
    }

    return $state['site_key'];
}

/**
 * Give the fingerprint of an API key: a hash that tells two keys apart
 * without storing either.
 *
 * It uses no WordPress salt on purpose. A security plugin, a host or a
 * reinstall can change the salts, and a fingerprint made with them then no
 * longer matches the same key: the state forgot every ID, the forms vanished
 * and every sequence read Not set up until Finish setting up emails (wp-guide,
 * 2026-10-29). A salt adds no protection here: the key itself is stored in the
 * same database unless it is in wp-config.php, and a Resend key is too long
 * and random for its hash to be reversed or guessed.
 *
 * @param string $api_key The API key.
 * @return string
 */
function Affiliate_Theme_Theme_key_fingerprint( $api_key ) {
    return hash( 'sha256', 'affiliate-theme-key|' . $api_key );
}

/* -------------------------------------------------------------------------
 * Request bodies
 *
 * Every body that the theme sends to Resend is made here and nowhere else.
 * Resend's automation API is young and its field names have changed before,
 * so a change there is a change to this section, and the fake API and the
 * graph snapshot in the checks catch it.
 * ---------------------------------------------------------------------- */

/**
 * The body that adds a sending domain: us-east-1, open and click tracking
 * on, and the tracking subdomain `links`.
 *
 * The Privacy Policy discloses both. Click tracking sends each link through
 * Resend's redirect, which records the click and then opens the same URL, so
 * the affiliate link reaches its page unchanged (checked 2026-11-04). The
 * subdomain is set when the domain is added, so its CNAME goes in with the
 * other records before the domain verifies: added later, it makes a verified
 * domain partially verified, and a partially verified domain cannot send.
 * Resend ignores both tracking settings until a tracking subdomain is set. A tracking subdomain can be changed but
 * never removed, and it must never be `rsend`, which Resend's own record uses.
 *
 * @param string $name The domain.
 * @return array
 */
function Affiliate_Theme_Theme_body_domain( $name ) {
    return array(
        'name'               => $name,
        'region'             => 'us-east-1',
        'open_tracking'      => true,
        'click_tracking'     => true,
        'tracking_subdomain' => 'links',
    );
}

/**
 * The body that turns a domain's open and click tracking on, and sets its
 * tracking subdomain when one is given.
 *
 * Only a domain that is not verified yet is given a subdomain (see
 * Affiliate_Theme_Theme_domain_step()).
 *
 * @param string $subdomain The tracking subdomain, or '' to leave it.
 * @return array
 */
function Affiliate_Theme_Theme_body_tracking( $subdomain = '' ) {
    $body = array(
        'open_tracking'  => true,
        'click_tracking' => true,
    );

    if ( '' !== $subdomain ) {
        $body['tracking_subdomain'] = $subdomain;
    }

    return $body;
}

/**
 * The body that turns an automation on or off.
 *
 * @param bool $enabled True to turn it on.
 * @return array
 */
function Affiliate_Theme_Theme_body_status( $enabled ) {
    return array( 'status' => $enabled ? 'enabled' : 'disabled' );
}

/**
 * The body that makes a landing page's event, which a sign-up sends.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return array
 */
function Affiliate_Theme_Theme_body_event( $index ) {
    return array(
        'name'   => Affiliate_Theme_Theme_sequence_event( $index ),
        'schema' => array( 'first_name' => 'string' ),
    );
}

/**
 * The body that makes a landing page's contact property, which marks a
 * contact who has started its emails.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return array
 */
function Affiliate_Theme_Theme_body_property( $index ) {
    return array(
        'key'  => Affiliate_Theme_Theme_sequence_property( $index ),
        'type' => 'string',
    );
}

/**
 * The body that makes one email's template: its names, its copy and its
 * values.
 *
 * @param int   $index    The landing page number, 1 to 3.
 * @param int   $n        The email's number in its sequence, from 1.
 * @param array $email    One entry from Affiliate_Theme_Theme_email_sequences().
 * @param array $settings The theme settings.
 * @return array|WP_Error The body, or the fault of the renderer or of the
 *                        values.
 */
function Affiliate_Theme_Theme_body_template( $index, $n, $email, $settings ) {
    // In inc/affiliate-theme-emails.php.
    $html = Affiliate_Theme_Theme_render_email( $index, $email );

    if ( is_wp_error( $html ) ) {
        return $html;
    }

    $values = Affiliate_Theme_Theme_body_template_values( $email, $settings );

    if ( is_wp_error( $values ) ) {
        return $values;
    }

    return array_merge(
        array(
            'name'    => Affiliate_Theme_Theme_template_name( $email ),
            'alias'   => Affiliate_Theme_Theme_template_alias( $index, $n ),
            'subject' => $email['subject'],
            'html'    => $html,
        ),
        $values
    );
}

/**
 * The part of a template that holds the buyer's values: From, Reply-to and
 * the variables with their fallbacks.
 *
 * From is left out while the Sending domain field is empty. Resend takes a
 * template with no From, and a template's From is not checked against the
 * account's domains. Reply-to is the Reply-to setting, else the
 * administration email address.
 *
 * @param array $email    One entry from Affiliate_Theme_Theme_email_sequences().
 * @param array $settings The theme settings.
 * @return array|WP_Error
 */
function Affiliate_Theme_Theme_body_template_values( $email, $settings ) {
    // In inc/affiliate-theme-emails.php.
    $variables = Affiliate_Theme_Theme_email_variables( $email, $settings );

    if ( is_wp_error( $variables ) ) {
        return $variables;
    }

    $body = array();

    if ( '' !== $settings['sending_domain'] ) {
        $body['from'] = Affiliate_Theme_Theme_email_from( $settings, $settings['sending_domain'] );
    }

    $body['reply_to']  = '' !== $settings['reply_to'] ? $settings['reply_to'] : (string) get_option( 'admin_email' );
    $body['variables'] = $variables;

    return $body;
}

/**
 * Make the automation graph of one landing page.
 *
 * trigger → guard_unsub_1 → guard_seen → mark_started → email_1, then for
 * each later email delay_N → guard_unsub_N → email_N. That is 20 steps for
 * 6 emails and 17 for 5.
 *
 * - guard_unsub_N ends the run when the contact has unsubscribed. Resend
 *   skips an unsubscribed contact's email by itself too, so these only make
 *   sure.
 * - guard_seen ends the run when the contact has this page's property, so a
 *   second sign-up on the same page never starts the emails again. A
 *   sign-up on another page does start that page's emails.
 * - A guard goes on by condition_not_met. A guard that is met has nowhere
 *   to go, and the run ends.
 * - Each email names its template by ID: Resend turns an alias into the ID
 *   when it stores the graph anyway, so the graph sent and the graph stored
 *   are the same, and a template made again shows up as a changed graph.
 *   The buyer's values live on the templates. A step passes only the
 *   visitor's first name from the sign-up, and no From.
 *
 * The affiliate-theme_sequence_delay filter can replace each wait, for a
 * test with minutes in place of days.
 *
 * @param int   $index The landing page number, 1 to 3.
 * @param array $ids   Template IDs by alias. A missing one is named by alias.
 * @return array steps and connections.
 */
function Affiliate_Theme_Theme_sequence_graph( $index, $ids ) {
    $sequences = Affiliate_Theme_Theme_email_sequences();
    $property  = Affiliate_Theme_Theme_sequence_property( $index );

    $guard = static function ( $key ) {
        return array(
            'key'    => $key,
            'type'   => 'condition',
            'config' => array(
                'type'     => 'rule',
                'field'    => 'contact.unsubscribed',
                'operator' => 'eq',
                'value'    => true,
            ),
        );
    };

    $link = static function ( $from, $to, $type = 'default' ) {
        return array(
            'from' => $from,
            'to'   => $to,
            'type' => $type,
        );
    };

    $steps = array(
        array(
            'key'    => 'trigger',
            'type'   => 'trigger',
            'config' => array( 'event_name' => Affiliate_Theme_Theme_sequence_event( $index ) ),
        ),
        $guard( 'guard_unsub_1' ),
        array(
            'key'    => 'guard_seen',
            'type'   => 'condition',
            'config' => array(
                'type'     => 'rule',
                'field'    => 'contact.properties.' . $property,
                'operator' => 'exists',
            ),
        ),
        array(
            'key'    => 'mark_started',
            'type'   => 'contact_update',
            'config' => array( 'properties' => array( $property => 'started' ) ),
        ),
    );

    $connections = array(
        $link( 'trigger', 'guard_unsub_1' ),
        $link( 'guard_unsub_1', 'guard_seen', 'condition_not_met' ),
        $link( 'guard_seen', 'mark_started', 'condition_not_met' ),
    );

    $before = 'mark_started';
    $type   = 'default';

    foreach ( $sequences[ $index ] as $k => $email ) {
        $n     = $k + 1;
        $alias = Affiliate_Theme_Theme_template_alias( $index, $n );

        if ( $n > 1 ) {
            $wait = (string) apply_filters( 'affiliate-theme_sequence_delay', $email['wait'], $index, $n );

            $steps[] = array(
                'key'    => 'delay_' . $n,
                'type'   => 'delay',
                'config' => array( 'duration' => '' !== trim( $wait ) ? trim( $wait ) : $email['wait'] ),
            );
            $steps[] = $guard( 'guard_unsub_' . $n );

            $connections[] = $link( $before, 'delay_' . $n );
            $connections[] = $link( 'delay_' . $n, 'guard_unsub_' . $n );

            $before = 'guard_unsub_' . $n;
            $type   = 'condition_not_met';
        }

        $steps[] = array(
            'key'    => 'email_' . $n,
            'type'   => 'send_email',
            'config' => array(
                'template' => array(
                    'id'        => isset( $ids[ $alias ] ) ? $ids[ $alias ] : $alias,
                    'variables' => array( 'USER_FIRST_NAME' => array( 'var' => 'event.first_name' ) ),
                ),
            ),
        );

        $connections[] = $link( $before, 'email_' . $n, $type );

        $before = 'email_' . $n;
        $type   = 'default';
    }

    return array(
        'steps'       => $steps,
        'connections' => $connections,
    );
}

/**
 * The body that makes a landing page's automation. It is made off, and the
 * setup run turns it on last.
 *
 * @param int   $index The landing page number, 1 to 3.
 * @param array $graph From Affiliate_Theme_Theme_sequence_graph().
 * @return array
 */
function Affiliate_Theme_Theme_body_automation( $index, $graph ) {
    return array_merge(
        array(
            'name'   => Affiliate_Theme_Theme_sequence_name( $index ),
            'status' => 'disabled',
        ),
        $graph
    );
}

/**
 * The body of a sign-up: the landing page's event and the visitor's
 * address, which starts that page's automation.
 *
 * A blank first name is left out, so the template's fallback ("there")
 * fills the greeting. So is the whole payload then: wp_json_encode() gives
 * an empty array as [], not {}.
 *
 * @param int    $index The landing page number, 1 to 3.
 * @param string $email The visitor's address.
 * @param string $first The visitor's first name, cleaned, or ''.
 * @return array
 */
function Affiliate_Theme_Theme_body_signup( $index, $email, $first ) {
    $body = array(
        'event' => Affiliate_Theme_Theme_sequence_event( $index ),
        'email' => $email,
    );

    if ( '' !== $first ) {
        $body['payload'] = array( 'first_name' => $first );
    }

    return $body;
}

/**
 * The Idempotency-Key of a sign-up: one per address and landing page. It
 * does not stop a repeat: the same key with a changed payload was accepted
 * live (202) and started a run. The automation's re-entry guard is what
 * stops a second series.
 *
 * @param int    $index The landing page number, 1 to 3.
 * @param string $email The visitor's address.
 * @return string
 */
function Affiliate_Theme_Theme_signup_idem( $index, $email ) {
    return 'affiliate-theme-signup/' . md5( strtolower( $email ) . '|' . Affiliate_Theme_Theme_sequence_event( $index ) );
}

/* -------------------------------------------------------------------------
 * The sending domain
 * ---------------------------------------------------------------------- */

/**
 * Suggest a sending domain: the site's host without www.
 *
 * Resend puts its mail records on send.<domain>, so the root domain is the
 * right choice. It does not clash with the mail service that the buyer
 * already uses there. The settings field shows it as a placeholder only:
 * the theme adds a domain to Resend only when the buyer types it.
 *
 * @return string The domain, or '' when the host is not a real domain.
 */
function Affiliate_Theme_Theme_domain_suggestion() {
    $host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
    $host = preg_replace( '/^www\./', '', $host );

    return Affiliate_Theme_Theme_is_domain( $host ) ? $host : '';
}

/**
 * Tell if a string is a domain name that Resend can send from.
 *
 * @param string $domain The domain.
 * @return bool
 */
function Affiliate_Theme_Theme_is_domain( $domain ) {
    return is_string( $domain )
        && strlen( $domain ) <= 253
        && 1 === preg_match( '/^(?!-)[a-z0-9-]{1,63}(?<!-)(\.(?!-)[a-z0-9-]{1,63}(?<!-))*\.[a-z]{2,63}$/', $domain );
}

/**
 * Find a domain by its exact name in the key check's list.
 *
 * @param array  $domains The domains, as GET /domains lists them.
 * @param string $name    The domain name, lowercased.
 * @return array|null The domain, or null when the account does not have it.
 */
function Affiliate_Theme_Theme_domain_find( $domains, $name ) {
    foreach ( $domains as $domain ) {
        if ( isset( $domain['name'], $domain['id'] ) && is_string( $domain['name'] ) && strtolower( $domain['name'] ) === $name ) {
            return $domain;
        }
    }

    return null;
}

/**
 * Store a refusal for the domain in the field, and give its notice.
 *
 * Nothing else is stored, so the next save tries again.
 *
 * @param string $name    The domain name.
 * @param string $message The message. It may hold <strong> and <code>.
 * @return array The notice: type and message.
 */
function Affiliate_Theme_Theme_domain_refused( $name, $message ) {
    $state           = Affiliate_Theme_Theme_get_state();
    $state['domain'] = array(
        'name'  => $name,
        'error' => $message,
    );
    Affiliate_Theme_Theme_update_state( $state );

    return array(
        'type'    => 'error',
        'message' => $message,
    );
}

/**
 * Add the domain in the Sending domain field to Resend, or adopt it.
 *
 * It runs after a settings save. The save made a new cache generation, so
 * the key check's list of domains is fresh. A domain that the account
 * already has is adopted by its exact name, and nothing is made. Otherwise
 * the theme adds it, with open and click tracking on and the tracking
 * subdomain `links` (see Affiliate_Theme_Theme_body_domain()). An adopted
 * domain is read once, then has open and click tracking turned on, and gets
 * `links` only while it is not verified.
 *
 * A changed or emptied field forgets the stored domain. Nothing is ever
 * deleted in Resend.
 *
 * @return array|null The notice (type and message), or null when there is
 *                    nothing to do.
 */
function Affiliate_Theme_Theme_domain_step() {
    $settings = Affiliate_Theme_Theme_get_settings();
    $state    = Affiliate_Theme_Theme_get_state();
    $name     = $settings['sending_domain'];
    $stored   = $state['domain'];

    if ( '' === $name ) {
        if ( ! empty( $stored ) ) {
            $state['domain'] = array();
            Affiliate_Theme_Theme_update_state( $state );
        }

        if ( empty( $stored['id'] ) ) {
            return null;
        }

        return array(
            'type'    => 'info',
            'message' => sprintf( 'The theme no longer uses <strong>%s</strong>. It is still in your Resend account.', esc_html( $stored['name'] ) ),
        );
    }

    if ( isset( $stored['name'] ) && $stored['name'] === $name && ! empty( $stored['id'] ) ) {
        return null;
    }

    // Forget the old domain first, so a refusal below leaves no ID behind.
    $state['domain'] = array();
    Affiliate_Theme_Theme_update_state( $state );

    $check   = Affiliate_Theme_Theme_check_key();
    $found   = Affiliate_Theme_Theme_domain_find( $check['domains'], $name );
    $created = false;

    if ( null === $found ) {
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'POST', '/domains', Affiliate_Theme_Theme_body_domain( $name ) );

        if ( Affiliate_Theme_Theme_resend_ok( $reply ) && ! empty( $reply['body']['id'] ) ) {
            $found   = $reply['body'];
            $created = true;
        } else {
            // A create whose reply was lost, or a list that was out of
            // date, leaves the domain in the account. Look once more.
            Affiliate_Theme_Theme_flush_cache();
            $check = Affiliate_Theme_Theme_check_key( true );
            $found = Affiliate_Theme_Theme_domain_find( $check['domains'], $name );

            if ( null === $found ) {
                if ( Affiliate_Theme_Theme_resend_ok( $reply ) ) {
                    return Affiliate_Theme_Theme_domain_refused( $name, sprintf( 'Resend did not give <strong>%s</strong> an ID. Save the settings to try again.', esc_html( $name ) ) );
                }

                $error = Affiliate_Theme_Theme_resend_fail( $reply, 'add ' . $name );

                if ( 0 !== $reply['code'] && preg_match( '/\b(already|another)\b/i', Affiliate_Theme_Theme_resend_error( $reply ) ) ) {
                    return Affiliate_Theme_Theme_domain_refused( $name, sprintf( 'Resend says that <strong>%s</strong> is already in use in another Resend account. Use that account&#8217;s API key here, or a different domain.', esc_html( $name ) ) );
                }

                return Affiliate_Theme_Theme_domain_refused( $name, esc_html( $error->get_error_message() ) );
            }
        }
    }

    $subdomain = '';

    if ( ! $created ) {
        // The list item may not carry tracking_subdomain, and GET leaves it
        // out when none is set, so read the domain itself.
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'GET', '/domains/' . rawurlencode( $found['id'] ) );

        if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) || ! is_array( $reply['body'] ) ) {
            $error = Affiliate_Theme_Theme_resend_fail( $reply, 'read ' . $name );

            return Affiliate_Theme_Theme_domain_refused( $name, sprintf( 'The theme could not read <strong>%s</strong> in Resend. %s Save the settings to try again.', esc_html( $name ), esc_html( $error->get_error_message() ) ) );
        }

        $found = array_merge( $found, $reply['body'] );
        $has = isset( $found['tracking_subdomain'] ) && is_string( $found['tracking_subdomain'] ) && '' !== $found['tracking_subdomain'];

        // A verified domain is never given a subdomain: its new record
        // would be pending, which makes the domain partially verified, and
        // a partially verified domain cannot send. A domain pending only its
        // receiving record sends, so it counts as verified here too.
        if ( ! $has && 'verified' !== Affiliate_Theme_Theme_domain_send_status( $found ) ) {
            $subdomain = 'links';
        }

        if ( ( $has && ( empty( $found['open_tracking'] ) || empty( $found['click_tracking'] ) ) ) || '' !== $subdomain ) {
            $reply = Affiliate_Theme_Theme_resend_admin_call( 'PATCH', '/domains/' . rawurlencode( $found['id'] ), Affiliate_Theme_Theme_body_tracking( $subdomain ) );

            if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
                $error = Affiliate_Theme_Theme_resend_fail( $reply, 'set tracking for ' . $name );

                return Affiliate_Theme_Theme_domain_refused( $name, sprintf( 'The theme could not turn on open and click tracking for <strong>%s</strong>. %s Save the settings to try again.', esc_html( $name ), esc_html( $error->get_error_message() ) ) );
            }
        }
    }

    $state           = Affiliate_Theme_Theme_get_state();
    $state['domain'] = array(
        'id'     => (string) $found['id'],
        'name'   => $name,
        'status' => '' !== Affiliate_Theme_Theme_domain_send_status( $found ) ? Affiliate_Theme_Theme_domain_send_status( $found ) : 'not_started',
        'error'  => '',
    );
    Affiliate_Theme_Theme_update_state( $state );
    Affiliate_Theme_Theme_flush_cache();

    if ( $created ) {
        return array(
            'type'    => 'success',
            'message' => sprintf( 'The theme added <strong>%s</strong> to your Resend account. Add the DNS records below.', esc_html( $name ) ),
        );
    }

    $message = sprintf( 'The theme uses <strong>%s</strong>, which was already in your Resend account.', esc_html( $name ) );

    if ( '' !== $subdomain ) {
        $message .= sprintf( ' It added the tracking subdomain <strong>%s</strong> for open and click tracking. Add its record below.', esc_html( $subdomain . '.' . $name ) );
    }

    return array(
        'type'    => 'success',
        'message' => $message,
    );
}

/**
 * Run the domain step after a save of the settings page.
 *
 * options.php sends the browser back with settings-updated in the URL.
 * This runs before the page prints anything, so its notice shows on the
 * same load. A reload of that URL does nothing, because the stored domain
 * then matches the field. It never runs on the front end, at activation or
 * in the sanitizer.
 *
 * @return void
 */
function Affiliate_Theme_Theme_domain_after_save() {
    if ( empty( $_GET['settings-updated'] ) || ! current_user_can( 'manage_options' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only reads that a save happened.
        return;
    }

    $check = Affiliate_Theme_Theme_check_key();

    if ( 'ok' !== $check['status'] ) {
        return;
    }

    $notice = Affiliate_Theme_Theme_domain_step();

    if ( null !== $notice ) {
        Affiliate_Theme_Theme_set_notice( $notice['message'], $notice['type'] );
    }
}
add_action( 'load-settings_page_affiliate-theme-settings', 'Affiliate_Theme_Theme_domain_after_save' );

/**
 * Read the stored domain from Resend: its status and its DNS records.
 *
 * A verified domain stays verified, so it is kept for an hour. Any other
 * status is kept for a minute, so the settings page sees the change soon.
 * The stored status follows what Resend gives. A domain that is gone from
 * the account loses its stored ID and keeps its name, and the next save
 * adds it again. Other faults are not kept.
 *
 * @param bool $force True asks Resend past the cache.
 * @return array|WP_Error|null The domain, a fault, or null when none is stored.
 */
function Affiliate_Theme_Theme_domain_get( $force = false ) {
    $state = Affiliate_Theme_Theme_get_state();

    if ( empty( $state['domain']['id'] ) ) {
        return null;
    }

    $id        = $state['domain']['id'];
    $cache_key = 'affiliate-theme_resend_domain_' . md5( (int) get_option( AFFILIATE_THEME_CACHE_GEN, 0 ) . '|' . $id );

    if ( ! $force ) {
        $cached = get_transient( $cache_key );

        if ( is_array( $cached ) ) {
            return $cached;
        }
    }

    $reply = Affiliate_Theme_Theme_resend_admin_call( 'GET', '/domains/' . rawurlencode( $id ) );

    if ( 404 === $reply['code'] ) {
        Affiliate_Theme_Theme_resend_log( $reply );

        $message         = sprintf( '<strong>%s</strong> is no longer in your Resend account. Save the settings to add it again.', esc_html( $state['domain']['name'] ) );
        $state['domain'] = array(
            'name'  => $state['domain']['name'],
            'error' => $message,
        );
        Affiliate_Theme_Theme_update_state( $state );

        return new WP_Error( 'affiliate_theme_resend', $message );
    }

    if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
        return Affiliate_Theme_Theme_resend_fail( $reply, 'show your sending domain' );
    }

    $domain = $reply['body'];
    $raw    = isset( $domain['status'] ) && is_string( $domain['status'] ) ? $domain['status'] : '';
    $status = Affiliate_Theme_Theme_domain_send_status( $domain );

    // A pending receiving record is read again within a minute, so the
    // section's line about it goes once it verifies.
    set_transient( $cache_key, $domain, 'verified' === $raw ? HOUR_IN_SECONDS : MINUTE_IN_SECONDS );

    if ( '' !== $status && ( ! isset( $state['domain']['status'] ) || $status !== $state['domain']['status'] ) ) {
        $state['domain']['status'] = $status;
        Affiliate_Theme_Theme_update_state( $state );
    }

    return $domain;
}

/**
 * Give the status the theme acts on: Resend's own, except that a domain
 * Resend calls partially_verified only because its receiving record is
 * pending counts as verified.
 *
 * Turning Enable receiving on in Resend adds an MX record on the domain
 * itself, and until it verifies the domain reads partially_verified. Such a
 * domain still sends (Pro, 2026-11-05: an email sent while only the
 * Receiving MX was pending was delivered), unlike one whose Tracking record
 * is pending, which Resend refuses. Without this, the next settings load
 * would turn every sequence off and hide the forms for nothing.
 *
 * @param array $domain A domain as GET /domains/{id} gives it.
 * @return string The status, or '' when Resend gave none.
 */
function Affiliate_Theme_Theme_domain_send_status( $domain ) {
    $status = is_array( $domain ) && isset( $domain['status'] ) && is_string( $domain['status'] ) ? $domain['status'] : '';

    if ( 'partially_verified' !== $status || empty( $domain['records'] ) || ! is_array( $domain['records'] ) ) {
        return $status;
    }

    $receiving = false;

    foreach ( $domain['records'] as $record ) {
        if ( ! is_array( $record ) ) {
            return $status;
        }

        $verified = isset( $record['status'] ) && 'verified' === $record['status'];

        if ( isset( $record['record'] ) && 'Receiving' === $record['record'] ) {
            $receiving = $receiving || ! $verified;
            continue;
        }

        if ( ! $verified ) {
            return $status;
        }
    }

    return $receiving ? 'verified' : $status;
}

/**
 * Tell if the domain is partially verified only because its receiving
 * record is pending.
 *
 * @param array $domain A domain as GET /domains/{id} gives it.
 * @return bool
 */
function Affiliate_Theme_Theme_domain_receiving_pending( $domain ) {
    return is_array( $domain ) && isset( $domain['status'] ) && 'partially_verified' === $domain['status']
        && 'verified' === Affiliate_Theme_Theme_domain_send_status( $domain );
}

/**
 * Tell if the stored domain can send: verified, or pending only its
 * receiving record.
 *
 * @param bool $force True asks Resend past the cache.
 * @return bool
 */
function Affiliate_Theme_Theme_domain_verified( $force = false ) {
    $domain = Affiliate_Theme_Theme_domain_get( $force );

    return is_array( $domain ) && 'verified' === Affiliate_Theme_Theme_domain_send_status( $domain );
}

/**
 * Read the stored domain past the cache, and when it is not verified, ask
 * Resend to check its DNS records and read it again.
 *
 * Resend checks a new domain's records by itself, so the page can show a
 * status that is a minute old and offer Check for a domain that is already
 * verified. Each verify starts a new check, which puts a verified domain's
 * records back to pending until it ends, about five minutes on 2026-10-20.
 * So a verified domain is never sent to verify. Resend runs the check after
 * the call returns, so the read after it usually gives pending.
 *
 * @return array|null The notice (type and message), or null when no domain
 *                    is stored.
 */
function Affiliate_Theme_Theme_domain_check() {
    $state = Affiliate_Theme_Theme_get_state();

    if ( empty( $state['domain']['id'] ) ) {
        return null;
    }

    $name   = $state['domain']['name'];
    $domain = Affiliate_Theme_Theme_domain_get( true );

    // A domain pending only its receiving record is not verified either: a
    // verify would put its sending records back to pending too, and Resend
    // checks the new MX by itself.
    if ( ! is_wp_error( $domain ) && 'verified' !== Affiliate_Theme_Theme_domain_send_status( $domain ) ) {
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'POST', '/domains/' . rawurlencode( $state['domain']['id'] ) . '/verify' );

        if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) && 404 !== $reply['code'] ) {
            return array(
                'type'    => 'error',
                'message' => esc_html( Affiliate_Theme_Theme_resend_fail( $reply, 'check the DNS records' )->get_error_message() ),
            );
        }

        // A 404 above is handled here: the read finds the domain gone.
        $domain = Affiliate_Theme_Theme_domain_get( true );
    }

    if ( is_wp_error( $domain ) ) {
        return array(
            'type'    => 'error',
            'message' => wp_kses( $domain->get_error_message(), array( 'strong' => array() ) ),
        );
    }

    if ( 'verified' === Affiliate_Theme_Theme_domain_send_status( $domain ) ) {
        return array(
            'type'    => 'success',
            'message' => Affiliate_Theme_Theme_domain_receiving_pending( $domain )
                ? sprintf( '<strong>%s</strong> is verified for sending. Resend is still checking its receiving (MX) record.', esc_html( $name ) )
                : sprintf( '<strong>%s</strong> is verified.', esc_html( $name ) ),
        );
    }

    return array(
        'type'    => 'info',
        'message' => 'Resend is checking your DNS records. That takes from a few minutes to a few hours after you add them. Click <strong>Check</strong> again later.',
    );
}

/**
 * Handle the Check button of "Your sending domain".
 *
 * @return void
 */
function Affiliate_Theme_Theme_domain_check_handler() {
    Affiliate_Theme_Theme_check_action( 'affiliate-theme_domain_check' );

    $notice = Affiliate_Theme_Theme_domain_check();

    if ( null !== $notice ) {
        Affiliate_Theme_Theme_set_notice( $notice['message'], $notice['type'] );
    }

    Affiliate_Theme_Theme_back_to_settings( 'affiliate-theme-domain' );
}
add_action( 'admin_post_affiliate-theme_domain_check', 'Affiliate_Theme_Theme_domain_check_handler' );

/**
 * Find the DNS zone of a domain from its DKIM record.
 *
 * Resend gives each record's name relative to the zone where the buyer
 * adds it: resend._domainkey.mail for mail.example.com means the zone is
 * example.com. With no label after
 * _domainkey, the zone is the domain itself. This needs no list of public
 * suffixes, so example.co.uk works.
 *
 * @param string $domain  The domain name.
 * @param array  $records The domain's records, as Resend gives them.
 * @return string The zone, or '' when there is no DKIM record.
 */
function Affiliate_Theme_Theme_domain_zone( $domain, $records ) {
    foreach ( $records as $record ) {
        if ( ! isset( $record['record'], $record['name'] ) || 'DKIM' !== $record['record'] || ! is_string( $record['name'] ) ) {
            continue;
        }

        if ( ! preg_match( '/^[^.]+\._domainkey(?:\.(.+))?$/i', strtolower( $record['name'] ), $match ) || empty( $match[1] ) ) {
            return $domain;
        }

        $prefix = $match[1] . '.';

        return 0 === strpos( $domain, $prefix ) && strlen( $domain ) > strlen( $prefix ) ? substr( $domain, strlen( $prefix ) ) : $domain;
    }

    return '';
}

/**
 * Give a record's full host name: its name with the zone after it.
 *
 * @param string $record_name The name, as Resend gives it.
 * @param string $zone        The zone, from Affiliate_Theme_Theme_domain_zone().
 * @return string The full name, or '' when the zone is not known.
 */
function Affiliate_Theme_Theme_domain_host( $record_name, $zone ) {
    if ( '' === $zone ) {
        return '';
    }

    $record_name = rtrim( strtolower( trim( (string) $record_name ) ), '.' );

    if ( '' === $record_name || '@' === $record_name ) {
        return $zone;
    }

    if ( $record_name === $zone || str_ends_with( $record_name, '.' . $zone ) ) {
        return $record_name;
    }

    return $record_name . '.' . $zone;
}

/**
 * Print the "Your sending domain" section of the settings page.
 *
 * The records of a domain that is not verified are shown in a table, to
 * copy into the buyer's DNS. Receiving records are left out: an inbound MX
 * record on the buyer's domain can take over their own mail.
 *
 * @return void
 */
function Affiliate_Theme_Theme_domain_render_section() {
    $settings = Affiliate_Theme_Theme_get_settings();
    $name     = $settings['sending_domain'];

    echo '<h2 id="affiliate-theme-domain">Your sending domain</h2>';

    $check = Affiliate_Theme_Theme_check_key();

    if ( 'ok' !== $check['status'] ) {
        echo '<p>Save a Resend API key with Full access first.</p>';
        return;
    }

    if ( '' === $name ) {
        echo '<p>Type your sending domain above and save.</p>';
        return;
    }

    $state  = Affiliate_Theme_Theme_get_state();
    $stored = $state['domain'];
    $html   = array(
        'strong' => array(),
        'code'   => array(),
    );

    if ( ! empty( $stored['error'] ) ) {
        printf( '<div class="notice notice-error inline"><p>%s</p></div>', wp_kses( $stored['error'], $html ) );
        return;
    }

    if ( empty( $stored['id'] ) || ! isset( $stored['name'] ) || $stored['name'] !== $name ) {
        printf( '<p>Save the settings to add <strong>%s</strong> to Resend.</p>', esc_html( $name ) );
        return;
    }

    $domain = Affiliate_Theme_Theme_domain_get();

    if ( is_wp_error( $domain ) ) {
        printf( '<div class="notice notice-error inline"><p>%s</p></div>', wp_kses( $domain->get_error_message(), $html ) );
        return;
    }

    $status = Affiliate_Theme_Theme_domain_send_status( $domain );
    $lines  = array(
        'verified'           => array( '#008a20', '%s is verified.' ),
        'not_started'        => array( '', '%s is waiting for its DNS records.' ),
        'pending'            => array( '', 'Resend is checking the DNS records of %s.' ),
        'failed'             => array( '#b32d2e', 'Resend could not find every DNS record of %s.' ),
        'partially_verified' => array( '#996800', 'Some DNS records of %s are not verified yet, and Resend cannot send from it until they are.' ),
        'temporary_failure'  => array( '#996800', 'Resend lost track of a DNS record of %s.' ),
    );
    $line   = isset( $lines[ $status ] )
        ? array( $lines[ $status ][0], sprintf( $lines[ $status ][1], $name ) )
        : array( '', sprintf( 'Resend gives %s the status %s.', $name, str_replace( '_', ' ', $status ) ) );

    printf(
        '<p><strong%s>%s</strong></p>',
        '' !== $line[0] ? ' style="color:' . esc_attr( $line[0] ) . '"' : '',
        esc_html( $line[1] )
    );

    if ( Affiliate_Theme_Theme_domain_receiving_pending( $domain ) ) {
        echo '<p>Resend is still checking the receiving (MX) record you turned on. Your emails send meanwhile.</p>';
    }

    // In inc/affiliate-theme-emails.php.
    printf( '<p>Your emails come from <code>%s</code>.</p>', esc_html( Affiliate_Theme_Theme_email_from( $settings, $name ) ) );

    if ( 'verified' === $status ) {
        $open_off  = empty( $domain['open_tracking'] );
        $click_off = empty( $domain['click_tracking'] );

        if ( $open_off && $click_off ) {
            echo '<p><strong>Open and click tracking are off for this domain.</strong> Your Privacy Policy says your emails use them. Turn them on in Resend, under the domain&#8217;s Configuration.</p>';
        } elseif ( $open_off || $click_off ) {
            printf(
                '<p><strong>%s tracking is off for this domain.</strong> Your Privacy Policy says your emails use it. Turn it on in Resend, under the domain&#8217;s Configuration.</p>',
                $open_off ? 'Open' : 'Click'
            );
        }
    }

    $link = sprintf(
        '<a href="%s" target="_blank" rel="noopener">Open %s in Resend</a>',
        esc_url( 'https://resend.com/domains/' . rawurlencode( $stored['id'] ) ),
        esc_html( $name )
    );

    if ( 'verified' === $status ) {
        printf( '<p>%s</p>', $link ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
        return;
    }

    printf(
        '<p>Add these records where you manage your domain&#8217;s DNS, then click <strong>Check</strong>. Resend may offer to add these DNS records for you: <strong>%s</strong>. Add them manually if auto-configure is unavailable.</p>',
        $link // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
    );

    $records = isset( $domain['records'] ) && is_array( $domain['records'] ) ? $domain['records'] : array();
    $zone    = Affiliate_Theme_Theme_domain_zone( $name, $records );
    $input   = '<input type="text" class="code" readonly="readonly" value="%s" onfocus="this.select()" style="width:100%%" />';

    echo '<table class="widefat striped" style="max-width:72rem"><thead><tr><th scope="col">Type</th><th scope="col">Name</th><th scope="col">Full host name</th><th scope="col">Value</th><th scope="col">Priority</th><th scope="col">Status</th></tr></thead><tbody>';

    foreach ( $records as $record ) {
        if ( ! is_array( $record ) || ( isset( $record['record'] ) && 'Receiving' === $record['record'] ) ) {
            continue;
        }

        $record_name = isset( $record['name'] ) && is_string( $record['name'] ) ? $record['name'] : '';
        $host        = Affiliate_Theme_Theme_domain_host( $record_name, $zone );

        printf(
            '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>',
            esc_html( isset( $record['type'] ) ? (string) $record['type'] : '' ),
            sprintf( $input, esc_attr( $record_name ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped here.
            '' !== $host ? sprintf( $input, esc_attr( $host ) ) : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped here.
            sprintf( $input, esc_attr( isset( $record['value'] ) ? (string) $record['value'] : '' ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped here.
            esc_html( isset( $record['priority'] ) ? (string) $record['priority'] : '' ),
            esc_html( isset( $record['status'] ) ? str_replace( '_', ' ', (string) $record['status'] ) : '' )
        );
    }

    echo '</tbody></table><p></p>';

    Affiliate_Theme_Theme_action_form( 'affiliate-theme_domain_check', 'Check', array(), true );
}

/* -------------------------------------------------------------------------
 * The email sequences: names, state and hashes
 * ---------------------------------------------------------------------- */

/**
 * Give a landing page's short name, as the settings page shows it.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return string
 */
function Affiliate_Theme_Theme_sequence_label( $index ) {
    $labels = array(
        1 => 'Centered',
        2 => 'Split',
        3 => 'Long Form',
    );

    return isset( $labels[ (int) $index ] ) ? $labels[ (int) $index ] : '';
}

/**
 * Give the name of a landing page's event: affiliate-theme.<site key>.landing-N.
 *
 * A sign-up sends it, and it starts the automation. The opt-in form uses it.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return string
 */
function Affiliate_Theme_Theme_sequence_event( $index ) {
    return 'affiliate-theme.' . Affiliate_Theme_Theme_site_key() . '.landing-' . (int) $index;
}

/**
 * Give the key of a landing page's contact property: at_<site key>_lN.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return string
 */
function Affiliate_Theme_Theme_sequence_property( $index ) {
    return 'at_' . Affiliate_Theme_Theme_site_key() . '_l' . (int) $index;
}

/**
 * Give the name of a landing page's automation. Resend lets two automations
 * share a name, so the theme finds its own by stored ID first.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return string
 */
function Affiliate_Theme_Theme_sequence_name( $index ) {
    return 'Affiliate Theme ' . Affiliate_Theme_Theme_site_key() . ' - Landing Page - ' . Affiliate_Theme_Theme_sequence_label( $index );
}

/**
 * Give the alias of an email's template: affiliate-theme-<site key>-lN-NN,
 * 30 characters. Resend takes 50.
 *
 * @param int $index The landing page number, 1 to 3.
 * @param int $n     The email's number in its sequence, from 1.
 * @return string
 */
function Affiliate_Theme_Theme_template_alias( $index, $n ) {
    return sprintf( 'affiliate-theme-%s-l%d-%02d', Affiliate_Theme_Theme_site_key(), (int) $index, (int) $n );
}

/**
 * Give the name of an email's template: Affiliate Theme <site key> - <name>.
 *
 * @param array $email One entry from Affiliate_Theme_Theme_email_sequences().
 * @return string
 */
function Affiliate_Theme_Theme_template_name( $email ) {
    return 'Affiliate Theme ' . Affiliate_Theme_Theme_site_key() . ' - ' . $email['name'];
}

/**
 * Read one landing page's part of the state, with its defaults.
 *
 * - event_id, property_id: their IDs in Resend.
 * - templates:     by alias: id, published, values_hash (the values last
 *                  sent, or '' when unknown), copy_hash (the copy last
 *                  sent, or null when unknown) and pending (the values_hash
 *                  of a PATCH that is not published yet).
 * - automation_id: its ID, graph_hash (the graph last sent or read) and
 *                  enabled (what Resend last said).
 * - off, off_by:   turned off by the buyer, on this page (theme) or in
 *                  Resend (resend). A sequence that is off is never turned
 *                  on by a setup run.
 * - error:         run (the run that met it) and message (escaped HTML).
 * - draft:         the aliases whose values the last run did not update,
 *                  because the template has an edit in Resend that is not
 *                  published.
 *
 * @param array $state The state.
 * @param int   $index The landing page number, 1 to 3.
 * @return array
 */
function Affiliate_Theme_Theme_get_sequence( $state, $index ) {
    $seq = isset( $state['sequences'][ $index ] ) && is_array( $state['sequences'][ $index ] ) ? $state['sequences'][ $index ] : array();

    return wp_parse_args(
        $seq,
        array(
            'event_id'      => '',
            'property_id'   => '',
            'templates'     => array(),
            'automation_id' => '',
            'graph_hash'    => '',
            'enabled'       => false,
            'off'           => false,
            'off_by'        => '',
            'error'         => array(),
            'draft'         => array(),
        )
    );
}

/**
 * Save one landing page's part of the state.
 *
 * @param int   $index The landing page number, 1 to 3.
 * @param array $seq   Its part, from Affiliate_Theme_Theme_get_sequence().
 * @return void
 */
function Affiliate_Theme_Theme_save_sequence( $index, $seq ) {
    $state                         = Affiliate_Theme_Theme_get_state();
    $state['sequences'][ $index ] = $seq;
    Affiliate_Theme_Theme_update_state( $state );
}

/**
 * Give the template IDs of a landing page, by alias.
 *
 * @param array $seq Its part of the state.
 * @return array
 */
function Affiliate_Theme_Theme_sequence_ids( $seq ) {
    $ids = array();

    foreach ( $seq['templates'] as $alias => $template ) {
        if ( ! empty( $template['id'] ) ) {
            $ids[ $alias ] = $template['id'];
        }
    }

    return $ids;
}

/**
 * Forget a landing page's automation, which is no longer in Resend.
 *
 * @param array $seq Its part of the state.
 * @return array
 */
function Affiliate_Theme_Theme_sequence_forget_automation( $seq ) {
    $seq['automation_id'] = '';
    $seq['graph_hash']    = '';
    $seq['enabled']       = false;

    return $seq;
}

/**
 * Bring a landing page's automation into line with what Resend lists.
 *
 * A stored automation that is gone is forgotten. Resend showing it off
 * while the state says on means someone turned it off in Resend, since a
 * run of the theme stores its own changes: it is then off, and no run turns
 * it on again. Resend showing it on while it is off here means the buyer
 * turned it on there, so it is no longer off.
 *
 * @param array      $seq  Its part of the state.
 * @param array|null $item The automation as GET /automations lists it, or
 *                         null when it is not in the list.
 * @return array
 */
function Affiliate_Theme_Theme_sequence_reconcile( $seq, $item ) {
    if ( null === $item ) {
        return Affiliate_Theme_Theme_sequence_forget_automation( $seq );
    }

    $enabled = isset( $item['status'] ) && 'enabled' === $item['status'];

    if ( $seq['enabled'] && ! $enabled ) {
        $seq['off']    = true;
        $seq['off_by'] = 'resend';
    } elseif ( $enabled && $seq['off'] ) {
        $seq['off']    = false;
        $seq['off_by'] = '';
    }

    $seq['enabled'] = $enabled;

    return $seq;
}

/**
 * Sort an array's keys at every level and drop its null values, so that
 * two copies of one structure hash the same however Resend orders them.
 *
 * @param mixed $value The value.
 * @return mixed
 */
function Affiliate_Theme_Theme_hash_sort( $value ) {
    if ( ! is_array( $value ) ) {
        return $value;
    }

    $out = array();

    foreach ( $value as $key => $item ) {
        if ( null !== $item ) {
            $out[ $key ] = Affiliate_Theme_Theme_hash_sort( $item );
        }
    }

    ksort( $out );

    return $out;
}

/**
 * Hash a template's values: From, Reply-to and each variable's key, type
 * and fallback.
 *
 * It takes them as the theme sends them and as GET /templates/{id} gives
 * them back, Reply-to as a list, so the two can be compared.
 *
 * @param mixed $from      The From line, or null.
 * @param mixed $reply_to  An address, a list of them, or null.
 * @param mixed $variables The variables.
 * @return string
 */
function Affiliate_Theme_Theme_values_hash( $from, $reply_to, $variables ) {
    $list = array();

    foreach ( (array) $variables as $variable ) {
        if ( ! is_array( $variable ) || ! isset( $variable['key'] ) ) {
            continue;
        }

        $fallback = isset( $variable['fallback_value'] ) ? (string) $variable['fallback_value'] : '';

        $list[ (string) $variable['key'] ] = array(
            'type'     => isset( $variable['type'] ) ? (string) $variable['type'] : 'string',
            'fallback' => '' !== $fallback ? $fallback : null,
        );
    }

    ksort( $list );

    $replies = array_values( array_filter( array_map( 'strval', (array) $reply_to ) ) );
    sort( $replies );

    return md5(
        wp_json_encode(
            array(
                'from'      => (string) $from,
                'reply_to'  => $replies,
                'variables' => $list,
            )
        )
    );
}

/**
 * Hash the values that the settings give one email's template.
 *
 * @param array $email    One entry from Affiliate_Theme_Theme_email_sequences().
 * @param array $settings The theme settings.
 * @return string|null The hash, or null when the values have a fault.
 */
function Affiliate_Theme_Theme_template_values_hash( $email, $settings ) {
    $body = Affiliate_Theme_Theme_body_template_values( $email, $settings );

    if ( is_wp_error( $body ) ) {
        return null;
    }

    return Affiliate_Theme_Theme_values_hash( isset( $body['from'] ) ? $body['from'] : '', $body['reply_to'], $body['variables'] );
}

/**
 * Give a delay's length in seconds, so "7 days" and "1 week" are the same.
 *
 * Resend stores a delay in its own words: it gave "7 days" back as "1 week"
 * (2026-10-21), and kept "1 day" and "6 days" as they were sent.
 *
 * @param string $duration The delay, such as "7 days".
 * @return int|string The seconds, or the text as it was when it is not
 *                    a number and a unit.
 */
function Affiliate_Theme_Theme_duration_seconds( $duration ) {
    $units = array(
        'minute' => MINUTE_IN_SECONDS,
        'hour'   => HOUR_IN_SECONDS,
        'day'    => DAY_IN_SECONDS,
        'week'   => WEEK_IN_SECONDS,
    );

    if ( is_string( $duration ) && preg_match( '/^\s*(\d+)\s*(minute|hour|day|week)s?\s*$/i', $duration, $match ) ) {
        return (int) $match[1] * $units[ strtolower( $match[2] ) ];
    }

    return $duration;
}

/**
 * Hash an automation graph: each step's key, type and config, and each
 * connection. It takes the graph as the theme sends it and as
 * GET /automations/{id} gives it back, with each delay in seconds.
 *
 * @param array $graph steps and connections.
 * @return string
 */
function Affiliate_Theme_Theme_graph_hash( $graph ) {
    $steps       = array();
    $connections = array();

    foreach ( isset( $graph['steps'] ) ? (array) $graph['steps'] : array() as $step ) {
        if ( is_array( $step ) && isset( $step['key'] ) ) {
            if ( isset( $step['type'], $step['config']['duration'] ) && 'delay' === $step['type'] ) {
                $step['config']['duration'] = Affiliate_Theme_Theme_duration_seconds( $step['config']['duration'] );
            }

            $steps[ (string) $step['key'] ] = array(
                'type'   => isset( $step['type'] ) ? (string) $step['type'] : '',
                'config' => Affiliate_Theme_Theme_hash_sort( isset( $step['config'] ) ? $step['config'] : array() ),
            );
        }
    }

    foreach ( isset( $graph['connections'] ) ? (array) $graph['connections'] : array() as $connection ) {
        if ( is_array( $connection ) && isset( $connection['from'], $connection['to'] ) ) {
            $connections[] = $connection['from'] . '>' . $connection['to'] . '>' . ( isset( $connection['type'] ) ? $connection['type'] : 'default' );
        }
    }

    ksort( $steps );
    sort( $connections );

    return md5( wp_json_encode( array( $steps, $connections ) ) );
}

/**
 * Hash a template's copy: its subject and its html.
 *
 * @param string $subject The subject.
 * @param string $html    The html.
 * @return string
 */
function Affiliate_Theme_Theme_copy_hash( $subject, $html ) {
    return md5( wp_json_encode( array( (string) $subject, (string) $html ) ) );
}

/**
 * Tell if the settings hold every value that the emails need: a sending
 * domain, a mailing address and a usable affiliate URL.
 *
 * While one is empty, the setup run leaves every template's values as they
 * were, so a template never loses a fallback once it is made, and Resend
 * keeps sending what it had.
 *
 * @param array $settings The theme settings.
 * @return bool
 */
function Affiliate_Theme_Theme_sequence_values_ready( $settings ) {
    return '' !== $settings['sending_domain']
        && '' !== trim( $settings['mailing_address'] )
        && Affiliate_Theme_Theme_is_redirect_url( $settings['redirect_url'] );
}

/**
 * Give what a landing page's emails still wait for, in plain words. No
 * call to Resend.
 *
 * The stored domain status is the one that Resend last gave, from
 * Affiliate_Theme_Theme_domain_get(). Whoever starts a setup run checks
 * the key.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return array
 */
function Affiliate_Theme_Theme_sequence_missing( $index ) {
    $settings = Affiliate_Theme_Theme_get_settings();
    $state    = Affiliate_Theme_Theme_get_state();
    $domain   = $state['domain'];
    $missing  = array();

    if ( '' === $settings['sending_domain'] || empty( $domain['id'] ) || ! isset( $domain['name'], $domain['status'] ) || $domain['name'] !== $settings['sending_domain'] || 'verified' !== $domain['status'] ) {
        $missing[] = 'a verified sending domain';
    }

    if ( '' === trim( $settings['mailing_address'] ) ) {
        $missing[] = 'your mailing address';
    }

    if ( ! Affiliate_Theme_Theme_is_redirect_url( $settings['redirect_url'] ) ) {
        $missing[] = 'a usable affiliate link';
    }

    return $missing;
}

/**
 * Tell if a landing page's emails are live: its automation is on in
 * Resend, as far as the theme knows. No call to Resend.
 *
 * The opt-in form shows only while this is true.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return bool
 */
function Affiliate_Theme_Theme_sequence_live( $index ) {
    $seq = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );

    return '' !== $seq['automation_id'] && $seq['enabled'] && ! $seq['off'];
}

/**
 * Give why a landing page's opt-in form cannot show, in plain words, or ''
 * while it can. No call to Resend.
 *
 * The opt-in block shows the reason to an administrator. It reads the
 * state only: Affiliate_Theme_Theme_sequence_status() plans the whole
 * setup run, which is too much for every page that shows the form.
 *
 * A missing value hides the form even while the automation is still on in
 * Resend, as it is between a save that empties a value and the setup run
 * that turns it off.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return string
 */
function Affiliate_Theme_Theme_optin_not_ready( $index ) {
    if ( '' === Affiliate_Theme_Theme_resend_key() ) {
        return 'add your Resend API key';
    }

    $seq     = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $label   = Affiliate_Theme_Theme_sequence_label( $index );
    $missing = Affiliate_Theme_Theme_sequence_missing( $index );

    if ( $seq['off'] ) {
        return sprintf( 'the %s emails are turned off', $label );
    }

    if ( $missing ) {
        return sprintf( 'the %s emails wait for %s', $label, Affiliate_Theme_Theme_list_words( $missing ) );
    }

    if ( '' === $seq['automation_id'] ) {
        return sprintf( 'the %s emails are not set up in Resend yet', $label );
    }

    if ( ! Affiliate_Theme_Theme_sequence_live( $index ) ) {
        return sprintf( 'the %s emails are not turned on yet', $label );
    }

    return '';
}

/**
 * Join words into a list: "a", "a and b", "a, b and c".
 *
 * @param array $words The words.
 * @return string
 */
function Affiliate_Theme_Theme_list_words( $words ) {
    $words = array_values( $words );

    if ( count( $words ) < 2 ) {
        return implode( '', $words );
    }

    $last = array_pop( $words );

    return implode( ', ', $words ) . ' and ' . $last;
}

/* -------------------------------------------------------------------------
 * Setting up the emails
 *
 * After a save, the theme makes everything the emails need in the buyer's
 * Resend account: 3 contact properties, 3 events, 17 published templates
 * and 3 automations, which it turns on last, once nothing is missing. The
 * planner works out what is left from the settings and the state, with no
 * call to Resend. The runner does one step per request, so no request runs
 * long, and the state is saved after each one. A run that stops is picked
 * up by the next one, which makes nothing twice: every run starts by
 * reading the account, and adopts what is there by alias, name or key.
 * ---------------------------------------------------------------------- */

/**
 * Read every page of a Resend list.
 *
 * @param string $path The list, such as /templates.
 * @return array|WP_Error The items, or a fault whose data is the reply.
 */
function Affiliate_Theme_Theme_resend_list( $path ) {
    $items = array();
    $after = '';

    // 20 pages of 100 is more than any account the theme sets up holds.
    for ( $page = 0; $page < 20; $page++ ) {
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'GET', $path . '?limit=100' . ( '' !== $after ? '&after=' . rawurlencode( $after ) : '' ) );

        if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
            return new WP_Error( 'affiliate_theme_resend', 'list', $reply );
        }

        $data = isset( $reply['body']['data'] ) && is_array( $reply['body']['data'] ) ? $reply['body']['data'] : array();

        foreach ( $data as $item ) {
            if ( is_array( $item ) && isset( $item['id'] ) ) {
                $items[] = $item;
            }
        }

        $last = end( $data );

        if ( empty( $reply['body']['has_more'] ) || ! is_array( $last ) || empty( $last['id'] ) ) {
            break;
        }

        $after = (string) $last['id'];
    }

    return $items;
}

/**
 * Find an object in a list: by its stored ID, else by a field's exact value.
 *
 * @param array  $items  The list.
 * @param string $id     The stored ID, or ''.
 * @param string $field  The field, such as alias.
 * @param string $value  Its value.
 * @return array|null The item, or null.
 */
function Affiliate_Theme_Theme_setup_find( $items, $id, $field, $value ) {
    if ( '' !== $id ) {
        foreach ( $items as $item ) {
            if ( (string) $item['id'] === $id ) {
                return $item;
            }
        }
    }

    foreach ( $items as $item ) {
        if ( isset( $item[ $field ] ) && $item[ $field ] === $value ) {
            return $item;
        }
    }

    return null;
}

/**
 * Store a fault of one landing page for this run. The run goes on with the
 * other pages, and the next run tries again.
 *
 * @param int    $index   The landing page number, 1 to 3.
 * @param string $token   The run.
 * @param string $message What went wrong, as escaped HTML.
 * @return true
 */
function Affiliate_Theme_Theme_setup_error( $index, $token, $message ) {
    $seq          = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $seq['error'] = array(
        'run'     => $token,
        'message' => $message,
    );
    Affiliate_Theme_Theme_save_sequence( $index, $seq );

    return true;
}

/**
 * Handle a failed reply during a run, and log it.
 *
 * No reply, a 429 after the retries, a fault at Resend or a refused key
 * stops the whole run, since the next request would most likely fail too.
 * Any other refusal stops only that landing page for this run.
 *
 * @param array  $reply The reply.
 * @param string $doing What the theme was doing, such as "add the template".
 * @param int    $index The landing page number, or 0 for the whole account.
 * @param string $token The run.
 * @return true|WP_Error True to go on, or the fault that stops the run.
 */
function Affiliate_Theme_Theme_setup_fault( $reply, $doing, $index, $token ) {
    $error   = Affiliate_Theme_Theme_resend_fail( $reply, $doing );
    $message = esc_html( $error->get_error_message() );

    if ( 0 === $reply['code'] || 401 === $reply['code'] || 429 === $reply['code'] || $reply['code'] >= 500 || ! $index ) {
        return new WP_Error(
            'affiliate_theme_setup',
            sprintf(
                '%s, so the theme stopped setting up your emails. %s Click <strong>Finish setting up emails</strong> to pick up where it stopped.',
                401 === $reply['code'] ? 'Resend refused the API key' : 'Resend did not answer',
                $message
            )
        );
    }

    return Affiliate_Theme_Theme_setup_error( $index, $token, $message );
}

/**
 * The read step, the first of every run: refresh the domain, read every
 * template, event, contact property and automation, and bring the state
 * into line with them.
 *
 * - A stored ID that is gone from its list is forgotten, so the run makes
 *   that object again. A template that the buyer deleted comes back.
 * - Otherwise each object is adopted by its alias, name or key, so a run
 *   whose reply was lost, a new key or a lost state makes nothing twice.
 * - An automation is found by its stored ID, then by its exact name. When
 *   several share the name, the one that is on wins, else the newest. An
 *   adopted automation is read once, and its graph hashed, so a graph that
 *   is right already is left alone.
 * - Each landing page's fault and its list of draft templates are cleared:
 *   this run tries again.
 *
 * @param string $token The run.
 * @return true|WP_Error
 */
function Affiliate_Theme_Theme_setup_read( $token ) {
    Affiliate_Theme_Theme_domain_get( true );

    $lists = array();

    foreach ( array( 'templates', 'events', 'contact-properties', 'automations' ) as $what ) {
        $items = Affiliate_Theme_Theme_resend_list( '/' . $what );

        if ( is_wp_error( $items ) ) {
            return Affiliate_Theme_Theme_setup_fault( $items->get_error_data(), 'list your ' . str_replace( '-', ' ', $what ), 0, $token );
        }

        $lists[ $what ] = $items;
    }

    $state = Affiliate_Theme_Theme_get_state();

    foreach ( Affiliate_Theme_Theme_email_sequences() as $index => $emails ) {
        $seq          = Affiliate_Theme_Theme_get_sequence( $state, $index );
        $seq['error'] = array();
        $seq['draft'] = array();

        $item               = Affiliate_Theme_Theme_setup_find( $lists['contact-properties'], $seq['property_id'], 'key', Affiliate_Theme_Theme_sequence_property( $index ) );
        $seq['property_id'] = null === $item ? '' : (string) $item['id'];

        $item            = Affiliate_Theme_Theme_setup_find( $lists['events'], $seq['event_id'], 'name', Affiliate_Theme_Theme_sequence_event( $index ) );
        $seq['event_id'] = null === $item ? '' : (string) $item['id'];

        $templates = array();

        foreach ( $emails as $k => $email ) {
            $alias = Affiliate_Theme_Theme_template_alias( $index, $k + 1 );
            $had   = isset( $seq['templates'][ $alias ] ) ? $seq['templates'][ $alias ] : array();
            $item  = Affiliate_Theme_Theme_setup_find( $lists['templates'], isset( $had['id'] ) ? (string) $had['id'] : '', 'alias', $alias );

            if ( null === $item ) {
                continue;
            }

            if ( ! isset( $had['id'] ) || (string) $had['id'] !== (string) $item['id'] ) {
                // Adopted. Its values are compared before any change, and
                // its copy is unknown.
                $had = array(
                    'values_hash' => '',
                    'copy_hash'   => null,
                );
            }

            $templates[ $alias ] = array_merge(
                $had,
                array(
                    'id'        => (string) $item['id'],
                    'published' => isset( $item['status'] ) && 'published' === $item['status'],
                )
            );
        }

        $seq['templates'] = $templates;

        // The automation, by its stored ID.
        $item = Affiliate_Theme_Theme_setup_find( $lists['automations'], $seq['automation_id'], 'id', $seq['automation_id'] );

        if ( null === $item ) {
            $seq = Affiliate_Theme_Theme_sequence_forget_automation( $seq );

            // Else by its exact name. The list is newest first.
            $name = Affiliate_Theme_Theme_sequence_name( $index );

            foreach ( $lists['automations'] as $candidate ) {
                if ( isset( $candidate['name'] ) && $candidate['name'] === $name && ( null === $item || ( 'enabled' !== $item['status'] && isset( $candidate['status'] ) && 'enabled' === $candidate['status'] ) ) ) {
                    $item = $candidate;
                }
            }

            if ( null !== $item ) {
                $reply = Affiliate_Theme_Theme_resend_admin_call( 'GET', '/automations/' . rawurlencode( $item['id'] ) );

                if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
                    return Affiliate_Theme_Theme_setup_fault( $reply, 'read the automation ' . $name, 0, $token );
                }

                $seq['automation_id'] = (string) $item['id'];
                $seq['graph_hash']    = Affiliate_Theme_Theme_graph_hash( $reply['body'] );
            }
        }

        if ( '' !== $seq['automation_id'] ) {
            $seq = Affiliate_Theme_Theme_sequence_reconcile( $seq, $item );
        }

        $state['sequences'][ $index ] = $seq;
    }

    Affiliate_Theme_Theme_update_state( $state );

    return true;
}

/**
 * Work out the steps left, in the order that they run. No call to Resend.
 *
 * 1. domain: the Sending domain field, when the state does not have it.
 *    A save runs it before the page loads, so this is for a run that
 *    follows a fault.
 * 2. read: once per run.
 * 3. property:N, then event:N, for each landing page.
 * 4. template:N:alias: add and publish, or publish alone.
 * 5. values:N:alias: a template whose values differ from what the
 *    settings give. None while a value that the emails need is empty, and
 *    none for a template with an unpublished edit in Resend.
 * 6. automation:N: make it, or re-point it when its graph differs.
 * 7. disable:N: on, but something is missing.
 * 8. enable:N: last, when that page has nothing else left, nothing is
 *    missing, no template is in draft, and it is not off.
 *
 * A landing page that met a fault in this run gets no more steps in it.
 *
 * @param array  $tried The run's steps that run only once: domain, read.
 * @param string $token The run, or '' to plan outside a run.
 * @return array The steps: id, seq (the landing page, or 0) and label.
 */
function Affiliate_Theme_Theme_setup_plan( $tried = array(), $token = '' ) {
    $settings = Affiliate_Theme_Theme_get_settings();
    $state    = Affiliate_Theme_Theme_get_state();
    $ready    = Affiliate_Theme_Theme_sequence_values_ready( $settings );
    $groups   = array_fill_keys( array( 'domain', 'read', 'property', 'event', 'template', 'values', 'automation', 'disable', 'enable' ), array() );
    $domain   = $state['domain'];

    $step = static function ( $id, $seq, $label ) {
        return array(
            'id'    => $id,
            'seq'   => $seq,
            'label' => $label,
        );
    };

    if ( '' !== $settings['sending_domain'] && ( empty( $domain['id'] ) || ! isset( $domain['name'] ) || $domain['name'] !== $settings['sending_domain'] ) && ! in_array( 'domain', $tried, true ) ) {
        $groups['domain'][] = $step( 'domain', 0, 'Sending domain' );
    }

    if ( ! in_array( 'read', $tried, true ) ) {
        $groups['read'][] = $step( 'read', 0, 'Reading your Resend account' );
    }

    foreach ( Affiliate_Theme_Theme_email_sequences() as $index => $emails ) {
        $seq = Affiliate_Theme_Theme_get_sequence( $state, $index );

        if ( '' !== $token && isset( $seq['error']['run'] ) && $seq['error']['run'] === $token ) {
            continue;
        }

        $label    = Affiliate_Theme_Theme_sequence_label( $index );
        $count    = count( $emails );
        $complete = '' !== $seq['property_id'] && '' !== $seq['event_id'];
        $own      = 0;

        if ( '' === $seq['property_id'] ) {
            $groups['property'][] = $step( 'property:' . $index, $index, $label . ': contact property' );
            ++$own;
        }

        if ( '' === $seq['event_id'] ) {
            $groups['event'][] = $step( 'event:' . $index, $index, $label . ': event' );
            ++$own;
        }

        foreach ( $emails as $k => $email ) {
            $n     = $k + 1;
            $alias = Affiliate_Theme_Theme_template_alias( $index, $n );
            $have  = isset( $seq['templates'][ $alias ] ) ? $seq['templates'][ $alias ] : array();

            if ( empty( $have['id'] ) || empty( $have['published'] ) ) {
                $groups['template'][] = $step( 'template:' . $index . ':' . $alias, $index, sprintf( '%s: email %d of %d', $label, $n, $count ) );
                $complete             = false;
                ++$own;
            }

            if ( empty( $have['id'] ) || ! $ready || in_array( $alias, $seq['draft'], true ) ) {
                continue;
            }

            $want = Affiliate_Theme_Theme_template_values_hash( $email, $settings );

            if ( null === $want || ! isset( $have['values_hash'] ) || $want !== $have['values_hash'] ) {
                $groups['values'][] = $step( 'values:' . $index . ':' . $alias, $index, sprintf( '%s: updating email %d of %d', $label, $n, $count ) );
                ++$own;
            }
        }

        if ( $complete ) {
            if ( '' === $seq['automation_id'] ) {
                $groups['automation'][] = $step( 'automation:' . $index, $index, $label . ': automation' );
                ++$own;
            } elseif ( Affiliate_Theme_Theme_graph_hash( Affiliate_Theme_Theme_sequence_graph( $index, Affiliate_Theme_Theme_sequence_ids( $seq ) ) ) !== $seq['graph_hash'] ) {
                $groups['automation'][] = $step( 'automation:' . $index, $index, $label . ': updating its automation' );
                ++$own;
            }
        }

        $missing = Affiliate_Theme_Theme_sequence_missing( $index );

        // A template in draft kept values that differ from the settings, and
        // may lack a fallback that a send needs, so its page is not turned
        // on. One that is on already stays on.
        if ( $seq['enabled'] && $missing ) {
            $groups['disable'][] = $step( 'disable:' . $index, $index, $label . ': turning it off' );
        } elseif ( ! $seq['enabled'] && ! $seq['off'] && ! $missing && $complete && ! $own && ! $seq['draft'] && '' !== $seq['automation_id'] ) {
            $groups['enable'][] = $step( 'enable:' . $index, $index, $label . ': turning it on' );
        }
    }

    return array_merge( ...array_values( $groups ) );
}

/**
 * Count the steps left for each landing page. Key 0 counts the domain and
 * the read.
 *
 * @param array $plan From Affiliate_Theme_Theme_setup_plan().
 * @return array
 */
function Affiliate_Theme_Theme_setup_remaining( $plan ) {
    $remaining = array_fill( 0, count( Affiliate_Theme_Theme_email_sequences() ) + 1, 0 );

    foreach ( $plan as $step ) {
        ++$remaining[ $step['seq'] ];
    }

    return $remaining;
}

/**
 * Make an event or a contact property. One that exists already is adopted.
 *
 * @param int    $index The landing page number, 1 to 3.
 * @param string $token The run.
 * @param string $field event_id or property_id.
 * @param string $path  /events or /contact-properties.
 * @param array  $body  The body.
 * @param string $match The list field that names it: name or key.
 * @param string $doing What the theme is doing, for a fault.
 * @return true|WP_Error
 */
function Affiliate_Theme_Theme_setup_make( $index, $token, $field, $path, $body, $match, $doing ) {
    $reply = Affiliate_Theme_Theme_resend_admin_call( 'POST', $path, $body );
    $id    = Affiliate_Theme_Theme_resend_ok( $reply ) && ! empty( $reply['body']['id'] ) ? (string) $reply['body']['id'] : '';

    if ( 409 === $reply['code'] ) {
        // It exists, though the read step did not list it.
        Affiliate_Theme_Theme_resend_log( $reply );

        $items = Affiliate_Theme_Theme_resend_list( $path );

        if ( is_wp_error( $items ) ) {
            return Affiliate_Theme_Theme_setup_fault( $items->get_error_data(), $doing, $index, $token );
        }

        $item = Affiliate_Theme_Theme_setup_find( $items, '', $match, $body[ $match ] );
        $id   = null === $item ? '' : (string) $item['id'];
    }

    if ( '' === $id ) {
        if ( Affiliate_Theme_Theme_resend_ok( $reply ) || 409 === $reply['code'] ) {
            return Affiliate_Theme_Theme_setup_error( $index, $token, esc_html( sprintf( 'Resend did not give the theme an ID when it tried to %s.', $doing ) ) );
        }

        return Affiliate_Theme_Theme_setup_fault( $reply, $doing, $index, $token );
    }

    $seq           = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $seq[ $field ] = $id;
    Affiliate_Theme_Theme_save_sequence( $index, $seq );

    return true;
}

/**
 * Store one template in the state, or forget it with null.
 *
 * @param int        $index    The landing page number, 1 to 3.
 * @param string     $alias    The alias.
 * @param array|null $template Its entry.
 * @return void
 */
function Affiliate_Theme_Theme_setup_store_template( $index, $alias, $template ) {
    $seq = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );

    if ( null === $template ) {
        unset( $seq['templates'][ $alias ] );
    } else {
        $seq['templates'][ $alias ] = $template;
    }

    Affiliate_Theme_Theme_save_sequence( $index, $seq );
}

/**
 * Find an email by its template alias.
 *
 * @param int    $index The landing page number, 1 to 3.
 * @param string $alias The alias.
 * @return array|null The email's number n and its entry email, or null.
 */
function Affiliate_Theme_Theme_setup_email( $index, $alias ) {
    $sequences = Affiliate_Theme_Theme_email_sequences();

    foreach ( $sequences[ $index ] as $k => $email ) {
        if ( Affiliate_Theme_Theme_template_alias( $index, $k + 1 ) === $alias ) {
            return array(
                'n'     => $k + 1,
                'email' => $email,
            );
        }
    }

    return null;
}

/**
 * Make one email's template and publish it, or publish one that is not.
 *
 * A template is made once and its copy is never changed by a run: only
 * Reset these emails does that. An alias that Resend says is in use, though
 * the read step did not list it, is adopted.
 *
 * @param int    $index The landing page number, 1 to 3.
 * @param string $alias The alias.
 * @param string $token The run.
 * @return true|WP_Error
 */
function Affiliate_Theme_Theme_setup_template( $index, $alias, $token ) {
    $found = Affiliate_Theme_Theme_setup_email( $index, $alias );
    $seq   = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $have  = isset( $seq['templates'][ $alias ] ) ? $seq['templates'][ $alias ] : array();

    if ( null === $found ) {
        return true;
    }

    if ( empty( $have['id'] ) ) {
        $body = Affiliate_Theme_Theme_body_template( $index, $found['n'], $found['email'], Affiliate_Theme_Theme_get_settings() );

        if ( is_wp_error( $body ) ) {
            error_log( 'Affiliate Theme could not make the template ' . $alias . '. ' . $body->get_error_message() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- A fault in the theme's own files.

            return Affiliate_Theme_Theme_setup_error( $index, $token, esc_html( $body->get_error_message() ) );
        }

        $reply = Affiliate_Theme_Theme_resend_admin_call( 'POST', '/templates', $body );

        if ( Affiliate_Theme_Theme_resend_ok( $reply ) && ! empty( $reply['body']['id'] ) ) {
            $have = array(
                'id'          => (string) $reply['body']['id'],
                'published'   => false,
                'values_hash' => Affiliate_Theme_Theme_values_hash( isset( $body['from'] ) ? $body['from'] : '', $body['reply_to'], $body['variables'] ),
                'copy_hash'   => Affiliate_Theme_Theme_copy_hash( $body['subject'], $body['html'] ),
            );
        } elseif ( 422 === $reply['code'] && preg_match( '/\balias\b/i', Affiliate_Theme_Theme_resend_error( $reply ) ) ) {
            Affiliate_Theme_Theme_resend_log( $reply );

            $reply = Affiliate_Theme_Theme_resend_admin_call( 'GET', '/templates/' . rawurlencode( $alias ) );

            if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) || empty( $reply['body']['id'] ) ) {
                return Affiliate_Theme_Theme_setup_fault( $reply, 'read the template ' . $alias, $index, $token );
            }

            $have = array(
                'id'          => (string) $reply['body']['id'],
                'published'   => isset( $reply['body']['status'] ) && 'published' === $reply['body']['status'],
                'values_hash' => '',
                'copy_hash'   => null,
            );
        } else {
            return Affiliate_Theme_Theme_setup_fault( $reply, 'add the template ' . $alias, $index, $token );
        }

        // Stored before the publish, so a lost publish leaves the ID here.
        Affiliate_Theme_Theme_setup_store_template( $index, $alias, $have );
    }

    if ( empty( $have['published'] ) ) {
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'POST', '/templates/' . rawurlencode( $have['id'] ) . '/publish' );

        if ( 404 === $reply['code'] ) {
            Affiliate_Theme_Theme_resend_log( $reply );
            Affiliate_Theme_Theme_setup_store_template( $index, $alias, null );

            return true;
        }

        if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
            return Affiliate_Theme_Theme_setup_fault( $reply, 'publish the template ' . $alias, $index, $token );
        }

        $have['published'] = true;
        Affiliate_Theme_Theme_setup_store_template( $index, $alias, $have );
    }

    return true;
}

/**
 * Bring one template's values into line with the settings: From, Reply-to
 * and the variables' fallbacks. Its copy is left alone, so an email that
 * the buyer edited in Resend keeps the edit.
 *
 * The template is read first. Values that match already are only noted. A
 * template with an edit in Resend that is not published is left alone and
 * listed in draft, since publishing would put that edit live too. The
 * theme's own PATCH whose publish did not happen is published.
 *
 * @param int    $index The landing page number, 1 to 3.
 * @param string $alias The alias.
 * @param string $token The run.
 * @return true|WP_Error
 */
function Affiliate_Theme_Theme_setup_values( $index, $alias, $token ) {
    $found = Affiliate_Theme_Theme_setup_email( $index, $alias );
    $seq   = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $have  = isset( $seq['templates'][ $alias ] ) ? $seq['templates'][ $alias ] : array();

    if ( null === $found || empty( $have['id'] ) ) {
        return true;
    }

    $body = Affiliate_Theme_Theme_body_template_values( $found['email'], Affiliate_Theme_Theme_get_settings() );

    if ( is_wp_error( $body ) ) {
        return Affiliate_Theme_Theme_setup_error( $index, $token, esc_html( $body->get_error_message() ) );
    }

    $want  = Affiliate_Theme_Theme_values_hash( isset( $body['from'] ) ? $body['from'] : '', $body['reply_to'], $body['variables'] );
    $path  = '/templates/' . rawurlencode( $have['id'] );
    $reply = Affiliate_Theme_Theme_resend_admin_call( 'GET', $path );

    if ( 404 === $reply['code'] ) {
        Affiliate_Theme_Theme_resend_log( $reply );
        Affiliate_Theme_Theme_setup_store_template( $index, $alias, null );

        return true;
    }

    if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
        return Affiliate_Theme_Theme_setup_fault( $reply, 'read the template ' . $alias, $index, $token );
    }

    $remote = $reply['body'];
    $draft  = ! empty( $remote['has_unpublished_versions'] );
    $mine   = $draft && isset( $have['pending'] ) && $want === $have['pending'];

    $current = Affiliate_Theme_Theme_values_hash(
        isset( $remote['from'] ) ? $remote['from'] : '',
        isset( $remote['reply_to'] ) ? $remote['reply_to'] : array(),
        isset( $remote['variables'] ) ? $remote['variables'] : array()
    );

    if ( $current === $want && ! $mine ) {
        $have['values_hash'] = $want;
        Affiliate_Theme_Theme_setup_store_template( $index, $alias, $have );

        return true;
    }

    if ( $draft && ! $mine ) {
        $seq            = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
        $seq['draft'][] = $alias;
        $seq['draft']   = array_values( array_unique( $seq['draft'] ) );
        Affiliate_Theme_Theme_save_sequence( $index, $seq );

        return true;
    }

    if ( ! $mine ) {
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'PATCH', $path, $body );

        if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
            return Affiliate_Theme_Theme_setup_fault( $reply, 'update the template ' . $alias, $index, $token );
        }

        $have['pending'] = $want;
        Affiliate_Theme_Theme_setup_store_template( $index, $alias, $have );
    }

    $reply = Affiliate_Theme_Theme_resend_admin_call( 'POST', $path . '/publish' );

    if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
        return Affiliate_Theme_Theme_setup_fault( $reply, 'publish the template ' . $alias, $index, $token );
    }

    unset( $have['pending'] );
    $have['values_hash'] = $want;
    $have['published']   = true;

    $seq                        = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $seq['templates'][ $alias ] = $have;
    $seq['draft']               = array_values( array_diff( $seq['draft'], array( $alias ) ) );
    Affiliate_Theme_Theme_save_sequence( $index, $seq );

    return true;
}

/**
 * Make a landing page's automation, off, or re-point one whose graph
 * differs from what the theme would send.
 *
 * Resend refuses a graph change while the automation is on, so a live one
 * is turned off, changed and turned on in this one step, which keeps the
 * gap short. A run whose next email comes due while it is off is
 * cancelled. Resend refusing to make an automation is shown with its own
 * message, since a plan may allow fewer automations than the theme needs.
 *
 * @param int    $index The landing page number, 1 to 3.
 * @param string $token The run.
 * @return true|WP_Error
 */
function Affiliate_Theme_Theme_setup_automation( $index, $token ) {
    $seq   = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $graph = Affiliate_Theme_Theme_sequence_graph( $index, Affiliate_Theme_Theme_sequence_ids( $seq ) );
    $hash  = Affiliate_Theme_Theme_graph_hash( $graph );
    $label = Affiliate_Theme_Theme_sequence_label( $index );

    if ( '' === $seq['automation_id'] ) {
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'POST', '/automations', Affiliate_Theme_Theme_body_automation( $index, $graph ) );

        if ( Affiliate_Theme_Theme_resend_ok( $reply ) && ! empty( $reply['body']['id'] ) ) {
            $seq['automation_id'] = (string) $reply['body']['id'];
            $seq['graph_hash']    = $hash;
            $seq['enabled']       = false;
            Affiliate_Theme_Theme_save_sequence( $index, $seq );

            return true;
        }

        if ( Affiliate_Theme_Theme_resend_ok( $reply ) ) {
            return Affiliate_Theme_Theme_setup_error( $index, $token, 'Resend did not give the automation an ID.' );
        }

        if ( 0 === $reply['code'] || 401 === $reply['code'] || 429 === $reply['code'] || $reply['code'] >= 500 ) {
            return Affiliate_Theme_Theme_setup_fault( $reply, 'add the ' . $label . ' automation', $index, $token );
        }

        Affiliate_Theme_Theme_resend_log( $reply );

        return Affiliate_Theme_Theme_setup_error(
            $index,
            $token,
            esc_html( Affiliate_Theme_Theme_resend_error( $reply ) ) . ' Resend refused another automation. Your Resend plan may allow fewer automations than the theme needs.'
        );
    }

    $path = '/automations/' . rawurlencode( $seq['automation_id'] );
    $was  = $seq['enabled'];

    if ( $was ) {
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'PATCH', $path, Affiliate_Theme_Theme_body_status( false ) );

        if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
            return Affiliate_Theme_Theme_setup_gone( $index, $reply, 'turn off the ' . $label . ' automation', $token );
        }

        $seq['enabled'] = false;
        Affiliate_Theme_Theme_save_sequence( $index, $seq );
    }

    $reply = Affiliate_Theme_Theme_resend_admin_call( 'PATCH', $path, $graph );

    if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
        return Affiliate_Theme_Theme_setup_gone( $index, $reply, 'update the ' . $label . ' automation', $token );
    }

    $seq['graph_hash'] = $hash;
    Affiliate_Theme_Theme_save_sequence( $index, $seq );

    if ( $was && ! $seq['off'] && ! Affiliate_Theme_Theme_sequence_missing( $index ) ) {
        return Affiliate_Theme_Theme_setup_switch( $index, true, $token );
    }

    return true;
}

/**
 * Handle a refused change to an automation: a 404 means it is gone, and the
 * next step makes it again.
 *
 * @param int    $index The landing page number, 1 to 3.
 * @param array  $reply The reply.
 * @param string $doing What the theme was doing.
 * @param string $token The run.
 * @return true|WP_Error
 */
function Affiliate_Theme_Theme_setup_gone( $index, $reply, $doing, $token ) {
    if ( 404 !== $reply['code'] ) {
        return Affiliate_Theme_Theme_setup_fault( $reply, $doing, $index, $token );
    }

    Affiliate_Theme_Theme_resend_log( $reply );

    $seq = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    Affiliate_Theme_Theme_save_sequence( $index, Affiliate_Theme_Theme_sequence_forget_automation( $seq ) );

    return true;
}

/**
 * Turn a landing page's automation on or off. A run's own change never
 * makes the page off: only Turn off does.
 *
 * @param int    $index   The landing page number, 1 to 3.
 * @param bool   $enabled True to turn it on.
 * @param string $token   The run.
 * @return true|WP_Error
 */
function Affiliate_Theme_Theme_setup_switch( $index, $enabled, $token ) {
    $seq   = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $reply = Affiliate_Theme_Theme_resend_admin_call( 'PATCH', '/automations/' . rawurlencode( $seq['automation_id'] ), Affiliate_Theme_Theme_body_status( $enabled ) );

    if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
        return Affiliate_Theme_Theme_setup_gone( $index, $reply, ( $enabled ? 'turn on' : 'turn off' ) . ' the ' . Affiliate_Theme_Theme_sequence_label( $index ) . ' automation', $token );
    }

    $seq['enabled'] = $enabled;
    Affiliate_Theme_Theme_save_sequence( $index, $seq );

    return true;
}

/**
 * Run one planned step.
 *
 * @param array  $step  From Affiliate_Theme_Theme_setup_plan().
 * @param string $token The run.
 * @param array  $run   The run's record, changed in place: tried and notices.
 * @return true|WP_Error True to go on, or the fault that stops the run.
 */
function Affiliate_Theme_Theme_setup_do( $step, $token, &$run ) {
    $parts = explode( ':', $step['id'], 3 );
    $index = isset( $parts[1] ) ? (int) $parts[1] : 0;

    switch ( $parts[0] ) {
        case 'domain':
            $run['tried'][] = 'domain';
            $notice         = Affiliate_Theme_Theme_domain_step();

            if ( null !== $notice ) {
                $run['notices'][] = $notice;
            }

            return true;

        case 'read':
            $run['tried'][] = 'read';

            return Affiliate_Theme_Theme_setup_read( $token );

        case 'property':
            return Affiliate_Theme_Theme_setup_make( $index, $token, 'property_id', '/contact-properties', Affiliate_Theme_Theme_body_property( $index ), 'key', 'add the contact property ' . Affiliate_Theme_Theme_sequence_property( $index ) );

        case 'event':
            return Affiliate_Theme_Theme_setup_make( $index, $token, 'event_id', '/events', Affiliate_Theme_Theme_body_event( $index ), 'name', 'add the event ' . Affiliate_Theme_Theme_sequence_event( $index ) );

        case 'template':
            return Affiliate_Theme_Theme_setup_template( $index, $parts[2], $token );

        case 'values':
            return Affiliate_Theme_Theme_setup_values( $index, $parts[2], $token );

        case 'automation':
            return Affiliate_Theme_Theme_setup_automation( $index, $token );

        case 'disable':
        case 'enable':
            return Affiliate_Theme_Theme_setup_switch( $index, 'enable' === $parts[0], $token );
    }

    return true;
}

/**
 * Take the setup lock for a run, or refresh it, so two tabs never set up
 * the emails at once.
 *
 * This is WP_Upgrader::create_lock() made for a run: one INSERT IGNORE, so
 * of two requests at the same moment only one gets the row. add_option()
 * cannot do this, because it reads first and then writes with ON DUPLICATE
 * KEY UPDATE, and both requests would win. The row holds "<token>|<time>".
 * Each step refreshes the time, and a lock left idle for 120 seconds, by a
 * tab that was closed, is taken over.
 *
 * @param string $token The run.
 * @return bool True when the run holds the lock.
 */
function Affiliate_Theme_Theme_setup_lock( $token ) {
    global $wpdb;

    $value = $token . '|' . time();
    $took  = (bool) $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO `$wpdb->options` ( `option_name`, `option_value`, `autoload` ) VALUES ( %s, %s, 'off' ) /* LOCK */", AFFILIATE_THEME_SETUP_LOCK, $value ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A lock must skip the cache.

    if ( ! $took ) {
        $held = Affiliate_Theme_Theme_setup_lock_value();

        if ( null !== $held ) {
            list( $owner, $time ) = array_pad( explode( '|', $held, 2 ), 2, '0' );

            if ( $held === $value ) {
                $took = true;
            } elseif ( $owner === $token || time() - (int) $time > 120 ) {
                // Only the request whose UPDATE still finds the old row wins.
                $took = (bool) $wpdb->query( $wpdb->prepare( "UPDATE `$wpdb->options` SET `option_value` = %s WHERE `option_name` = %s AND `option_value` = %s", $value, AFFILIATE_THEME_SETUP_LOCK, $held ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A lock must skip the cache.
            }
        }
    }

    wp_cache_delete( AFFILIATE_THEME_SETUP_LOCK, 'options' );

    return $took;
}

/**
 * Give the lock row as the database holds it: "<token>|<time>", or null.
 *
 * @return string|null
 */
function Affiliate_Theme_Theme_setup_lock_value() {
    global $wpdb;

    $value = $wpdb->get_var( $wpdb->prepare( "SELECT `option_value` FROM `$wpdb->options` WHERE `option_name` = %s", AFFILIATE_THEME_SETUP_LOCK ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A lock must skip the cache.

    return null === $value ? null : (string) $value;
}

/**
 * Tell if a run holds the lock and has not been idle for 120 seconds.
 *
 * @return bool
 */
function Affiliate_Theme_Theme_setup_locked() {
    $held = Affiliate_Theme_Theme_setup_lock_value();

    if ( null === $held ) {
        return false;
    }

    $time = array_pad( explode( '|', $held, 2 ), 2, '0' );

    return time() - (int) $time[1] <= 120;
}

/**
 * Let go of the lock, if the run still holds it.
 *
 * @param string $token The run.
 * @return void
 */
function Affiliate_Theme_Theme_setup_unlock( $token ) {
    global $wpdb;

    $wpdb->query( $wpdb->prepare( "DELETE FROM `$wpdb->options` WHERE `option_name` = %s AND `option_value` LIKE %s", AFFILIATE_THEME_SETUP_LOCK, $wpdb->esc_like( $token . '|' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- A lock must skip the cache.
    wp_cache_delete( AFFILIATE_THEME_SETUP_LOCK, 'options' );
    delete_transient( 'affiliate-theme_setup_run_' . $token );
}

/**
 * Make the notice that a finished run leaves on the settings page.
 *
 * @param string $token   The run.
 * @param array  $notices The domain step's notices in this run.
 * @return array type and message.
 */
function Affiliate_Theme_Theme_setup_notice( $token, $notices ) {
    $state  = Affiliate_Theme_Theme_get_state();
    $live   = 0;
    $faults = 0;
    $all    = Affiliate_Theme_Theme_email_sequences();

    foreach ( array_keys( $all ) as $index ) {
        $seq     = Affiliate_Theme_Theme_get_sequence( $state, $index );
        $live   += Affiliate_Theme_Theme_sequence_live( $index ) ? 1 : 0;
        $faults += isset( $seq['error']['run'] ) && $seq['error']['run'] === $token ? 1 : 0;
    }

    if ( $faults ) {
        $notice = array( 'warning', 'The theme set up what it could. <strong>Your email sequences</strong> below shows what Resend refused.' );
    } elseif ( count( $all ) === $live ) {
        $notice = array( 'success', 'Your email sequences are set up, and all three are live.' );
    } else {
        $notice = array( 'info', 'The theme finished setting up your emails. <strong>Your email sequences</strong> below shows what each one still needs.' );
    }

    $messages = array();
    $types    = array( $notice[0] );

    foreach ( $notices as $earlier ) {
        $messages[] = $earlier['message'];
        $types[]    = $earlier['type'];
    }

    $messages[] = $notice[1];

    foreach ( array( 'error', 'warning', 'success', 'info' ) as $type ) {
        if ( in_array( $type, $types, true ) ) {
            break;
        }
    }

    return array(
        'type'    => $type,
        'message' => implode( ' ', $messages ),
    );
}

/**
 * Run the next step of a setup run, and start the run when it has no token.
 *
 * Each call takes or refreshes the lock, checks the key, runs the first
 * step that the planner gives and plans again. When nothing is left it
 * keeps the final notice for the settings page and lets go of the lock. A
 * fault that stops the run lets go of it too.
 *
 * @param string $token The run, or '' to start one. Its token is also its
 *                      ID, and its record (tried, notices, last) is a
 *                      transient named after it.
 * @return array token, done, label (what the step did), remaining (per
 *               landing page, see Affiliate_Theme_Theme_setup_remaining()),
 *               error (plain text, or '') and notice (type and message,
 *               on done or on a fault).
 */
function Affiliate_Theme_Theme_setup_step( $token = '' ) {
    $reply = array(
        'token'     => '',
        'done'      => true,
        'label'     => '',
        'remaining' => array(),
        'error'     => '',
    );

    $check = Affiliate_Theme_Theme_check_key();

    if ( 'ok' !== $check['status'] ) {
        $message         = 'missing' === $check['status'] ? 'Save a Resend API key with Full access first.' : $check['message'];
        $reply['error']  = $message;
        $reply['notice'] = array(
            'type'    => 'error',
            'message' => esc_html( $message ),
        );

        return $reply;
    }

    $token = is_string( $token ) && preg_match( '/^[A-Za-z0-9]{20}$/', $token ) ? $token : wp_generate_password( 20, false );

    if ( ! Affiliate_Theme_Theme_setup_lock( $token ) ) {
        $reply['error']  = 'Another tab is setting up these emails. Try again in two minutes.';
        $reply['notice'] = array(
            'type'    => 'error',
            'message' => $reply['error'],
        );

        return $reply;
    }

    $reply['token'] = $token;
    $run_key        = 'affiliate-theme_setup_run_' . $token;
    $run            = get_transient( $run_key );
    $run            = wp_parse_args(
        is_array( $run ) ? $run : array(),
        array(
            'tried'   => array(),
            'notices' => array(),
            'last'    => '',
        )
    );

    $plan = Affiliate_Theme_Theme_setup_plan( $run['tried'], $token );

    if ( $plan ) {
        $step           = $plan[0];
        $reply['label'] = $step['label'];

        if ( $step['id'] === $run['last'] && $step['seq'] ) {
            // A step that left nothing changed would run for ever.
            $result = Affiliate_Theme_Theme_setup_error( $step['seq'], $token, esc_html( sprintf( 'The theme could not finish this step: %s.', $step['label'] ) ) );
        } else {
            $run['last'] = $step['id'];
            $result      = Affiliate_Theme_Theme_setup_do( $step, $token, $run );
        }

        if ( is_wp_error( $result ) ) {
            Affiliate_Theme_Theme_setup_unlock( $token );

            $reply['error']  = html_entity_decode( wp_strip_all_tags( $result->get_error_message() ), ENT_QUOTES, 'UTF-8' );
            $reply['notice'] = array(
                'type'    => 'error',
                'message' => $result->get_error_message(),
            );

            return $reply;
        }

        set_transient( $run_key, $run, 10 * MINUTE_IN_SECONDS );

        $plan = Affiliate_Theme_Theme_setup_plan( $run['tried'], $token );
    }

    $reply['remaining'] = Affiliate_Theme_Theme_setup_remaining( $plan );

    if ( $plan ) {
        $reply['done'] = false;

        return $reply;
    }

    $reply['notice'] = Affiliate_Theme_Theme_setup_notice( $token, $run['notices'] );
    Affiliate_Theme_Theme_set_notice( $reply['notice']['message'], $reply['notice']['type'] );
    Affiliate_Theme_Theme_setup_unlock( $token );

    return $reply;
}

/**
 * Run every step in one request: the path with no JavaScript, and what
 * Turn on and Reset use.
 *
 * It stops when the run is done, at a fault, or when the time budget is
 * spent, which leaves a notice to click Finish setting up emails again.
 *
 * @param int $budget The seconds that it may take.
 * @return array The last reply from Affiliate_Theme_Theme_setup_step().
 */
function Affiliate_Theme_Theme_setup_run_all( $budget = 100 ) {
    $start = microtime( true );
    $token = '';

    do {
        $reply = Affiliate_Theme_Theme_setup_step( $token );
        $token = $reply['token'];

        if ( '' !== $reply['error'] ) {
            Affiliate_Theme_Theme_set_notice( $reply['notice']['message'], 'error' );

            return $reply;
        }

        if ( $reply['done'] ) {
            return $reply;
        }
    } while ( microtime( true ) - $start < $budget );

    Affiliate_Theme_Theme_setup_unlock( $token );

    $reply['error']  = 'Setting up your emails takes longer than this server allows in one go.';
    $reply['notice'] = array(
        'type'    => 'warning',
        'message' => 'Setting up your emails takes longer than this server allows in one go. Click <strong>Finish setting up emails</strong> again to go on.',
    );
    Affiliate_Theme_Theme_set_notice( $reply['notice']['message'], $reply['notice']['type'] );

    return $reply;
}

/**
 * Answer the setup panel's request for the next step.
 *
 * admin-ajax works on every permalink setting, Plain included, which a REST
 * route would not without .htaccess. The panel sends the nonce, never the
 * key.
 *
 * @return void
 */
function Affiliate_Theme_Theme_setup_step_ajax() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( -1, 403 );
    }

    check_ajax_referer( 'affiliate-theme_setup' );

    if ( function_exists( 'set_time_limit' ) ) {
        set_time_limit( 60 ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- One step can make a few calls to Resend.
    }

    $token = isset( $_POST['token'] ) && is_string( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
    $reply = Affiliate_Theme_Theme_setup_step( $token );

    unset( $reply['notice'] );

    wp_send_json( $reply );
}
add_action( 'wp_ajax_affiliate-theme_setup_step', 'Affiliate_Theme_Theme_setup_step_ajax' );

/**
 * Handle Finish setting up emails, the panel's button that works without
 * JavaScript.
 *
 * @return void
 */
function Affiliate_Theme_Theme_setup_finish_handler() {
    Affiliate_Theme_Theme_check_action( 'affiliate-theme_setup_finish' );
    Affiliate_Theme_Theme_setup_run_all();
    Affiliate_Theme_Theme_back_to_settings( 'affiliate-theme-sequences' );
}
add_action( 'admin_post_affiliate-theme_setup_finish', 'Affiliate_Theme_Theme_setup_finish_handler' );

/**
 * Give the landing page that a sequence action names.
 *
 * @return int
 */
function Affiliate_Theme_Theme_sequence_from_post() {
    $index     = isset( $_POST['sequence'] ) ? absint( $_POST['sequence'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by Affiliate_Theme_Theme_check_action().
    $sequences = Affiliate_Theme_Theme_email_sequences();

    if ( ! isset( $sequences[ $index ] ) ) {
        wp_die( 'There is no such email sequence.', 400 );
    }

    return $index;
}

/**
 * Turn off one landing page's emails: its automation goes off in Resend,
 * and nothing is deleted. No setup run turns it on again, only Turn on.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return array The notice: type and message.
 */
function Affiliate_Theme_Theme_sequence_off( $index ) {
    $label = Affiliate_Theme_Theme_sequence_label( $index );
    $token = wp_generate_password( 20, false );

    if ( ! Affiliate_Theme_Theme_setup_lock( $token ) ) {
        return array(
            'type'    => 'error',
            'message' => 'Another tab is setting up these emails. Try again in two minutes.',
        );
    }

    $seq = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );

    if ( '' !== $seq['automation_id'] ) {
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'PATCH', '/automations/' . rawurlencode( $seq['automation_id'] ), Affiliate_Theme_Theme_body_status( false ) );

        if ( 404 === $reply['code'] ) {
            Affiliate_Theme_Theme_resend_log( $reply );
            $seq = Affiliate_Theme_Theme_sequence_forget_automation( $seq );
        } elseif ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
            Affiliate_Theme_Theme_setup_unlock( $token );

            return array(
                'type'    => 'error',
                'message' => esc_html( Affiliate_Theme_Theme_resend_fail( $reply, 'turn off the ' . $label . ' automation' )->get_error_message() ),
            );
        }
    }

    $seq['enabled'] = false;
    $seq['off']     = true;
    $seq['off_by']  = 'theme';
    Affiliate_Theme_Theme_save_sequence( $index, $seq );
    Affiliate_Theme_Theme_setup_unlock( $token );

    return array(
        'type'    => 'success',
        'message' => sprintf( '<strong>%s</strong> is off. New sign-ups on that page get no emails, and people partway through stop getting them as each next email comes due. Turning it on again does not restart them.', esc_html( $label ) ),
    );
}

/**
 * Handle Turn off.
 *
 * @return void
 */
function Affiliate_Theme_Theme_sequence_off_handler() {
    Affiliate_Theme_Theme_check_action( 'affiliate-theme_sequence_off' );

    $notice = Affiliate_Theme_Theme_sequence_off( Affiliate_Theme_Theme_sequence_from_post() );
    Affiliate_Theme_Theme_set_notice( $notice['message'], $notice['type'] );
    Affiliate_Theme_Theme_back_to_settings( 'affiliate-theme-sequences' );
}
add_action( 'admin_post_affiliate-theme_sequence_off', 'Affiliate_Theme_Theme_sequence_off_handler' );

/**
 * Handle Turn on: the page is no longer off, and a run makes anything that
 * is missing and turns the automation on when nothing is.
 *
 * @return void
 */
function Affiliate_Theme_Theme_sequence_on_handler() {
    Affiliate_Theme_Theme_check_action( 'affiliate-theme_sequence_on' );

    $index         = Affiliate_Theme_Theme_sequence_from_post();
    $seq           = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $seq['off']    = false;
    $seq['off_by'] = '';
    Affiliate_Theme_Theme_save_sequence( $index, $seq );

    Affiliate_Theme_Theme_setup_run_all();
    Affiliate_Theme_Theme_back_to_settings( 'affiliate-theme-sequences' );
}
add_action( 'admin_post_affiliate-theme_sequence_on', 'Affiliate_Theme_Theme_sequence_on_handler' );

/**
 * Put one landing page's emails back to the theme's copy, over any edit
 * the buyer made in Resend, and publish them. It is the only path that
 * changes a template's copy once it is made.
 *
 * While a value that the emails need is empty, only the names, subject and
 * html are sent, so the templates keep the values that they have.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return array The notice (type and message), and count: the emails reset.
 */
function Affiliate_Theme_Theme_sequence_reset( $index ) {
    $label = Affiliate_Theme_Theme_sequence_label( $index );
    $token = wp_generate_password( 20, false );
    $fail  = static function ( $message ) {
        return array(
            'type'    => 'error',
            'message' => $message,
            'count'   => 0,
        );
    };

    if ( ! Affiliate_Theme_Theme_setup_lock( $token ) ) {
        return $fail( 'Another tab is setting up these emails. Try again in two minutes.' );
    }

    $settings  = Affiliate_Theme_Theme_get_settings();
    $ready     = Affiliate_Theme_Theme_sequence_values_ready( $settings );
    $sequences = Affiliate_Theme_Theme_email_sequences();
    $count     = 0;

    foreach ( $sequences[ $index ] as $k => $email ) {
        $alias = Affiliate_Theme_Theme_template_alias( $index, $k + 1 );
        $seq   = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );

        if ( empty( $seq['templates'][ $alias ]['id'] ) ) {
            // The run after this makes it.
            continue;
        }

        $have = $seq['templates'][ $alias ];
        $body = Affiliate_Theme_Theme_body_template( $index, $k + 1, $email, $settings );

        if ( is_wp_error( $body ) ) {
            Affiliate_Theme_Theme_setup_unlock( $token );

            return $fail( esc_html( $body->get_error_message() ) );
        }

        unset( $body['alias'] );

        if ( ! $ready ) {
            unset( $body['from'], $body['reply_to'], $body['variables'] );
        }

        $path  = '/templates/' . rawurlencode( $have['id'] );
        $reply = Affiliate_Theme_Theme_resend_admin_call( 'PATCH', $path, $body );

        if ( Affiliate_Theme_Theme_resend_ok( $reply ) ) {
            $reply = Affiliate_Theme_Theme_resend_admin_call( 'POST', $path . '/publish' );
        }

        if ( 404 === $reply['code'] ) {
            Affiliate_Theme_Theme_resend_log( $reply );
            Affiliate_Theme_Theme_setup_store_template( $index, $alias, null );
            continue;
        }

        if ( ! Affiliate_Theme_Theme_resend_ok( $reply ) ) {
            Affiliate_Theme_Theme_setup_unlock( $token );

            return $fail( esc_html( Affiliate_Theme_Theme_resend_fail( $reply, 'reset the template ' . $alias )->get_error_message() ) );
        }

        unset( $have['pending'] );
        $have['copy_hash'] = Affiliate_Theme_Theme_copy_hash( $body['subject'], $body['html'] );
        $have['published'] = true;

        if ( $ready ) {
            $have['values_hash'] = Affiliate_Theme_Theme_values_hash( isset( $body['from'] ) ? $body['from'] : '', $body['reply_to'], $body['variables'] );
        }

        $seq                        = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
        $seq['templates'][ $alias ] = $have;
        $seq['draft']               = array_values( array_diff( $seq['draft'], array( $alias ) ) );
        Affiliate_Theme_Theme_save_sequence( $index, $seq );
        ++$count;
    }

    Affiliate_Theme_Theme_setup_unlock( $token );

    return array(
        'type'    => 'success',
        'message' => sprintf( 'The emails of <strong>%s</strong> are back to the theme&#8217;s copy.', esc_html( $label ) ),
        'count'   => $count,
    );
}

/**
 * Handle Reset these emails to the theme's copy. Its checkbox makes the
 * buyer confirm it, with or without JavaScript.
 *
 * @return void
 */
function Affiliate_Theme_Theme_sequence_reset_handler() {
    Affiliate_Theme_Theme_check_action( 'affiliate-theme_sequence_reset' );

    $index = Affiliate_Theme_Theme_sequence_from_post();

    if ( empty( $_POST['confirm'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by Affiliate_Theme_Theme_check_action().
        Affiliate_Theme_Theme_set_notice( 'Nothing was reset. Tick <strong>Replace my edits in Resend</strong> to reset these emails.', 'error' );
        Affiliate_Theme_Theme_back_to_settings( 'affiliate-theme-sequences' );
    }

    $check = Affiliate_Theme_Theme_check_key();

    if ( 'ok' !== $check['status'] ) {
        Affiliate_Theme_Theme_set_notice( esc_html( $check['message'] ), 'error' );
        Affiliate_Theme_Theme_back_to_settings( 'affiliate-theme-sequences' );
    }

    $notice = Affiliate_Theme_Theme_sequence_reset( $index );

    if ( 'error' === $notice['type'] ) {
        Affiliate_Theme_Theme_set_notice( $notice['message'], 'error' );
        Affiliate_Theme_Theme_back_to_settings( 'affiliate-theme-sequences' );
    }

    // A run makes any template that was missing, and re-points the
    // automation when one was made again.
    $result = Affiliate_Theme_Theme_setup_run_all();

    if ( '' === $result['error'] ) {
        Affiliate_Theme_Theme_set_notice( $notice['message'] . ' ' . $result['notice']['message'], $result['notice']['type'] );
    }

    Affiliate_Theme_Theme_back_to_settings( 'affiliate-theme-sequences' );
}
add_action( 'admin_post_affiliate-theme_sequence_reset', 'Affiliate_Theme_Theme_sequence_reset_handler' );

/* -------------------------------------------------------------------------
 * Your email sequences
 * ---------------------------------------------------------------------- */

/**
 * Read each automation's status from Resend on a load of the settings page,
 * so an automation turned off or deleted in Resend shows as such, and its
 * form stops.
 *
 * It reads every page of GET /automations, at most once in 10 minutes, and
 * not while a run holds the lock: the run's own changes would race it. It
 * changes only enabled, off and the IDs of automations that are gone.
 *
 * @return void
 */
function Affiliate_Theme_Theme_sequence_refresh() {
    $state = Affiliate_Theme_Theme_get_state();
    $any   = false;

    foreach ( array_keys( Affiliate_Theme_Theme_email_sequences() ) as $index ) {
        $seq = Affiliate_Theme_Theme_get_sequence( $state, $index );
        $any = $any || '' !== $seq['automation_id'];
    }

    if ( ! $any || Affiliate_Theme_Theme_setup_locked() ) {
        return;
    }

    $cache_key = 'affiliate-theme_resend_automations_' . md5( (int) get_option( AFFILIATE_THEME_CACHE_GEN, 0 ) . '|' . $state['key_fp'] );

    if ( get_transient( $cache_key ) ) {
        return;
    }

    $items = Affiliate_Theme_Theme_resend_list( '/automations' );

    if ( is_wp_error( $items ) ) {
        Affiliate_Theme_Theme_resend_log( $items->get_error_data() );
        return;
    }

    set_transient( $cache_key, 1, 10 * MINUTE_IN_SECONDS );

    $state = Affiliate_Theme_Theme_get_state();

    foreach ( array_keys( Affiliate_Theme_Theme_email_sequences() ) as $index ) {
        $seq = Affiliate_Theme_Theme_get_sequence( $state, $index );

        if ( '' !== $seq['automation_id'] ) {
            $state['sequences'][ $index ] = Affiliate_Theme_Theme_sequence_reconcile( $seq, Affiliate_Theme_Theme_setup_find( $items, $seq['automation_id'], 'id', $seq['automation_id'] ) );
        }
    }

    Affiliate_Theme_Theme_update_state( $state );
}

/**
 * Give a landing page's status, and one line about it. No call to Resend.
 *
 * In this order: off, setting up (a run holds the lock and has steps left
 * here), not set up (no automation), needs update (something in Resend is
 * out of date, or a template has an unpublished edit), waiting (for what
 * Affiliate_Theme_Theme_sequence_missing() gives), live.
 *
 * @param int        $index The landing page number, 1 to 3.
 * @param array|null $plan  From Affiliate_Theme_Theme_setup_plan() with
 *                          domain and read tried, or null to plan here.
 * @return array status and line (HTML, with <strong> at most).
 */
function Affiliate_Theme_Theme_sequence_status( $index, $plan = null ) {
    $seq  = Affiliate_Theme_Theme_get_sequence( Affiliate_Theme_Theme_get_state(), $index );
    $plan = null === $plan ? Affiliate_Theme_Theme_setup_plan( array( 'domain', 'read' ) ) : $plan;

    $status = static function ( $status, $line ) {
        return array(
            'status' => $status,
            'line'   => $line,
        );
    };

    if ( $seq['off'] ) {
        return $status( 'off', 'Off. New sign-ups on this page get no emails.' . ( 'resend' === $seq['off_by'] ? ' It was turned off in Resend.' : '' ) );
    }

    $own    = 0;
    $update = 0;

    foreach ( $plan as $step ) {
        if ( $step['seq'] === $index ) {
            ++$own;
            $update += 0 === strpos( $step['id'], 'enable:' ) || 0 === strpos( $step['id'], 'disable:' ) ? 0 : 1;
        }
    }

    if ( $own && Affiliate_Theme_Theme_setup_locked() ) {
        return $status( 'setting up', 'The theme is setting these emails up now.' );
    }

    $error = ! empty( $seq['error']['message'] ) ? ' ' . $seq['error']['message'] : '';

    if ( '' === $seq['automation_id'] ) {
        return $status( 'not set up', ( '' !== $error ? 'The theme could not set these emails up.' : 'These emails are not in Resend yet.' ) . $error );
    }

    if ( $update || $seq['draft'] ) {
        $lines = array();

        if ( $update ) {
            $lines[] = 'Some of these emails or their automation are out of date in Resend.';
        }

        if ( $seq['draft'] ) {
            $numbers = array();

            foreach ( $seq['draft'] as $alias ) {
                $numbers[] = (int) substr( $alias, -2 );
            }

            sort( $numbers );

            $lines[] = sprintf(
                '%s %s %s in Resend that %s not published. Publish or discard %s there, then save these settings.',
                1 === count( $numbers ) ? 'Email' : 'Emails',
                Affiliate_Theme_Theme_list_words( $numbers ),
                1 === count( $numbers ) ? 'has an edit' : 'have edits',
                1 === count( $numbers ) ? 'is' : 'are',
                1 === count( $numbers ) ? 'it' : 'them'
            );
        }

        if ( $seq['enabled'] ) {
            $lines[] = 'New sign-ups still get these emails.';
        }

        return $status( 'needs update', implode( ' ', $lines ) . $error );
    }

    $missing = Affiliate_Theme_Theme_sequence_missing( $index );

    if ( $missing ) {
        return $status( 'waiting', 'Waiting for: ' . esc_html( Affiliate_Theme_Theme_list_words( $missing ) ) . '.' . $error );
    }

    if ( $seq['enabled'] ) {
        return $status( 'live', 'Live. New sign-ups on this page get these emails.' );
    }

    return $status( 'needs update', 'Ready, but not turned on yet. Click <strong>Finish setting up emails</strong>.' . $error );
}

/**
 * Give how long a sequence runs, in days, from its waits.
 *
 * @param array $emails The emails of one landing page.
 * @return int
 */
function Affiliate_Theme_Theme_sequence_days( $emails ) {
    $days = 0;

    foreach ( $emails as $email ) {
        if ( preg_match( '/^(\d+)\s+days?$/', $email['wait'], $match ) ) {
            $days += (int) $match[1];
        }
    }

    return $days;
}

/**
 * Print the "Your email sequences" section of the settings page.
 *
 * Its panel starts a setup run by itself right after a save, and on a load
 * where all that is left is to turn sequences on: the domain was just
 * verified. A sequence that is off never gets that step. The panel carries
 * the admin-ajax URL and a nonce, never the key.
 *
 * @return void
 */
function Affiliate_Theme_Theme_sequences_render_section() {
    echo '<h2 id="affiliate-theme-sequences">Your email sequences</h2>';

    $check = Affiliate_Theme_Theme_check_key();

    if ( 'ok' !== $check['status'] ) {
        echo '<p>Save a Resend API key with Full access first.</p>';
        return;
    }

    Affiliate_Theme_Theme_sequence_refresh();

    echo '<p>The theme sets these up in your Resend account, under Templates and Automations. Their names start with Affiliate Theme.</p>';

    $state     = Affiliate_Theme_Theme_get_state();
    $plan      = Affiliate_Theme_Theme_setup_plan( array( 'domain', 'read' ) );
    $autostart = false;

    if ( ! Affiliate_Theme_Theme_setup_locked() ) {
        if ( ! empty( $_GET['settings-updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only reads that a save happened.
            $autostart = true;
        } elseif ( $plan ) {
            $autostart = true;

            foreach ( $plan as $step ) {
                $seq       = Affiliate_Theme_Theme_get_sequence( $state, $step['seq'] );
                $autostart = $autostart && 0 === strpos( $step['id'], 'enable:' ) && empty( $seq['error'] );
            }
        }
    }

    $html = array( 'strong' => array() );
    $box  = '<label style="display:block;margin:0 0 .25em"><input type="checkbox" name="confirm" value="1" /> Replace my edits in Resend</label>';

    printf(
        '<div id="affiliate-theme-setup" data-ajax="%s" data-nonce="%s" data-autostart="%s">',
        esc_url( admin_url( 'admin-ajax.php' ) ),
        esc_attr( wp_create_nonce( 'affiliate-theme_setup' ) ),
        $autostart ? '1' : '0'
    );
    echo '<p class="affiliate-theme-setup__status" aria-live="polite"></p>';
    echo '<table class="widefat striped" style="max-width:72rem"><thead><tr><th scope="col">Landing page</th><th scope="col">Emails</th><th scope="col">Status</th><th scope="col">Actions</th></tr></thead><tbody>';

    foreach ( Affiliate_Theme_Theme_email_sequences() as $index => $emails ) {
        $seq    = Affiliate_Theme_Theme_get_sequence( $state, $index );
        $status = Affiliate_Theme_Theme_sequence_status( $index, $plan );
        $color  = array(
            'live'         => '#008a20',
            'needs update' => '#996800',
            'off'          => '#b32d2e',
        );

        // Newer copy in the theme than in a template it made or reset.
        $newer = false;

        foreach ( $emails as $k => $email ) {
            $alias = Affiliate_Theme_Theme_template_alias( $index, $k + 1 );

            if ( ! isset( $seq['templates'][ $alias ]['copy_hash'] ) ) {
                continue;
            }

            $render = Affiliate_Theme_Theme_render_email( $index, $email );
            $newer  = $newer || ( ! is_wp_error( $render ) && Affiliate_Theme_Theme_copy_hash( $email['subject'], $render ) !== $seq['templates'][ $alias ]['copy_hash'] );
        }

        echo '<tr>';
        printf( '<td><strong>%s</strong></td>', esc_html( Affiliate_Theme_Theme_sequence_label( $index ) ) );
        printf( '<td>%d emails over %d days</td>', count( $emails ), (int) Affiliate_Theme_Theme_sequence_days( $emails ) );
        printf(
            '<td><strong%s>%s</strong><br />%s%s<br /><span data-affiliate-theme-progress="%d"></span></td>',
            isset( $color[ $status['status'] ] ) ? ' style="color:' . esc_attr( $color[ $status['status'] ] ) . '"' : '',
            esc_html( ucfirst( $status['status'] ) ),
            wp_kses( $status['line'], $html ),
            $newer ? ' The theme has newer copy for these emails. Reset to use it.' : '',
            (int) $index
        );
        echo '<td>';

        if ( $seq['off'] ) {
            Affiliate_Theme_Theme_action_form( 'affiliate-theme_sequence_on', 'Turn on', array( 'sequence' => $index ) );
        } else {
            Affiliate_Theme_Theme_action_form( 'affiliate-theme_sequence_off', 'Turn off', array( 'sequence' => $index ) );
        }

        if ( Affiliate_Theme_Theme_sequence_ids( $seq ) ) {
            Affiliate_Theme_Theme_action_form( 'affiliate-theme_sequence_reset', 'Reset these emails to the theme&#8217;s copy', array( 'sequence' => $index ), false, $box );
        }

        if ( '' !== $seq['automation_id'] ) {
            printf(
                '<p style="margin:0"><a href="%s" target="_blank" rel="noopener">Open in Resend</a></p>',
                esc_url( 'https://resend.com/automations/' . rawurlencode( $seq['automation_id'] ) . '/editor' )
            );
        }

        echo '</td></tr>';
    }

    echo '</tbody></table><p></p>';

    if ( $plan ) {
        Affiliate_Theme_Theme_action_form( 'affiliate-theme_setup_finish', 'Finish setting up emails', array(), true, '', 'data-affiliate-theme-setup' );
    }

    echo '<p>Turning a sequence off also stops the remaining emails of everyone partway through it.</p>';
    echo '</div>';
}

/**
 * Show one line on the other Settings screens while the emails need the
 * buyer: the key is missing or refused, or a sequence is waiting or needs
 * an update. It makes no call to Resend beyond the cached key check.
 *
 * @return void
 */
function Affiliate_Theme_Theme_sequences_admin_notice() {
    if ( ! current_user_can( 'manage_options' ) || ! function_exists( 'get_current_screen' ) ) {
        return;
    }

    $screen = get_current_screen();

    if ( ! $screen || 'options-general' !== $screen->parent_base || 'settings_page_affiliate-theme-settings' === $screen->id ) {
        return;
    }

    $check = Affiliate_Theme_Theme_check_key();
    $line  = '';

    if ( in_array( $check['status'], array( 'missing', 'sending_only', 'invalid' ), true ) ) {
        $line = 'Affiliate Theme sends no emails until it has a Resend API key with Full access.';
    } elseif ( 'ok' === $check['status'] ) {
        $plan = Affiliate_Theme_Theme_setup_plan( array( 'domain', 'read' ) );

        foreach ( array_keys( Affiliate_Theme_Theme_email_sequences() ) as $index ) {
            $status = Affiliate_Theme_Theme_sequence_status( $index, $plan );

            if ( in_array( $status['status'], array( 'waiting', 'needs update' ), true ) ) {
                $line = 'Some of the Affiliate Theme email sequences are waiting or need an update.';
                break;
            }
        }
    }

    if ( '' === $line ) {
        return;
    }

    printf(
        '<div class="notice notice-warning"><p>%s <a href="%s">Open Affiliate Theme Settings</a></p></div>',
        esc_html( $line ),
        esc_url( admin_url( 'options-general.php?page=affiliate-theme-settings#affiliate-theme-sequences' ) )
    );
}
add_action( 'admin_notices', 'Affiliate_Theme_Theme_sequences_admin_notice' );

/* -------------------------------------------------------------------------
 * The theme's notices on the settings page
 * ---------------------------------------------------------------------- */

/**
 * Keep a notice for the next load of the settings page.
 *
 * @param string $message The message. It may hold <strong> and <code>.
 * @param string $type    success, warning, error or info.
 * @return void
 */
function Affiliate_Theme_Theme_set_notice( $message, $type = 'success' ) {
    set_transient(
        'affiliate-theme_notice_' . get_current_user_id(),
        array(
            'message' => $message,
            'type'    => $type,
        ),
        MINUTE_IN_SECONDS
    );
}

/**
 * Send the browser back to a section of the settings page.
 *
 * @param string $anchor The section id.
 * @return void
 */
function Affiliate_Theme_Theme_back_to_settings( $anchor ) {
    wp_safe_redirect( admin_url( 'options-general.php?page=affiliate-theme-settings' ) . '#' . $anchor );
    exit;
}

/**
 * Check an action from the settings page: the right person and a nonce.
 *
 * @param string $action The admin-post action.
 * @return void
 */
function Affiliate_Theme_Theme_check_action( $action ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Sorry, you are not allowed to do that.', 403 );
    }

    check_admin_referer( $action );

    if ( function_exists( 'set_time_limit' ) ) {
        set_time_limit( 120 ); // phpcs:ignore Squiz.PHP.DiscouragedFunctions.Discouraged -- An action can make many calls to Resend.
    }
}

/**
 * Print a small form that runs one action of the settings page.
 *
 * These forms sit outside the settings form, so nothing is nested.
 *
 * @param string $action  The admin-post action.
 * @param string $label   The button text.
 * @param array  $fields  Hidden fields, name => value.
 * @param bool   $primary True for a primary button.
 * @param string $before  Markup to print before the button, such as an input.
 * @param string $marker  The attribute that admin-settings.js looks for:
 *                        data-affiliate-theme-busy marks the button busy
 *                        while the form is sent, data-affiliate-theme-setup
 *                        runs the setup panel in its place.
 * @return void
 */
function Affiliate_Theme_Theme_action_form( $action, $label, $fields = array(), $primary = false, $before = '', $marker = 'data-affiliate-theme-busy' ) {
    echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:0 .5em .5em 0" ' . esc_attr( $marker ) . '>';
    printf( '<input type="hidden" name="action" value="%s" />', esc_attr( $action ) );
    wp_nonce_field( $action );

    foreach ( $fields as $name => $value ) {
        printf( '<input type="hidden" name="%s" value="%s" />', esc_attr( $name ), esc_attr( $value ) );
    }

    echo $before; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built and escaped by the caller.
    printf( '<button type="submit" class="button%s">%s</button>', $primary ? ' button-primary' : '', esc_html( $label ) );
    echo '</form>';
}

/**
 * Print the theme's own notice at the top of the settings page.
 *
 * An action of the settings page keeps it for a minute with
 * Affiliate_Theme_Theme_set_notice() and sends the browser back here.
 * WordPress knows nothing of these notices, so it does not print them, and
 * this does. The settings errors are WordPress's and are never printed here.
 *
 * @return void
 */
function Affiliate_Theme_Theme_resend_render_notices() {
    $key    = 'affiliate-theme_notice_' . get_current_user_id();
    $notice = get_transient( $key );

    if ( ! is_array( $notice ) || empty( $notice['message'] ) ) {
        return;
    }

    delete_transient( $key );

    printf(
        '<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
        esc_attr( in_array( $notice['type'], array( 'success', 'warning', 'error', 'info' ), true ) ? $notice['type'] : 'info' ),
        wp_kses(
            $notice['message'],
            array(
                'strong' => array(),
                'code'   => array(),
            )
        )
    );
}
