<?php
/**
 * Affiliate Theme — the legal pages.
 *
 * Contains the legal page list, the four legal patterns, the optional
 * analytics and advertising add-on to the privacy pattern, the legal half of
 * the activation seeder, and the legal links block. The add-on is a
 * pattern only. It is never seeded and never linked.
 *
 * The text here is a starting template for the buyer to review and
 * complete. It is not legal advice. That caveat belongs on the settings
 * page, never in the page content that a visitor reads.
 *
 * @package affiliate-theme
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * The legal pages
 *
 * One function makes the markup. The pattern files echo it and the
 * activation seeder copies it. Thus the two can never disagree.
 * ---------------------------------------------------------------------- */

/**
 * Give the list of legal pages that the theme makes.
 *
 * The privacy slug is privacy rather than privacy-policy on purpose.
 * WordPress core parks its own auto-made draft at privacy-policy, so the
 * two never collide.
 *
 * @return array
 */
function Affiliate_Theme_Theme_legal_pages() {
    return array(
        'privacy'    => array(
            'slug'  => 'privacy',
            'title' => 'Privacy Policy',
        ),
        'terms'      => array(
            'slug'  => 'terms-of-service',
            'title' => 'Terms of Service',
        ),
        'disclaimer' => array(
            'slug'  => 'earnings-disclaimer',
            'title' => 'Earnings Disclaimer',
        ),
        'disclosure' => array(
            'slug'  => 'affiliate-disclosure',
            'title' => 'Affiliate Disclosure',
        ),
    );
}

/**
 * Make the block markup of one legal page.
 *
 * The markup carries no inline style at all. The type then comes from the
 * element styles in theme.json, so the frozen post_content holds no literal
 * that can go stale and no var:preset reference that a later redefinition
 * could break.
 *
 * @param string $key A key of Affiliate_Theme_Theme_legal_pages(), or
 *                    privacy-tracking for the add-on, which is deliberately
 *                    not in that list.
 * @return string
 */
function Affiliate_Theme_Theme_legal_pattern( $key ) {
    switch ( (string) $key ) {
        case 'privacy-tracking':
            return Affiliate_Theme_Theme_legal_pattern_privacy_tracking();

        case 'terms':
            return Affiliate_Theme_Theme_legal_pattern_terms();

        case 'disclaimer':
            return Affiliate_Theme_Theme_legal_pattern_disclaimer();

        case 'disclosure':
            return Affiliate_Theme_Theme_legal_pattern_disclosure();

        default:
            return Affiliate_Theme_Theme_legal_pattern_privacy();
    }
}

/* -------------------------------------------------------------------------
 * The legal seeder
 *
 * This half of the seeder is not hooked and never touches the seed flag.
 * Affiliate_Theme_Theme_seed_pages() is the one hooked entry point and
 * calls this before it writes the flag. Two hooked handlers sharing one
 * flag would race: the first would set it and the second would return
 * early, silently seeding nothing.
 * ---------------------------------------------------------------------- */

/**
 * Make the four legal pages as drafts.
 *
 * The pages take no page template, which leaves them on templates/page.html
 * with the header, the title, and the footer.
 *
 * @return array The page IDs that were made or adopted.
 */
function Affiliate_Theme_Theme_seed_legal_pages() {
    $page_ids = array();

    foreach ( Affiliate_Theme_Theme_legal_pages() as $key => $page ) {
        $page_id = Affiliate_Theme_Theme_seed_page(
            $page['slug'],
            $page['title'],
            Affiliate_Theme_Theme_legal_pattern( $key )
        );

        if ( $page_id ) {
            $page_ids[] = $page_id;
        }
    }

    return $page_ids;
}

/* -------------------------------------------------------------------------
 * The legal links block
 * ---------------------------------------------------------------------- */

/**
 * Give the published legal pages as links.
 *
 * A draft is never linked. That is what makes the footer links appear on
 * publication and not before.
 *
 * @return array A list of arrays with the keys title and url.
 */
function Affiliate_Theme_Theme_legal_links() {
    $settings = Affiliate_Theme_Theme_get_settings();
    $ids      = isset( $settings['legal_page_ids'] ) && is_array( $settings['legal_page_ids'] )
        ? $settings['legal_page_ids']
        : array();

    // The option is gone or was never written. Find the pages by slug.
    if ( empty( $ids ) ) {
        foreach ( Affiliate_Theme_Theme_legal_pages() as $page ) {
            $found = get_page_by_path( $page['slug'], OBJECT, 'page' );

            if ( $found instanceof WP_Post ) {
                $ids[] = (int) $found->ID;
            }
        }
    }

    $links = array();

    foreach ( $ids as $id ) {
        $page = get_post( (int) $id );

        if ( ! $page instanceof WP_Post || 'page' !== $page->post_type || 'publish' !== $page->post_status ) {
            continue;
        }

        $url = get_permalink( $page );

        if ( ! $url ) {
            continue;
        }

        // The buyer may rename the page. Read the title back every time.
        $links[] = array(
            'title' => get_the_title( $page ),
            'url'   => $url,
        );
    }

    return $links;
}

/**
 * Tell if the current render is the editor asking for a preview.
 *
 * ServerSideRender reaches render.php over the REST API. A visitor never
 * does, so this separates the editor placeholder from the front end.
 *
 * @return bool
 */
function Affiliate_Theme_Theme_is_editor_render() {
    return ( defined( 'REST_REQUEST' ) && REST_REQUEST );
}

/**
 * Register the block script and then the block.
 *
 * The script must have its handle before register_block_type() runs,
 * because block.json names the handle.
 *
 * @return void
 */
function Affiliate_Theme_Theme_register_legal_links_block() {
    wp_register_script(
        'affiliate-theme-legal-links-editor',
        get_theme_file_uri( '/blocks/legal-links/index.js' ),
        array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ),
        AFFILIATE_THEME_VERSION,
        true
    );

    register_block_type( get_theme_file_path( '/blocks/legal-links' ) );
}
add_action( 'init', 'Affiliate_Theme_Theme_register_legal_links_block' );

/* -------------------------------------------------------------------------
 * The legal patterns
 *
 * Every statement here must be true of a site running the theme as it
 * ships: WordPress, the opt-in form, an email service provider, open and
 * click tracking in its emails, and no analytics, advertising pixels or
 * tracking cookies for visitors. The copy is frozen into post_content, so it names no threshold, penalty, date or count that
 * could go stale, and it carries no links. Sibling pages are named by
 * title and outside sites as plain text.
 * ---------------------------------------------------------------------- */

/**
 * The privacy page.
 *
 * @return string
 */
function Affiliate_Theme_Theme_legal_pattern_privacy() {
    return <<<'MARKUP'
<!-- wp:paragraph -->
<p>Effective date: [Month Day, Year]</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Who We Are</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This policy explains what personal information [Your Business Name] collects through [yoursite.com], how we use it, who we share it with, and the choices and rights you have. The site is operated by [Your Business Name], [Your Mailing Address]. You can reach us at [you@example.com].</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What We Collect</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We collect personal information from three sources: what you give us, what our web host records automatically when you visit, and whether you open our emails and click their links.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><strong>Information you give us.</strong> The email address you type into a form on this site, and your first name where the form asks for it.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Information collected automatically.</strong> Our web host keeps standard server logs, which record your IP address, your browser type, the page you requested and the time of the request.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Cookies.</strong> This site sets no cookies for ordinary visitors. WordPress, the software the site runs on, sets cookies only for people who log in or leave a comment, to keep them logged in and to remember their comment details.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>We do not collect sensitive personal information, such as health, financial account, government identifier or precise location data. This site does not take payments and does not handle payment card details.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">How We Use It</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>To send you the material you asked for.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>To send you follow-up marketing emails about related topics, resources and offers. You can unsubscribe at any time.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>To see which of our emails are read and which of their links are clicked, so we can improve our service.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>To run, maintain and secure the site, including preventing abuse of our forms.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>To comply with the law and respond to lawful requests.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Who We Share It With</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We share personal information only with:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><strong>Our email service provider.</strong> When you submit a form, your email address and first name are sent to our email service provider, which stores our list and delivers our emails. It acts as our processor: it handles the information on our behalf and under our instructions. Our emails contain standard open tracking technology: a small image that loads when you open one of our emails and tells our email service provider that it was opened. We use this to see which of our emails are read. You can block it by turning off images in your email app. Links in our emails first pass through our email service provider, which records the click and then sends you on to the page the link names.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>Our web host,</strong> which stores the site and its server logs on our behalf.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">We Do Not Sell Or Share Your Information</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>We do not sell your personal information and we do not share it for cross-context behavioral advertising.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Global Privacy Control</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If your browser sends a Global Privacy Control (GPC) signal, we treat it as a valid request to opt out of the sale and sharing of your personal information and of targeted advertising, for that browser. You do not need to do anything else.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Do Not Track</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Some browsers send a "Do Not Track" signal. This site does not track visitors across other websites, and no third party collects information about your activity on other websites through this one. A Do Not Track signal therefore changes nothing about how the site works or what it collects.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Your Rights</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Wherever you live, you may ask us to:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>confirm whether we hold personal information about you, and tell you what it is and how we use it;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>correct information that is inaccurate;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>delete your information;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>give you a copy of your information in a portable format;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>stop any sale or sharing of your information, any targeted advertising, and any profiling that has legal or similarly significant effects on you;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>reconsider a decision to refuse your request, as described under Appeals.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>To make a request, write to [you@example.com] and tell us what you would like us to do. You do not need an account with us. We may need to confirm your identity before we act, usually by asking you to reply from the email address the request is about.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>You may use an authorized agent to make a request for you. We may ask the agent for proof that you gave them permission, and ask you to confirm your identity directly.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>We will not treat you differently, charge you a different price or give you a lower quality of service because you used any of these rights. We respond to every request within 45 days of receiving it.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Appeals</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If we decline your request, in whole or in part, we will tell you why. You can appeal by replying to our decision, or by writing to [you@example.com] with "Appeal" in the subject line. We will tell you the outcome of your appeal and the reasons for it. If we deny your appeal, you may contact the attorney general of your state.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">California Shine The Light</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>California Civil Code §1798.83 lets California residents ask which personal information a business has disclosed to third parties for those third parties' own direct marketing purposes. We do not disclose personal information to third parties for their own direct marketing purposes.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Our Emails</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Every marketing email we send includes an unsubscribe link and our postal address. When you unsubscribe, we stop sending you marketing email promptly, and in any case within 10 business days. We will not email you again unless you sign up again.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">How Long We Keep It</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We keep your email address and name for as long as you stay subscribed. If you unsubscribe, we keep a minimal suppression record, your email address and the fact that you unsubscribed, so that we do not email you again by mistake. Server logs are kept for the period our web host sets.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Security</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We use reasonable safeguards to protect personal information, and we use providers that do the same. No method of sending or storing information over the internet is perfectly secure, so we cannot promise absolute security.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Where Your Information Is Processed</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Our email service provider and our web host may store and process your information outside your state or country. Wherever they do, this policy still governs how we use it.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Children</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This site is intended for adults aged 18 or older. It is not directed to children under 13, and we do not knowingly collect personal information from anyone under 16. If you believe someone under 16 has given us their information, write to [you@example.com] and we will delete it.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Other Sites And Affiliate Links</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This site links to products and services operated by other companies, and some of those links are affiliate links, as our Affiliate Disclosure explains. Once you follow a link you are on another site, and its own privacy policy applies, not this one. Please read it before you give that site any information.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Changes To This Policy</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We may update this policy as the site or our practices change. When we do, we will change the effective date at the top of this page. If we make a material change to how we use the information of people on our email list, we will also tell subscribers by email before the change takes effect.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Contact Us</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Questions about this policy, or a request about your information? Write to [Your Business Name] at [you@example.com], or by post at [Your Mailing Address].</p>
<!-- /wp:paragraph -->
MARKUP;
}

/**
 * The terms of service page.
 *
 * There is no arbitration clause and no class action waiver. Neither holds
 * under browsewrap assent, and the opt-in form has no clickwrap line yet.
 *
 * @return string
 */
function Affiliate_Theme_Theme_legal_pattern_terms() {
    return <<<'MARKUP'
<!-- wp:paragraph -->
<p>Effective date: [Month Day, Year]</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Acceptance Of These Terms</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>These terms govern your use of [yoursite.com], which is operated by [Your Business Name]. By using the site you agree to them, and by joining our email list or downloading anything we offer you confirm that you have read and agree to them. If you do not agree, please do not use the site.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Who May Use The Site</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>You must be at least 18 years old, or the age of majority where you live, and able to enter into a binding agreement. If you use the site for a company, you confirm that you have authority to accept these terms on its behalf.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Other Documents</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Our Privacy Policy, our Earnings Disclaimer and our Affiliate Disclosure, each published on this site, form part of these terms. Please read them too.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Permitted Use</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>You may read this site and use what we publish for your own personal or internal business purposes. You may not:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>copy, resell, republish or redistribute our material as your own;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>use the site for anything unlawful, deceptive or harmful;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>scrape, harvest or bulk-download the site by automated means;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>attempt to break, overload or gain unauthorized access to the site or its systems;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>submit false information, or somebody else's email address, to our forms.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Our Content</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Unless we say otherwise, everything on this site, including text, graphics, logos, layout and downloads, belongs to [Your Business Name] or is used with permission, and is protected by copyright and trademark law. We grant you a limited, personal, non-exclusive, non-transferable and revocable license to view and use it as described above. All rights not expressly granted are reserved.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Anything You Send Us</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If you send us a comment, a testimonial, a review, a question or any other material, you confirm that it is yours to send, and you give us permission to use and publish it in connection with our business. We treat anything you send as non-confidential unless we have agreed otherwise in writing.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Any testimonial or review you give us must reflect your own genuine experience and honest opinion.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Our Email List</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If you join our email list, we will send you the material you asked for and follow-up marketing emails. You can unsubscribe at any time with the link in any of our emails. Our Privacy Policy explains how we handle your information.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Third-Party Products And Links</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Some links on this site and in our emails lead to products and services sold by other companies, and we earn a commission when you buy through them. Our Affiliate Disclosure explains this. We are not the seller and we are not a party to your purchase. The seller's own terms, pricing, refund policy and support apply, and any dispute about a third-party product is between you and the seller.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">No Professional Advice And No Guaranteed Results</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>What we publish is for general information and education. It is not financial, investment, legal, tax or medical advice. We do not promise any particular result from using it, including any income. Our Earnings Disclaimer explains this in full.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Disclaimer Of Warranties</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>The site and everything on it are provided "as is" and "as available", without warranty of any kind, whether express or implied, including any implied warranty of merchantability, fitness for a particular purpose or non-infringement. We do not promise that the site will be uninterrupted, secure or error free, or that the information on it is complete, accurate or current.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Limitation Of Liability</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>To the fullest extent the law allows, [Your Business Name] will not be liable for any indirect, incidental, special, consequential or punitive damages, or for any loss of profits, revenue, data or goodwill, arising out of or relating to your use of this site or anything you obtain through it. Our total liability for any claim arising out of or relating to these terms or the site is limited to the greater of the amount you paid us in the 12 months before the claim arose and US $100.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Some places do not allow certain warranties to be excluded or liability to be limited. Where the law does not allow it, these exclusions and limits apply to you only as far as the law permits.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Indemnification</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>You agree to defend, indemnify and hold harmless [Your Business Name] from any claim, loss, liability or expense, including reasonable legal fees, that arises from your misuse of the site or from your breach of these terms.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Resolving Disputes</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If you have a dispute with us, please contact us first at [you@example.com] and describe it. We will both try in good faith to resolve it informally. If it is not resolved within 30 days, either of us may take it to court as set out under Governing Law And Venue.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Governing Law And Venue</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>These terms are governed by the laws of [Your State/Country], without regard to its conflict of law rules, and the courts of [Your State/Country] have exclusive jurisdiction over any dispute arising from them.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Changes And Termination</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We may change these terms, or change, suspend or withdraw the site, at any time. A change to these terms applies from the effective date shown at the top of this page, and does not apply to a dispute that arose before that date. We may suspend or end your access to the site if you break these terms.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">General</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If any part of these terms is found unenforceable, the rest remains in effect. If we do not enforce a right, we have not waived it. These terms, together with the documents listed under Other Documents, are the entire agreement between you and us about the site. You may not transfer your rights under these terms. We may transfer ours, for example if the business is sold.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Contact Us</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Questions about these terms? Write to [Your Business Name] at [you@example.com], or by post at [Your Mailing Address].</p>
<!-- /wp:paragraph -->
MARKUP;
}

/**
 * The earnings disclaimer page.
 *
 * @return string
 */
function Affiliate_Theme_Theme_legal_pattern_disclaimer() {
    return <<<'MARKUP'
<!-- wp:paragraph -->
<p>Effective date: [Month Day, Year]</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What This Page Covers</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>[Your Business Name] publishes material about affiliate marketing and online business at [yoursite.com]. This page explains what we do and do not promise about the results you might get. It applies to everything on this site, to every email we send, to any video or other material we publish, and to any product we recommend.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">No Guarantee Of Income</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Nothing we publish is a promise of earnings.</strong> We do not claim that you will make any money at all, that you will earn a particular amount, or that you will earn anything within a particular period of time.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">We Do Not Claim Typical Results</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Nothing on this site represents what a typical person earns. Most people who buy information or programs about making money online earn little or nothing from them. Expect your own results to be closer to that than to any exceptional result, until your own numbers show otherwise.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>If we ever share a specific result, ours or anyone else's, we will say alongside it what people generally achieve.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Your Results Depend On You</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Every business outcome depends on factors we neither control nor know about, including:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>the time, effort and consistency you put in;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>your existing skills, experience and audience;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>the money you have available to invest and to lose;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>the market you enter, the competition in it and general economic conditions;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>plain luck and timing.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Because of that, we cannot and do not predict what will happen for you.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Forward-Looking Statements</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Where we describe what might happen, what could be achieved or what the future may hold, those are forward-looking statements. They express an opinion about what is possible, they are not a promise of performance, and actual results often differ from them.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Testimonials And Examples</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Any testimonial we publish comes from a real person and describes their genuine experience in their own circumstances.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>We do not pay or reward anyone for a positive testimonial or review.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>If the person giving a testimonial has a material connection to us, such as being paid, receiving a free product, or being a friend, relative or business partner, we disclose that connection next to the testimonial.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>A testimonial describes one person's result. It is not a promise that you will get the same result.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Third-Party Products</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The products we recommend are made and sold by other companies. Any claim a product's creator makes about it, including about earnings, is theirs and not ours. Do your own research before you buy, and read the seller's terms and refund policy.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">This Is Not Professional Advice</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The material here is educational. It is not financial, investment, legal, tax or accounting advice, and it is not tailored to your circumstances. Before you act on anything you read here, take advice from a qualified professional who knows your situation. You are responsible for your own business and tax compliance.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Your Decision, Your Risk</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Every business carries risk, including the risk of losing the money and time you put in. What you do with the material here is your decision, and the outcome of that decision is yours. Our Terms of Service explain the limits of our liability.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Contact Us</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Questions about this disclaimer? Write to [Your Business Name] at [you@example.com], or by post at [Your Mailing Address].</p>
<!-- /wp:paragraph -->
MARKUP;
}

/**
 * The affiliate disclosure page.
 *
 * @return string
 */
function Affiliate_Theme_Theme_legal_pattern_disclosure() {
    return <<<'MARKUP'
<!-- wp:paragraph -->
<p>Effective date: [Month Day, Year]</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Our Disclosure</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>We earn commissions from purchases made through links on this site and in our emails.</strong></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>[Your Business Name] operates [yoursite.com]. When you click a link to a product and then buy it, the seller may pay us a commission. We publish this page so that you know about our financial relationships before you decide how much weight to give what we say.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Material Connections</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Besides commissions, we may have other connections with the companies whose products we mention:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>bonuses or prizes for reaching sales targets;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>free or discounted products, or free access to them;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>business, family or personal relationships with a seller or product creator.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Where a connection like this applies to a particular product, we disclose it where we mention that product.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Where We Disclose</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This page is a summary. We also disclose our connections next to the links themselves, for example with "Paid link" or "I earn a commission if you buy through this link", and in any email that contains affiliate links. You should not have to visit this page to find out that we are paid.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">No Extra Cost To You</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A commission is paid by the seller out of the price it already charges. Buying through our link adds nothing to what you pay.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Our Opinions</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The recommendations and reviews we publish reflect our honest opinion. Commissions can influence which products we choose to feature and how prominently we feature them, so please weigh that when you read a recommendation here. Sellers do not write or approve our reviews.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">We Are Not The Seller</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>We do not sell the products we link to. The seller sets the price, the terms, the refund policy and the support, and any problem with a purchase is handled by them.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">No Guarantee Of Results</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A product working for someone else is not a promise that it will work for you. Please read our Earnings Disclaimer before you buy anything you find through this site.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">The Rules We Follow</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This disclosure is made in line with the United States Federal Trade Commission's Guides Concerning the Use of Endorsements and Testimonials in Advertising, 16 CFR Part 255.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Questions</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If you would like to know whether a particular link earns us a commission, just ask. Write to [Your Business Name] at [you@example.com], or by post at [Your Mailing Address].</p>
<!-- /wp:paragraph -->
MARKUP;
}

/**
 * The optional analytics and advertising section of the privacy page.
 *
 * This is never seeded. Affiliate_Theme_Theme_legal_pages() drives both the
 * seeder and the legal links, so this key stays out of it. The buyer
 * inserts the pattern into the Privacy Policy page after "Who We Share It With"
 * when they add analytics or advertising pixels, and deletes the "We Do Not
 * Sell Or Share Your Information" section, which its last paragraph
 * replaces. The settings screen says so. The content cannot.
 *
 * @return string
 */
function Affiliate_Theme_Theme_legal_pattern_privacy_tracking() {
    return <<<'MARKUP'
<!-- wp:heading -->
<h2 class="wp-block-heading">Analytics And Advertising</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This site uses cookies, pixels and similar technologies provided by analytics and advertising companies. They collect information about your device and browser, your browsing activity on this site, such as the pages you view and the links you click, and online identifiers such as cookie IDs and your IP address.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>We use this information to understand how the site is used, to measure how well our advertising works, and to show our ads to people who have visited the site. We make it available to two categories of recipient:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>analytics providers, which help us understand how the site is used;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>advertising networks, which help us show our ads and measure their results.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>The analytics and advertising providers listed below receive this information:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>[Provider Name]: measures visits and page views.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Your Choices</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Under the laws of some states, letting these providers collect this information may count as a "sale" or "sharing" of personal information, or as "targeted advertising". You can opt out in any of these ways:</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>turn on Global Privacy Control in your browser, which we honor as a valid request to opt out of sale, sharing and targeted advertising for that browser;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>block or delete cookies in your browser settings;</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>write to [you@example.com] and ask us to opt you out.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Sale And Sharing</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><strong>Other than through the analytics and advertising providers described above, we do not sell your personal information, share it for cross-context behavioral advertising, or use it for targeted advertising.</strong> We do not rent or trade our email list.</p>
<!-- /wp:paragraph -->
MARKUP;
}
