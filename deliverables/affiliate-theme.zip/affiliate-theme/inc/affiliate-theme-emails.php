<?php
/**
 * Affiliate Theme — the email sequences.
 *
 * Contains the email list of each landing page, the email renderer, the ZIP
 * builder, the download handler, and the "Your email sequences" section of
 * the settings page.
 *
 * Each landing page promises its subscribers something by email. These
 * emails keep that promise. The buyer adds each one to GetResponse as an
 * automation message, from its own ZIP file: Design message, then HTML
 * editor, then Upload from ZIP. GetResponse wants index.html at the root of
 * that ZIP, and 10 MB or less. The subject line and the preview text are
 * typed on the message screen, so READ-ME-FIRST.txt lists them.
 *
 * The emails link to the affiliate redirect URL, so the theme builds the
 * download on request from the saved settings. Only an administrator can
 * download it.
 *
 * @package affiliate-theme
 */

defined( 'ABSPATH' ) || exit;

const AFFILIATE_THEME_EMAIL_ACTION = 'affiliate-theme_email_zip';
const AFFILIATE_THEME_EMAIL_NOTICE = 'affiliate-theme-emails';

/* -------------------------------------------------------------------------
 * The email lists
 * ---------------------------------------------------------------------- */

/**
 * Give the emails of each landing page, in the order that they are sent.
 *
 * The keys match Affiliate_Theme_Theme_landing_pages(). For each email:
 *
 * - file:    its body in emails/landing-N/, without .html. Its ZIP file
 *            takes the same name.
 * - name:    the message name to type in GetResponse.
 * - subject: the subject line. Keep it to 60 characters or less, as
 *            GetResponse advises for mobile.
 * - preview: the preview text.
 * - wait:    the days to wait after the email before it. 0 sends the
 *            email as soon as the contact subscribes.
 * - attach:  optional. A file in the same folder that goes in the ZIP
 *            next to index.html, which links to it by its bare name.
 *            GetResponse does not host it, so READ-ME-FIRST.txt and the
 *            settings page tell the buyer to upload it to the Media
 *            Library and put its link in by hand.
 *
 * These strings go into READ-ME-FIRST.txt, which the buyer opens in a text
 * editor and copies from. Keep them plain ASCII.
 *
 * @return array
 */
function Affiliate_Theme_Theme_email_sequences() {
    return array(
        1 => array(
            array(
                'file'    => '01-one-page-plan',
                'name'    => 'Centered 1/5 - Your one-page plan',
                'subject' => 'Your one-page plan is inside',
                'preview' => 'The exact steps, all on one page. Save this email.',
                'wait'    => 0,
            ),
            array(
                'file'    => '02-offers-that-pay',
                'name'    => 'Centered 2/5 - The offers that pay the most',
                'subject' => 'The offers that pay the most for the least work',
                'preview' => 'Six checks to run before you promote anything.',
                'wait'    => 1,
            ),
            array(
                'file'    => '03-first-email',
                'name'    => 'Centered 3/5 - The first email, word for word',
                'subject' => 'The first email to send, word for word',
                'preview' => 'Copy it, fill in the brackets, and load it as email one.',
                'wait'    => 1,
            ),
            array(
                'file'    => '04-the-90-day-mistake',
                'name'    => 'Centered 4/5 - The 90-day mistake',
                'subject' => 'The mistake that costs new affiliates 90 days',
                'preview' => "It feels like progress. It's the opposite.",
                'wait'    => 1,
            ),
            array(
                'file'    => '05-autopilot',
                'name'    => 'Centered 5/5 - How it runs on autopilot',
                'subject' => 'How the whole system runs on autopilot',
                'preview' => 'What runs by itself, and what you keep doing.',
                'wait'    => 1,
            ),
        ),
        2 => array(
            array(
                'file'    => '01-day-1-pick-the-offer',
                'name'    => 'Split 1/5 - Day 1: Pick the offer that pays',
                'subject' => 'Day 1: Pick the offer that pays',
                'preview' => 'Your first step in the free 5-day email course.',
                'wait'    => 0,
            ),
            array(
                'file'    => '02-day-2-put-your-page-up',
                'name'    => 'Split 2/5 - Day 2: Put your page up',
                'subject' => 'Day 2: Put your page up',
                'preview' => 'The five parts every lead page needs, and nothing else.',
                'wait'    => 1,
            ),
            array(
                'file'    => '03-day-3-write-the-email',
                'name'    => 'Split 3/5 - Day 3: Write the email that sells',
                'subject' => 'Day 3: Write the email that sells',
                'preview' => 'A simple shape you can reuse for any offer, plus an example.',
                'wait'    => 1,
            ),
            array(
                'file'    => '04-day-4-send-traffic',
                'name'    => 'Split 4/5 - Day 4: Send your first traffic',
                'subject' => 'Day 4: Send your first traffic',
                'preview' => 'Pick one source and get your first visitors today.',
                'wait'    => 1,
            ),
            array(
                'file'    => '05-day-5-do-it-again',
                'name'    => 'Split 5/5 - Day 5: Do it again, and again',
                'subject' => 'Day 5: Do it again, and again',
                'preview' => 'The weekly loop that keeps it all growing.',
                'wait'    => 1,
            ),
        ),
        3 => array(
            array(
                'file'    => '01-your-guide',
                'name'    => 'Long Form 1/7 - Your guide',
                'subject' => 'Your guide is here',
                'preview' => 'The Lead-First Affiliate Guide: five chapters, one PDF.',
                'wait'    => 0,
                'attach'  => 'guide.pdf',
            ),
            array(
                'file'    => '02-offers-that-pay-monthly',
                'name'    => 'Long Form 2/7 - Offers that pay every month',
                'subject' => 'The offer that pays you every month',
                'preview' => 'Chapter 1, plus the test to run before you promote it.',
                'wait'    => 1,
            ),
            array(
                'file'    => '03-the-page-layout',
                'name'    => 'Long Form 3/7 - The page layout',
                'subject' => 'The page layout that turns clicks into subscribers',
                'preview' => 'Chapter 2, plus a test to run on your own phone.',
                'wait'    => 1,
            ),
            array(
                'file'    => '04-the-seven-emails',
                'name'    => 'Long Form 4/7 - The seven emails',
                'subject' => "You're reading email 4 of 7",
                'preview' => 'Chapter 3: the seven emails that do the selling for you.',
                'wait'    => 1,
            ),
            array(
                'file'    => '05-first-100-clicks',
                'name'    => 'Long Form 5/7 - Your first 100 clicks',
                'subject' => 'Your first 100 clicks, for very little money',
                'preview' => 'Chapter 4, plus a simple ten-a-day plan.',
                'wait'    => 1,
            ),
            array(
                'file'    => '06-read-your-numbers',
                'name'    => 'Long Form 6/7 - Read your numbers',
                'subject' => 'Four numbers that tell you what to fix',
                'preview' => 'Chapter 5, plus a five-minute weekly check-in.',
                'wait'    => 1,
            ),
            array(
                'file'    => '07-what-to-do-next',
                'name'    => 'Long Form 7/7 - What to do next',
                'subject' => 'What to do next',
                'preview' => 'The whole guide in five steps.',
                'wait'    => 1,
            ),
        ),
    );
}

/* -------------------------------------------------------------------------
 * The email renderer
 * ---------------------------------------------------------------------- */

/**
 * Give the site name that the emails print.
 *
 * WordPress stores the Site Title with its HTML entities, so this decodes
 * them. An empty Site Title falls back to the host name.
 *
 * @return string Plain text.
 */
function Affiliate_Theme_Theme_email_site_name() {
    $name = trim( wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES ) );

    if ( '' === $name ) {
        $name = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
    }

    return $name;
}

/**
 * Give the inline style of each bare tag in an email body.
 *
 * Mail apps ignore most style sheets, so every tag carries its own style.
 * The body files use bare tags only, and this map replaces each one. A tag
 * with an attribute is left alone, so layout.html styles its own tags.
 *
 * @return array Bare tag => styled markup.
 */
function Affiliate_Theme_Theme_email_styles() {
    $serif = "font-family:Newsreader,'Iowan Old Style',Georgia,'Times New Roman',serif;font-size:17px;line-height:28px;color:#111827;";
    $sans  = "font-family:Archivo,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;";

    return array(
        '<p>'           => '<p style="margin:0 0 18px 0;' . $serif . '">',
        '<h2>'          => '<h2 style="margin:28px 0 12px 0;' . $sans . 'font-size:21px;line-height:27px;font-weight:700;color:#111827;">',
        '<ul>'          => '<ul style="margin:0 0 18px 0;padding:0 0 0 24px;">',
        '<ol>'          => '<ol style="margin:0 0 18px 0;padding:0 0 0 24px;">',
        '<li>'          => '<li style="margin:0 0 10px 0;' . $serif . '">',
        '<blockquote>'  => '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 18px 0;"><tr><td align="left" bgcolor="#f4f6fb" style="background-color:#f4f6fb;border-left:4px solid #2563eb;padding:18px 20px 0 20px;">',
        '</blockquote>' => '</td></tr></table>',
    );
}

/**
 * Turn the call-to-action paragraph of an email body into a button.
 *
 * A body writes it as <p class="cta"><a href="URL">Label</a></p>. The
 * button is a table cell with a background color, which every mail app
 * draws, Outlook included.
 *
 * @param string $html The email markup.
 * @return string
 */
function Affiliate_Theme_Theme_email_buttons( $html ) {
    return preg_replace_callback(
        '#<p class="cta"><a href="([^"]+)">(.+?)</a></p>#',
        static function ( $m ) {
            return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td align="left" style="padding:4px 0 24px 0;">'
                . '<table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" bgcolor="#2563eb" style="background-color:#2563eb;border-radius:8px;">'
                . '<a href="' . $m[1] . '" target="_blank" style="display:inline-block;padding:14px 26px;font-family:Archivo,-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;font-size:17px;line-height:22px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:8px;">' . $m[2] . '</a>'
                . '</td></tr></table>'
                . '</td></tr></table>';
        },
        $html
    );
}

/**
 * Write every character past ASCII as a numeric HTML entity.
 *
 * The email then reads the same in every character set, so a mail app, or
 * a GetResponse import that guesses the wrong one, cannot garble a curly
 * quote. This works without mbstring, which WordPress does not polyfill.
 * Text that is not valid UTF-8 comes back as it was.
 *
 * @param string $html The email markup.
 * @return string
 */
function Affiliate_Theme_Theme_email_entities( $html ) {
    $out = preg_replace_callback(
        '/[\x{80}-\x{10FFFF}]/u',
        static function ( $m ) {
            $bytes = $m[0];
            $count = strlen( $bytes );
            $code  = ord( $bytes[0] ) & ( 0xFF >> ( $count + 1 ) );

            for ( $i = 1; $i < $count; $i++ ) {
                $code = ( $code << 6 ) | ( ord( $bytes[ $i ] ) & 0x3F );
            }

            return '&#' . $code . ';';
        },
        $html
    );

    return null === $out ? $html : $out;
}

/**
 * Make the full HTML of one email.
 *
 * The steps run in this order: the body goes into emails/layout.html, the
 * signature goes in, the call to action becomes a button, the bare tags get
 * their styles, the plain links get theirs, the values fill the tokens,
 * and the characters past ASCII become entities. Then no {{TOKEN}} may be
 * left. GetResponse's own tags, such as {{CONTACT `subscriber_first_name`}},
 * hold spaces and backticks, so the check passes over them.
 *
 * @param int    $index         The landing page number, 1 to 3.
 * @param array  $email         One entry from Affiliate_Theme_Theme_email_sequences().
 * @param string $affiliate_url The affiliate redirect URL.
 * @return string|WP_Error
 */
function Affiliate_Theme_Theme_render_email( $index, $email, $affiliate_url ) {
    $layout_file = get_theme_file_path( 'emails/layout.html' );
    $body_file   = get_theme_file_path( 'emails/landing-' . (int) $index . '/' . $email['file'] . '.html' );

    $layout = is_readable( $layout_file ) ? file_get_contents( $layout_file ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- A local theme file.
    $body   = is_readable( $body_file ) ? file_get_contents( $body_file ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- A local theme file.

    if ( false === $layout || false === $body ) {
        return new WP_Error( 'affiliate_theme_email_missing', sprintf( 'The theme file %s is missing.', false === $layout ? $layout_file : $body_file ) );
    }

    $site_name = Affiliate_Theme_Theme_email_site_name();

    $html = str_replace( '{{BODY}}', trim( $body ), $layout );
    $html = str_replace( '{{SIGNATURE}}', '<p>Talk soon,<br>{{SITE_NAME}}</p>', $html );
    $html = Affiliate_Theme_Theme_email_buttons( $html );
    $html = strtr( $html, Affiliate_Theme_Theme_email_styles() );
    $html = preg_replace( '#<a href="([^"]+)">#', '<a href="$1" target="_blank" style="color:#2563eb;text-decoration:underline;">', $html );
    $html = strtr(
        $html,
        array(
            '{{AFFILIATE_URL}}' => esc_url( $affiliate_url ),
            '{{SITE_URL}}'      => esc_url( home_url( '/' ) ),
            '{{SITE_NAME}}'     => esc_html( $site_name ),
            '{{SUBJECT}}'       => esc_html( $email['subject'] ),
        )
    );
    $html = Affiliate_Theme_Theme_email_entities( $html );

    if ( preg_match_all( '/\{\{[A-Z_]+\}\}/', $html, $left ) ) {
        return new WP_Error(
            'affiliate_theme_email_token',
            sprintf( 'emails/landing-%d/%s.html has a token that nothing fills: %s', (int) $index, $email['file'], implode( ', ', array_unique( $left[0] ) ) )
        );
    }

    return $html;
}

/* -------------------------------------------------------------------------
 * The ZIP builder
 * ---------------------------------------------------------------------- */

/**
 * Give an example of the link an attach file gets in the Media Library.
 *
 * WordPress files an upload under this month's folder, so the example
 * matches an upload made today. The steps that print it say "something
 * like", because WordPress renames a file whose name is taken.
 *
 * @param string $file The attach file name, such as guide.pdf.
 * @return string
 */
function Affiliate_Theme_Theme_email_attach_url( $file ) {
    $uploads = wp_get_upload_dir();

    return ( empty( $uploads['url'] ) ? home_url( '/wp-content/uploads' ) : $uploads['url'] ) . '/' . $file;
}

/**
 * Give the line of an email's index.html that links to its attach file.
 *
 * GetResponse does not host the attach file, so the buyer replaces that
 * link with the file's Media Library link. GetResponse's HTML editor numbers
 * the lines as the file has them.
 *
 * @param int    $index         The landing page number, 1 to 3.
 * @param array  $email         One entry from Affiliate_Theme_Theme_email_sequences().
 * @param string $affiliate_url The affiliate redirect URL.
 * @return int The line number, or 0 when the email has no such link.
 */
function Affiliate_Theme_Theme_email_link_line( $index, $email, $affiliate_url ) {
    $html = Affiliate_Theme_Theme_render_email( $index, $email, $affiliate_url );

    if ( is_wp_error( $html ) || empty( $email['attach'] ) ) {
        return 0;
    }

    foreach ( explode( "\n", $html ) as $i => $line ) {
        if ( false !== strpos( $line, '<a href="' . $email['attach'] . '"' ) ) {
            return $i + 1;
        }
    }

    return 0;
}

/**
 * Write the READ-ME-FIRST.txt of one landing page's emails.
 *
 * Plain text with Windows line ends, which every text editor shows
 * correctly, wrapped at 72 characters.
 *
 * @param int    $index         The landing page number, 1 to 3.
 * @param string $affiliate_url The affiliate redirect URL.
 * @return string
 */
function Affiliate_Theme_Theme_email_readme( $index, $affiliate_url ) {
    $pages  = Affiliate_Theme_Theme_landing_pages();
    $emails = Affiliate_Theme_Theme_email_sequences()[ $index ];
    $count  = count( $emails );
    $rule     = str_repeat( '-', 64 );
    $attach   = false;
    $brackets = false;

    // Wrap at 72 characters. $indent starts every line. $hang also starts
    // every line after the first, under the text that follows a "1. ".
    $wrap = static function ( $text, $indent = '', $hang = '' ) {
        $lines = explode( "\n", wordwrap( $text, 72 - strlen( $indent ) - strlen( $hang ), "\n", true ) );

        return $indent . implode( "\n" . $indent . $hang, $lines );
    };

    $out   = array();
    $out[] = 'YOUR EMAILS FOR: ' . $pages[ $index ]['title'];
    $out[] = '';
    $out[] = 'Site:                  ' . Affiliate_Theme_Theme_email_site_name() . ' (' . home_url( '/' ) . ')';
    $out[] = 'Every email links to:  ' . $affiliate_url;
    $out[] = 'Made:                  ' . wp_date( get_option( 'date_format' ) ) . ', by Affiliate Theme ' . AFFILIATE_THEME_VERSION;
    $out[] = '';
    $out[] = $wrap( sprintf( 'These %d emails keep the promise that your landing page makes, so use them with that landing page. Each email is its own ZIP file:', $count ) );
    $out[] = '';

    foreach ( $emails as $i => $email ) {
        $out[] = '  ' . $email['file'] . '.zip';

        // The first email with an attach file. GetResponse does not host
        // that file, so the buyer uploads it to the Media Library and puts
        // its link in by hand.
        if ( ! $attach && ! empty( $email['attach'] ) ) {
            $attach = array(
                'number' => $i + 1,
                'zip'    => $email['file'] . '.zip',
                'folder' => $email['file'],
                'file'   => $email['attach'],
                'line'   => Affiliate_Theme_Theme_email_link_line( $index, $email, $affiliate_url ),
            );
        }

        // A sample email for subscribers to copy shows its blanks as [brackets].
        $body_file = get_theme_file_path( 'emails/landing-' . (int) $index . '/' . $email['file'] . '.html' );
        $brackets  = $brackets || ( is_readable( $body_file ) && false !== strpos( (string) file_get_contents( $body_file ), '[' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- A local theme file.
    }

    $out[] = '';

    if ( $attach ) {
        $out[] = $wrap( sprintf( 'Unzip %1$s and upload the %2$s inside it to the Media Library in your WordPress dashboard (Media > Add Media File). Your subscribers download it from there. After %2$s is uploaded, delete the folder %3$s that unzipping made. Do not delete %1$s.', $attach['zip'], $attach['file'], $attach['folder'] ) );
        $out[] = '';
    }

    $out[] = $wrap( 'Keep all the email ZIP files zipped. GetResponse takes each one exactly as it is. If Safari on a Mac unzipped this download into a folder for you, that is fine: the email ZIP files inside the folder stay zipped.' );
    $out[] = '';
    $out[] = '';
    $out[] = 'STEP 1. MAKE ONE AUTOMATION MESSAGE FOR EACH EMAIL';
    $out[] = '';
    $out[] = 'Do this for each email in the list below, in order:';
    $out[] = '';
    $out[] = $wrap( '1. In GetResponse, open Automation, then Automation messages, and click Create automation message.', '  ', '   ' );
    $out[] = $wrap( '2. Click Edit name and type the message name. For Linked list, choose the list whose token is in Settings > Affiliate Theme Settings in WordPress.', '  ', '   ' );
    $out[] = $wrap( '3. Type the subject line. Click Preview text and type the preview text.', '  ', '   ' );
    $out[] = $wrap( "4. Click Design message. Open the HTML editor tab, click Upload from ZIP, choose the email's ZIP file and click Upload.", '  ', '   ' );
    $out[] = $wrap( '5. Check the email. There should be HTML code on the left and plain text on the right.', '  ', '   ' );
    $step  = 6;

    // The two link lines stand alone and unwrapped, because a wrap would
    // cut the URL in two.
    if ( $attach ) {
        $out[] = $wrap( sprintf( '%d. Email %d only: in your WordPress dashboard, open Media > Library and click %s. Click Copy URL to clipboard, in the lower right corner.', $step++, $attach['number'], $attach['file'] ), '  ', '   ' );
        $out[] = $wrap( sprintf( '%d. Email %d only: go back to the email in GetResponse. Press Ctrl+F (Command+F on a Mac), or open your browser\'s Edit menu and choose Find in Page, and find this%s:', $step++, $attach['number'], $attach['line'] ? sprintf( ', on line %d of the HTML code', $attach['line'] ) : '' ), '  ', '   ' );
        $out[] = '';
        $out[] = '       <a href="' . $attach['file'] . '"';
        $out[] = '';
        $out[] = $wrap( sprintf( 'Replace %s, between the quotes, with the link you copied, so that it reads something like this:', $attach['file'] ), '     ' );
        $out[] = '';
        $out[] = '       <a href="' . Affiliate_Theme_Theme_email_attach_url( $attach['file'] ) . '"';
        $out[] = '';
    }

    $out[] = $wrap( sprintf( '%d. Click Save and finish.', $step ), '  ', '   ' );
    $out[] = '';
    $out[] = '';
    $out[] = 'STEP 2. SEND THE EMAILS FROM AN AUTOMATION WORKFLOW';
    $out[] = '';
    $out[] = $wrap( 'Make a workflow that starts when a contact subscribes to that list. Add a Send message action for email 1. Then, for each email after it, add a Wait action and a Send message action. The list below gives each wait. GetResponse automation workflows need a paid plan. New accounts get them free during the 14-day free trial.' );
    $out[] = '';
    $out[] = '';
    $out[] = 'THE EMAILS';
    $out[] = '';
    $out[] = $rule;

    foreach ( $emails as $i => $email ) {
        $number = $i + 1;

        if ( 0 === (int) $email['wait'] ) {
            $when = 'Right away, as soon as the contact subscribes.';
        } else {
            $when = sprintf( '%d %s after email %d.', (int) $email['wait'], 1 === (int) $email['wait'] ? 'day' : 'days', $number - 1 );
        }

        $out[] = sprintf( 'Email %d of %d', $number, $count );
        $out[] = '  ZIP file:      ' . $email['file'] . '.zip';
        $out[] = '  Message name:  ' . $email['name'];
        $out[] = '  Subject line:  ' . $email['subject'];
        $out[] = '  Preview text:  ' . $email['preview'];
        $out[] = '  When:          ' . $when;
        $out[] = $rule;
    }

    $out[] = '';
    $out[] = '';
    $out[] = 'GOOD TO KNOW';
    $out[] = '';
    $out[] = $wrap( '- Each email greets the contact by first name, or with "Hi there" when GetResponse has no first name for them.', '', '  ' );
    $out[] = $wrap( '- The emails sign off with your Site Title, from Settings > General in WordPress.', '', '  ' );
    $out[] = $wrap( '- GetResponse adds the unsubscribe link and your postal address to the bottom of every email, so the emails do not carry their own.', '', '  ' );
    if ( $brackets ) {
        $out[] = $wrap( '- Words in [brackets] inside a sample email are for your subscribers to fill in when they copy it. Leave them as they are.', '', '  ' );
    }

    $out[] = $wrap( '- The emails match your landing page as the theme made it. If you change what your page promises, change the emails to match.', '', '  ' );
    $out[] = $wrap( '- If you change your affiliate redirect URL, download the emails again and replace them in GetResponse.', '', '  ' );

    if ( $attach ) {
        $out[] = $wrap( sprintf( "- Email %1\$d links to %2\$s in your Media Library. After you put that link in, click the guide button in the email's preview to check that the guide opens. Keep %2\$s in your Media Library: if you delete it, the link in email %1\$d stops working.", $attach['number'], $attach['file'] ), '', '  ' );
    }

    return implode( "\r\n", $out ) . "\r\n";
}

/**
 * Make an empty ZIP file in the temp folder.
 *
 * @param ZipArchive $zip    The archive object to open.
 * @param string     $prefix The temp file name prefix.
 * @return string|false The file path, or false.
 */
function Affiliate_Theme_Theme_email_zip_open( $zip, $prefix ) {
    if ( ! function_exists( 'wp_tempnam' ) ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }

    $path = wp_tempnam( $prefix );

    // OVERWRITE, because wp_tempnam() leaves an empty file, and PHP 8
    // deprecates opening an empty file as an archive.
    if ( ! $path || true !== $zip->open( $path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
        if ( $path ) {
            wp_delete_file( $path );
        }

        return false;
    }

    return $path;
}

/**
 * Add one file to a ZIP with the Unix mode 644.
 *
 * Without a mode, macOS can unzip a file as one that nobody may read. The
 * theme's own zip had that fault (see WAT/tools/build_theme_zip.py).
 *
 * @param ZipArchive $zip  The open archive.
 * @param string     $name The file name in the archive.
 * @param string     $data The file contents.
 * @return bool
 */
function Affiliate_Theme_Theme_email_zip_add( $zip, $name, $data ) {
    return $zip->addFromString( $name, $data )
        && $zip->setExternalAttributesName( $name, ZipArchive::OPSYS_UNIX, 0100644 << 16 );
}

/**
 * Build the download of one landing page's emails.
 *
 * The download is a ZIP that holds one ZIP per email and READ-ME-FIRST.txt.
 * Each email ZIP holds index.html at its root, plus the email's attach
 * file next to it, as GetResponse's Upload from ZIP wants.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return array|WP_Error The keys path, the temp file, and name, the
 *                        download's file name. The caller deletes the file.
 */
function Affiliate_Theme_Theme_build_email_zip( $index ) {
    $index     = (int) $index;
    $sequences = Affiliate_Theme_Theme_email_sequences();
    $settings  = Affiliate_Theme_Theme_get_settings();

    if ( ! isset( $sequences[ $index ] ) ) {
        return new WP_Error( 'affiliate_theme_email_index', 'There is no email sequence for that landing page.' );
    }

    if ( ! class_exists( 'ZipArchive' ) ) {
        return new WP_Error( 'affiliate_theme_no_zip', 'The PHP zip extension is not installed.' );
    }

    if ( ! Affiliate_Theme_Theme_is_redirect_url( $settings['redirect_url'] ) ) {
        return new WP_Error( 'affiliate_theme_no_url', 'No usable affiliate redirect URL is saved.' );
    }

    $outer      = new ZipArchive();
    $outer_path = Affiliate_Theme_Theme_email_zip_open( $outer, 'affiliate-emails' );

    if ( ! $outer_path ) {
        return new WP_Error( 'affiliate_theme_email_zip', 'The theme could not make a temp file.' );
    }

    $fail = static function ( $error ) use ( $outer, $outer_path ) {
        $outer->close();
        wp_delete_file( $outer_path );

        return $error;
    };

    foreach ( $sequences[ $index ] as $email ) {
        $html = Affiliate_Theme_Theme_render_email( $index, $email, $settings['redirect_url'] );

        if ( is_wp_error( $html ) ) {
            return $fail( $html );
        }

        $inner      = new ZipArchive();
        $inner_path = Affiliate_Theme_Theme_email_zip_open( $inner, 'affiliate-email' );

        if ( ! $inner_path ) {
            return $fail( new WP_Error( 'affiliate_theme_email_zip', 'The theme could not make a temp file.' ) );
        }

        $ok = Affiliate_Theme_Theme_email_zip_add( $inner, 'index.html', $html );

        if ( $ok && ! empty( $email['attach'] ) ) {
            $attach_file = get_theme_file_path( 'emails/landing-' . $index . '/' . $email['attach'] );
            $attach_data = is_readable( $attach_file ) ? file_get_contents( $attach_file ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- A local theme file.

            if ( false === $attach_data ) {
                $inner->close();
                wp_delete_file( $inner_path );

                return $fail( new WP_Error( 'affiliate_theme_email_missing', sprintf( 'The theme file %s is missing.', $attach_file ) ) );
            }

            $ok = Affiliate_Theme_Theme_email_zip_add( $inner, $email['attach'], $attach_data );
        }

        $ok   = $inner->close() && $ok;
        $data = $ok ? file_get_contents( $inner_path ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Our own temp file.

        wp_delete_file( $inner_path );

        if ( false === $data || ! Affiliate_Theme_Theme_email_zip_add( $outer, $email['file'] . '.zip', $data ) ) {
            return $fail( new WP_Error( 'affiliate_theme_email_zip', sprintf( 'The theme could not write %s.zip.', $email['file'] ) ) );
        }
    }

    if ( ! Affiliate_Theme_Theme_email_zip_add( $outer, 'READ-ME-FIRST.txt', Affiliate_Theme_Theme_email_readme( $index, $settings['redirect_url'] ) ) ) {
        return $fail( new WP_Error( 'affiliate_theme_email_zip', 'The theme could not write READ-ME-FIRST.txt.' ) );
    }

    if ( ! $outer->close() ) {
        wp_delete_file( $outer_path );

        return new WP_Error( 'affiliate_theme_email_zip', 'The theme could not finish the ZIP file.' );
    }

    return array(
        'path' => $outer_path,
        'name' => 'affiliate-emails-landing-' . $index . '.zip',
    );
}

/* -------------------------------------------------------------------------
 * The download
 * ---------------------------------------------------------------------- */

/**
 * Give the URL of the settings page, at the email section.
 *
 * @param string $notice A notice code for the section to show, or ''.
 * @return string
 */
function Affiliate_Theme_Theme_email_settings_url( $notice = '' ) {
    $url = admin_url( 'options-general.php?page=affiliate-theme-settings' );

    if ( '' !== $notice ) {
        $url = add_query_arg( AFFILIATE_THEME_EMAIL_NOTICE, $notice, $url );
    }

    return $url . '#' . AFFILIATE_THEME_EMAIL_NOTICE;
}

/**
 * Send one landing page's emails as a download.
 *
 * Reached through admin-post.php from a button in the email section. A
 * fault sends the browser back to that section with a notice.
 *
 * @return void
 */
function Affiliate_Theme_Theme_email_zip_handler() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Sorry, you are not allowed to download these emails.', 403 );
    }

    check_admin_referer( AFFILIATE_THEME_EMAIL_ACTION );

    $index = isset( $_GET['landing'] ) ? absint( $_GET['landing'] ) : 0;
    $built = Affiliate_Theme_Theme_build_email_zip( $index );

    if ( is_wp_error( $built ) ) {
        $notices = array(
            'affiliate_theme_no_url' => 'no-url',
            'affiliate_theme_no_zip' => 'no-zip',
        );
        $code    = $built->get_error_code();

        if ( ! isset( $notices[ $code ] ) ) {
            error_log( 'Affiliate Theme: the email download failed: ' . $built->get_error_message() );
        }

        wp_safe_redirect( Affiliate_Theme_Theme_email_settings_url( isset( $notices[ $code ] ) ? $notices[ $code ] : 'failed' ) );
        exit;
    }

    while ( ob_get_level() > 0 ) {
        ob_end_clean();
    }

    nocache_headers();
    header( 'Content-Type: application/zip' );
    header( 'Content-Disposition: attachment; filename="' . $built['name'] . '"' );
    header( 'Content-Length: ' . filesize( $built['path'] ) );

    readfile( $built['path'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile -- Streams our own temp file.
    wp_delete_file( $built['path'] );
    exit;
}
add_action( 'admin_post_' . AFFILIATE_THEME_EMAIL_ACTION, 'Affiliate_Theme_Theme_email_zip_handler' );

/**
 * Drop the notice code from the address bar after the page shows it, so a
 * reload does not show the notice again.
 *
 * @param array $args The query arguments WordPress removes.
 * @return array
 */
function Affiliate_Theme_Theme_email_removable_args( $args ) {
    $args[] = AFFILIATE_THEME_EMAIL_NOTICE;

    return $args;
}
add_filter( 'removable_query_args', 'Affiliate_Theme_Theme_email_removable_args' );

/* -------------------------------------------------------------------------
 * The settings page section
 * ---------------------------------------------------------------------- */

/**
 * Print the "Your email sequences" section of the settings page.
 *
 * Called from Affiliate_Theme_Theme_render_settings_page(), after the
 * landing pages. The buttons stay disabled until a usable affiliate
 * redirect URL is saved, because every email links to it.
 *
 * @return void
 */
function Affiliate_Theme_Theme_emails_render_settings_section() {
    $settings  = Affiliate_Theme_Theme_get_settings();
    $ready     = Affiliate_Theme_Theme_is_redirect_url( $settings['redirect_url'] );
    $sequences = Affiliate_Theme_Theme_email_sequences();

    printf( '<h2 id="%s">Your email sequences</h2>', esc_attr( AFFILIATE_THEME_EMAIL_NOTICE ) );

    // A display flag set by the download handler; it changes nothing. A
    // settings save keeps the old query string, so skip the notice then.
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $notice   = isset( $_GET[ AFFILIATE_THEME_EMAIL_NOTICE ] ) && ! isset( $_GET['settings-updated'] ) ? sanitize_key( wp_unslash( $_GET[ AFFILIATE_THEME_EMAIL_NOTICE ] ) ) : '';
    $messages = array(
        'no-url' => 'Save a usable affiliate redirect URL first. Every email links to it.',
        'no-zip' => 'Your server cannot make ZIP files, because PHP&#8217;s zip extension is turned off. Ask your web host to turn it on, then try again.',
        'failed' => 'The theme could not build the emails. Try again. If it fails again, install the theme again.',
    );

    if ( isset( $messages[ $notice ] ) ) {
        echo '<div class="notice notice-error inline"><p>' . wp_kses_post( $messages[ $notice ] ) . '</p></div>';
    }

    echo '<p>Each landing page promises its visitors emails. These emails keep that promise, and every one of them links to your affiliate redirect URL. Download the emails for the landing page that you publish.</p>';

    echo '<table class="widefat striped" style="max-width:52rem"><thead><tr><th scope="col">Landing page</th><th scope="col">Emails</th><th scope="col"><span class="screen-reader-text">Download</span></th></tr></thead><tbody>';

    foreach ( Affiliate_Theme_Theme_landing_pages() as $index => $page ) {
        $count = isset( $sequences[ $index ] ) ? count( $sequences[ $index ] ) : 0;

        if ( ! $count ) {
            continue;
        }

        $what = sprintf( '%d emails, one a day.', $count );

        if ( ! empty( $sequences[ $index ][0]['attach'] ) ) {
            $what .= ' The first one delivers the guide, a PDF that you upload to your Media Library.';
        }

        if ( $ready ) {
            $button = sprintf(
                '<a class="button" href="%s" aria-label="%s">Download the emails</a>',
                esc_url( wp_nonce_url( add_query_arg( array( 'action' => AFFILIATE_THEME_EMAIL_ACTION, 'landing' => $index ), admin_url( 'admin-post.php' ) ), AFFILIATE_THEME_EMAIL_ACTION ) ),
                esc_attr( 'Download the emails for ' . $page['title'] )
            );
        } else {
            $button = '<button type="button" class="button" disabled="disabled">Download the emails</button>';
        }

        printf(
            '<tr><td><strong>%s</strong></td><td>%s</td><td style="text-align:right">%s</td></tr>',
            esc_html( $page['title'] ),
            esc_html( $what ),
            $button // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built and escaped above.
        );
    }

    echo '</tbody></table>';

    if ( ! $ready ) {
        echo '<p class="description">Save a usable affiliate redirect URL above first. Every email links to it.</p>';
    }

    echo '<ol>';
    echo '<li>Unzip the download. Inside are one ZIP file for each email and <code>READ-ME-FIRST.txt</code>. Keep the email ZIP files zipped.</li>';
    echo '<li>In GetResponse, make one automation message for each email, in order. Type the message name, the subject line and the preview text from <code>READ-ME-FIRST.txt</code>. Then click <strong>Design message</strong> &rarr; <strong>HTML editor</strong> &rarr; <strong>Upload from ZIP</strong> and upload that email&#8217;s ZIP file.</li>';
    echo '<li>Send the emails from an automation workflow that starts when a contact subscribes to your list. <code>READ-ME-FIRST.txt</code> gives the wait before each email.</li>';
    echo '</ol>';
    echo '<p>The emails match the landing pages as the theme made them. If you change what your page promises, change the emails to match. If you change your affiliate redirect URL, download the emails again.</p>';

    // GetResponse does not host an attach file, so the buyer puts it in
    // the Media Library and links to it from there.
    foreach ( Affiliate_Theme_Theme_landing_pages() as $index => $page ) {
        foreach ( isset( $sequences[ $index ] ) ? $sequences[ $index ] : array() as $i => $email ) {
            if ( empty( $email['attach'] ) ) {
                continue;
            }

            $file = $email['attach'];

            printf( '<h3>%s lead magnet instructions</h3>', esc_html( $page['title'] ) );
            echo '<ol>';
            printf(
                '<li>Unzip <code>%1$s.zip</code>, inside the download, and upload the lead magnet <code>%2$s</code> from the folder <code>%1$s</code> to your Media Library (<strong>Media</strong> &rarr; <strong>Add Media File</strong>).</li>',
                esc_html( $email['file'] ),
                esc_html( $file )
            );
            printf( '<li>In the Media Library, click <code>%s</code>, then click <strong>Copy URL to clipboard</strong>.</li>', esc_html( $file ) );
            printf(
                '<li>In GetResponse, open email %1$d in the HTML editor and find <code>%2$s</code>. Replace <code>%3$s</code>, between the quotes, with the link you just copied. It should then look something like <code>%4$s</code>.</li>',
                (int) $i + 1,
                esc_html( '<a href="' . $file . '"' ),
                esc_html( $file ),
                esc_html( '<a href="' . Affiliate_Theme_Theme_email_attach_url( $file ) . '"' )
            );
            echo '</ol>';

            break;
        }
    }
}
