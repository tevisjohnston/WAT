<?php
/**
 * Affiliate Theme — the email sequences.
 *
 * Contains the emails of each landing page in the order that they are sent,
 * the renderer that makes each email's HTML, the values that fill its Resend
 * variables, and the From line. Nothing in this file calls Resend.
 *
 * Each landing page promises its subscribers something by email. These
 * emails keep that promise. Each one becomes a template in the buyer's
 * Resend account, and one automation for each landing page sends them in
 * order.
 *
 * A template holds the theme's copy only. The buyer's values, such as the
 * affiliate URL and the mailing address, reach it as Resend variables,
 * written {{{NAME}}}, whose fallback values the theme keeps on the template.
 * So the HTML is the same on every site, and a changed setting changes the
 * fallbacks, never the copy.
 *
 * @package affiliate-theme
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * The email lists
 * ---------------------------------------------------------------------- */

/**
 * Give the emails of each landing page, in the order that they are sent.
 *
 * The keys match Affiliate_Theme_Theme_landing_pages(). For each email:
 *
 * - file:    its body in emails/landing-N/, without .html.
 * - name:    the template's name in Resend, after "Affiliate Theme <site
 *            key> - ". Resend takes 50 characters in all, which leaves 23
 *            here.
 * - subject: the subject line. Keep it to 60 characters or less, so it
 *            fits a phone screen.
 * - preview: the preview text that a mail app shows after the subject. It
 *            goes into the hidden preheader at the top of the email.
 * - wait:    how long to wait after the email before it, written the way
 *            Resend writes a delay, such as "1 day" or "7 days". The first
 *            email has none: it goes out as soon as the visitor signs up.
 * - vars:    the Resend variables that the email uses. Every email uses
 *            the layout's four and the affiliate link.
 *            Affiliate_Theme_Theme_email_variables() gives their values.
 *
 * These strings reach the buyer's Resend dashboard and the subscriber's
 * inbox. Keep them plain ASCII.
 *
 * The emails quote what their landing page promises: Split's Day 1 to Day 5
 * titles, Long Form's five chapters and Centered's four items. A promise
 * changed in Affiliate_Theme_Theme_landing_pattern_*() needs the same change
 * in its emails, and for Long Form in the guide too.
 *
 * @return array
 */
function Affiliate_Theme_Theme_email_sequences() {
    $vars = array( 'USER_FIRST_NAME', 'SITE_NAME', 'SITE_URL', 'MAILING_ADDRESS', 'AFFILIATE_URL' );

    return array(
        1 => array(
            array(
                'file'    => '01-one-page-plan',
                'name'    => 'Centered 1/6 Plan',
                'subject' => 'Your one-page plan is inside',
                'preview' => 'The exact steps, all on one page. Save this email.',
                'wait'    => '',
                'vars'    => $vars,
            ),
            array(
                'file'    => '02-offers-that-pay',
                'name'    => 'Centered 2/6 Offers',
                'subject' => 'The offers that pay the most for the least work',
                'preview' => 'Six checks to run before you promote anything.',
                'wait'    => '1 day',
                'vars'    => $vars,
            ),
            array(
                'file'    => '03-first-email',
                'name'    => 'Centered 3/6 Email',
                'subject' => 'The first email to send, word for word',
                'preview' => 'Copy it, fill in the brackets, and load it as email one.',
                'wait'    => '6 days',
                'vars'    => $vars,
            ),
            array(
                'file'    => '04-the-90-day-mistake',
                'name'    => 'Centered 4/6 Mistake',
                'subject' => 'The mistake that costs new affiliates 90 days',
                'preview' => "It feels like progress. It's the opposite.",
                'wait'    => '7 days',
                'vars'    => $vars,
            ),
            array(
                'file'    => '05-autopilot',
                'name'    => 'Centered 5/6 Autopilot',
                'subject' => 'How the whole system runs on autopilot',
                'preview' => 'What runs by itself, and what you keep doing.',
                'wait'    => '7 days',
                'vars'    => $vars,
            ),
            array(
                'file'    => '06-your-next-30-days',
                'name'    => 'Centered 6/6 Next 30',
                'subject' => 'Your next 30 days',
                'preview' => 'The whole system as one plan, one week at a time.',
                'wait'    => '7 days',
                'vars'    => $vars,
            ),
        ),
        2 => array(
            array(
                'file'    => '01-day-1-pick-the-offer',
                'name'    => 'Split 1/5 Day 1 Offer',
                'subject' => 'Day 1: Pick the offer that pays',
                'preview' => 'Your first step in the free 5-day email course.',
                'wait'    => '',
                'vars'    => $vars,
            ),
            array(
                'file'    => '02-day-2-put-your-page-up',
                'name'    => 'Split 2/5 Day 2 Page',
                'subject' => 'Day 2: Put your page up',
                'preview' => 'The five parts every lead page needs, and nothing else.',
                'wait'    => '1 day',
                'vars'    => $vars,
            ),
            array(
                'file'    => '03-day-3-write-the-email',
                'name'    => 'Split 3/5 Day 3 Email',
                'subject' => 'Day 3: Write the email that sells',
                'preview' => 'A simple shape you can reuse for any offer, plus an example.',
                'wait'    => '1 day',
                'vars'    => $vars,
            ),
            array(
                'file'    => '04-day-4-send-traffic',
                'name'    => 'Split 4/5 Day 4 Traffic',
                'subject' => 'Day 4: Send your first traffic',
                'preview' => 'Pick one source and get your first visitors today.',
                'wait'    => '1 day',
                'vars'    => $vars,
            ),
            array(
                'file'    => '05-day-5-do-it-again',
                'name'    => 'Split 5/5 Day 5 Repeat',
                'subject' => 'Day 5: Do it again, and again',
                'preview' => 'The weekly loop that keeps it all growing.',
                'wait'    => '1 day',
                'vars'    => $vars,
            ),
        ),
        3 => array(
            array(
                'file'    => '01-your-guide',
                'name'    => 'Long Form 1/6 Guide',
                'subject' => 'Your guide is here',
                'preview' => 'The Lead-First Affiliate Guide: five chapters, one PDF.',
                'wait'    => '',
                'vars'    => array_merge( $vars, array( 'GUIDE_URL' ) ),
            ),
            array(
                'file'    => '02-offers-that-pay-monthly',
                'name'    => 'Long Form 2/6 Monthly',
                'subject' => 'The offer that pays you every month',
                'preview' => 'Chapter 1, plus the test to run before you promote it.',
                'wait'    => '1 day',
                'vars'    => $vars,
            ),
            array(
                'file'    => '03-the-page-layout',
                'name'    => 'Long Form 3/6 Layout',
                'subject' => 'The page layout that turns clicks into subscribers',
                'preview' => 'Chapter 2, plus a test to run on your own phone.',
                'wait'    => '6 days',
                'vars'    => $vars,
            ),
            array(
                'file'    => '04-the-seven-emails',
                'name'    => 'Long Form 4/6 7 emails',
                'subject' => "You're reading email 4 of 6",
                'preview' => 'Chapter 3: the seven emails that do the selling for you.',
                'wait'    => '7 days',
                'vars'    => $vars,
            ),
            array(
                'file'    => '05-first-100-clicks',
                'name'    => 'Long Form 5/6 Clicks',
                'subject' => 'Your first 100 clicks, for very little money',
                'preview' => 'Chapter 4, plus a simple ten-a-day plan.',
                'wait'    => '7 days',
                'vars'    => $vars,
            ),
            array(
                'file'    => '06-read-your-numbers',
                'name'    => 'Long Form 6/6 Numbers',
                'subject' => 'Four numbers that tell you what to fix',
                'preview' => 'Chapter 5, a weekly check-in, and the whole guide in five steps.',
                'wait'    => '7 days',
                'vars'    => $vars,
            ),
        ),
    );
}

/* -------------------------------------------------------------------------
 * The email renderer
 * ---------------------------------------------------------------------- */

/**
 * Give the inline style of each bare tag in an email body.
 *
 * Mail apps ignore most style sheets, so every tag carries its own style.
 * The body files use bare tags only, and this map replaces each one. A tag
 * with an attribute is left alone, so layout.html styles its own tags.
 *
 * @return array Bare tag => styled markup.
 */
function Affiliate_Theme_Theme_email_styles() {
    $serif = "font-family:Newsreader,'Iowan Old Style',Georgia,'Times New Roman',serif;font-size:17px;line-height:28px;color:#111827;";
    $sans  = "font-family:Archivo,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;";

    return array(
        '<p>'           => '<p style="margin:0 0 18px 0;' . $serif . '">',
        '<h2>'          => '<h2 style="margin:28px 0 12px 0;' . $sans . 'font-size:21px;line-height:27px;font-weight:700;color:#111827;">',
        '<ul>'          => '<ul style="margin:0 0 18px 0;padding:0 0 0 24px;">',
        '<ol>'          => '<ol style="margin:0 0 18px 0;padding:0 0 0 24px;">',
        '<li>'          => '<li style="margin:0 0 10px 0;' . $serif . '">',
        '<blockquote>'  => '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 18px 0;"><tr><td align="left" bgcolor="#f4f6fb" style="background-color:#f4f6fb;border-left:4px solid #2563eb;padding:18px 20px 0 20px;">',
        '</blockquote>' => '</td></tr></table>',
    );
}

/**
 * Turn the call-to-action paragraph of an email body into a button.
 *
 * A body writes it as <p class="cta"><a href="URL">Label</a></p>. The
 * button is a table cell with a background color, which every mail app
 * draws, Outlook included.
 *
 * @param string $html The email markup.
 * @return string
 */
function Affiliate_Theme_Theme_email_buttons( $html ) {
    return preg_replace_callback(
        '#<p class="cta"><a href="([^"]+)">(.+?)</a></p>#',
        static function ( $m ) {
            return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td align="left" style="padding:4px 0 24px 0;">'
                . '<table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" bgcolor="#2563eb" style="background-color:#2563eb;border-radius:8px;">'
                . '<a href="' . $m[1] . '" target="_blank" style="display:inline-block;padding:14px 26px;font-family:Archivo,-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,Helvetica,Arial,sans-serif;font-size:17px;line-height:22px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:8px;">' . $m[2] . '</a>'
                . '</td></tr></table>'
                . '</td></tr></table>';
        },
        $html
    );
}

/**
 * Write every character past ASCII as a numeric HTML entity.
 *
 * The email then reads the same in every character set, so no mail app
 * that guesses the wrong one can garble a curly
 * quote. This works without mbstring, which WordPress does not polyfill.
 * Text that is not valid UTF-8 comes back as it was.
 *
 * @param string $html The email markup.
 * @return string
 */
function Affiliate_Theme_Theme_email_entities( $html ) {
    $out = preg_replace_callback(
        '/[\x{80}-\x{10FFFF}]/u',
        static function ( $m ) {
            $bytes = $m[0];
            $count = strlen( $bytes );
            $code  = ord( $bytes[0] ) & ( 0xFF >> ( $count + 1 ) );

            for ( $i = 1; $i < $count; $i++ ) {
                $code = ( $code << 6 ) | ( ord( $bytes[ $i ] ) & 0x3F );
            }

            return '&#' . $code . ';';
        },
        $html
    );

    return null === $out ? $html : $out;
}

/**
 * Escape a value for the email HTML, braces included.
 *
 * Resend reads {{{NAME}}} as a template variable, and a variable that the
 * send does not fill stops the email. A brace in the Site Title or the
 * mailing address must stay text, so it becomes an entity.
 *
 * @param string $text Plain text.
 * @return string
 */
function Affiliate_Theme_Theme_email_text( $text ) {
    return str_replace( array( '{', '}' ), array( '&#123;', '&#125;' ), esc_html( $text ) );
}

/**
 * Make the full HTML of one email.
 *
 * The steps run in this order: the body goes into emails/layout.html, the
 * signature goes in, the call to action becomes a button, the bare tags get
 * their styles, the plain links get theirs, the subject and the preview
 * fill their tokens, and the characters past ASCII become entities.
 *
 * The HTML holds the theme's copy only. Every value from the buyer's site
 * stays a Resend variable, written {{{NAME}}}, which the template fills
 * from its fallback values. Then no {{TOKEN}} may be left, and the only
 * variables may be the email's own vars and RESEND_UNSUBSCRIBE_URL, which
 * Resend fills itself: a variable that nothing fills stops the send.
 *
 * @param int   $index The landing page number, 1 to 3.
 * @param array $email One entry from Affiliate_Theme_Theme_email_sequences().
 * @return string|WP_Error
 */
function Affiliate_Theme_Theme_render_email( $index, $email ) {
    $layout_file = get_theme_file_path( 'emails/layout.html' );
    $body_file   = get_theme_file_path( 'emails/landing-' . (int) $index . '/' . $email['file'] . '.html' );

    $layout = is_readable( $layout_file ) ? file_get_contents( $layout_file ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- A local theme file.
    $body   = is_readable( $body_file ) ? file_get_contents( $body_file ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- A local theme file.

    if ( false === $layout || false === $body ) {
        return new WP_Error( 'affiliate_theme_email_missing', sprintf( 'The theme file %s is missing.', false === $layout ? $layout_file : $body_file ) );
    }

    $html = str_replace( '{{BODY}}', trim( $body ), $layout );
    $html = str_replace( '{{SIGNATURE}}', '<p>Talk soon,<br>{{{SITE_NAME}}}</p>', $html );
    $html = Affiliate_Theme_Theme_email_buttons( $html );
    $html = strtr( $html, Affiliate_Theme_Theme_email_styles() );
    $html = preg_replace( '#<a href="([^"]+)">#', '<a href="$1" target="_blank" style="color:#2563eb;text-decoration:underline;">', $html );
    $html = strtr(
        $html,
        array(
            '{{SUBJECT}}' => Affiliate_Theme_Theme_email_text( $email['subject'] ),
            '{{PREVIEW}}' => Affiliate_Theme_Theme_email_text( $email['preview'] ),
        )
    );
    $html = Affiliate_Theme_Theme_email_entities( $html );

    if ( preg_match_all( '/(?<!\{)\{\{[A-Z_]+\}\}(?!\})/', $html, $left ) ) {
        return new WP_Error(
            'affiliate_theme_email_token',
            sprintf( 'emails/landing-%d/%s.html has a token that nothing fills: %s', (int) $index, $email['file'], implode( ', ', array_unique( $left[0] ) ) )
        );
    }

    preg_match_all( '/\{\{\{\s*([^}]*?)\s*\}\}\}/', $html, $vars );
    $unknown = array_diff( array_unique( $vars[1] ), $email['vars'], array( 'RESEND_UNSUBSCRIBE_URL' ) );

    if ( $unknown ) {
        return new WP_Error(
            'affiliate_theme_email_variable',
            sprintf( 'emails/landing-%d/%s.html has a Resend variable that its template does not declare: %s', (int) $index, $email['file'], implode( ', ', $unknown ) )
        );
    }

    return $html;
}

/* -------------------------------------------------------------------------
 * What fills the emails
 * ---------------------------------------------------------------------- */

/**
 * Give the variables of one email's template, with the values that fill
 * them.
 *
 * The template keeps each value as the fallback of its variable, so Resend
 * fills it at every send, and a changed setting reaches the next email of
 * everyone partway through a series. Resend puts a value into the HTML as
 * it is and escapes nothing, so each value here is HTML already: escaped,
 * with braces and every character past ASCII written as entities.
 *
 * An empty value gets no fallback. Resend then refuses to send that email,
 * so no email can go out with a blank affiliate link or without the mailing
 * address. Resend takes 2,000 characters at most for a value.
 *
 * @param array $email    One entry from Affiliate_Theme_Theme_email_sequences().
 * @param array $settings The theme settings.
 * @return array|WP_Error The template's variables: key, type and, when the
 *                        value is not empty, fallback_value.
 */
function Affiliate_Theme_Theme_email_variables( $email, $settings ) {
    $values = array(
        // The automation fills the first name from the sign-up. This is the
        // greeting when the visitor gave none.
        'USER_FIRST_NAME' => 'there',
        'AFFILIATE_URL'   => esc_url( $settings['redirect_url'] ),
        'SITE_NAME'       => Affiliate_Theme_Theme_email_text( Affiliate_Theme_Theme_email_site_name() ),
        'SITE_URL'        => esc_url( home_url( '/' ) ),
        'MAILING_ADDRESS' => str_replace( "\n", '<br>', Affiliate_Theme_Theme_email_text( $settings['mailing_address'] ) ),
        // The site address's scheme, as SITE_URL has it. The theme's own
        // URL takes is_ssl(), which is false behind some proxies and in
        // WP-CLI, and would give the email an http link.
        'GUIDE_URL'       => esc_url( set_url_scheme( get_theme_file_uri( 'assets/lead-magnets/landing-3-guide.pdf' ), (string) wp_parse_url( home_url( '/' ), PHP_URL_SCHEME ) ) ),
    );

    // What the buyer calls each value, for the error below.
    $labels = array(
        'USER_FIRST_NAME' => 'greeting',
        'AFFILIATE_URL'   => 'affiliate redirect URL',
        'SITE_NAME'       => 'Site Title',
        'SITE_URL'        => 'site address',
        'MAILING_ADDRESS' => 'mailing address',
        'GUIDE_URL'       => 'guide link',
    );

    $variables = array();

    foreach ( $email['vars'] as $key ) {
        if ( ! isset( $values[ $key ] ) ) {
            return new WP_Error( 'affiliate_theme_email_value', sprintf( 'The theme has no value for the Resend variable %s.', $key ) );
        }

        $value = Affiliate_Theme_Theme_email_entities( $values[ $key ] );

        if ( strlen( $value ) > 2000 ) {
            return new WP_Error( 'affiliate_theme_email_value', sprintf( 'Your %s is too long for the emails. Resend takes 2,000 characters at most.', $labels[ $key ] ) );
        }

        $variable = array(
            'key'  => $key,
            'type' => 'string',
        );

        if ( '' !== $value ) {
            $variable['fallback_value'] = $value;
        }

        $variables[] = $variable;
    }

    return $variables;
}

/**
 * Make the From line of the emails: a name and an address on the domain.
 *
 * The name is the From name setting, or else the Site Title. A name with
 * punctuation goes in quotes, as the email standard asks.
 *
 * @param array  $settings The theme settings.
 * @param string $domain   The sending domain.
 * @return string
 */
function Affiliate_Theme_Theme_email_from( $settings, $domain ) {
    $name = '' !== $settings['from_name'] ? $settings['from_name'] : Affiliate_Theme_Theme_email_site_name();
    $name = trim( str_replace( array( '"', '\\', '<', '>', "\r", "\n" ), '', $name ) );

    if ( preg_match( '/[^A-Za-z0-9 !#$%&\'*+\/=?^_`{|}~-]/', $name ) ) {
        $name = '"' . $name . '"';
    }

    $address = $settings['from_local'] . '@' . $domain;

    return '' === $name ? $address : $name . ' <' . $address . '>';
}
