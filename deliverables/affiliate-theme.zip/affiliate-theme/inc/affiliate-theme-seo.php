<?php
/**
 * Affiliate Theme — search and social.
 *
 * Contains the description, the social tags and the structured data that
 * the theme prints in <head>, the excerpt field on pages, the sponsored
 * mark on affiliate links, the font preloads, and the search and social
 * part of the settings page.
 *
 * WordPress already prints the title tag, the canonical link of a post or
 * a page, the robots meta tag and the XML sitemaps. Never print a second
 * copy of any of them here.
 *
 * WARNING: Never print the affiliate URL from this file. The REST reply of
 * the opt-in form is the only place it may appear. The sponsored links
 * below read it on the server and write only a rel attribute.
 *
 * @package affiliate-theme
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * An SEO plugin takes over
 * ---------------------------------------------------------------------- */

/**
 * Give the name of the active SEO plugin, if there is one.
 *
 * Each plugin is found by a constant or a function that it defines as it
 * loads. A plugin writes its own description, social tags and structured
 * data, so the theme must not print a second set beside them.
 *
 * @return string The plugin name, or an empty string.
 */
function Affiliate_Theme_Theme_seo_plugin() {
    $plugins = array(
        'Yoast SEO'         => defined( 'WPSEO_VERSION' ),
        'Rank Math'         => defined( 'RANK_MATH_VERSION' ),
        'All in One SEO'    => function_exists( 'aioseo' ),
        'SEOPress'          => defined( 'SEOPRESS_VERSION' ),
        'The SEO Framework' => defined( 'THE_SEO_FRAMEWORK_VERSION' ),
        'Slim SEO'          => defined( 'SLIM_SEO_VER' ),
        'Squirrly SEO'      => defined( 'SQ_VERSION' ),
        'SmartCrawl'        => defined( 'SMARTCRAWL_PLUGIN_BASENAME' ),
    );

    foreach ( $plugins as $name => $active ) {
        if ( $active ) {
            return $name;
        }
    }

    return '';
}

/**
 * Tell if the theme prints its own description, social tags and
 * structured data.
 *
 * The filter turns them off, or back on beside a plugin that the list
 * does not know.
 *
 * @return bool
 */
function Affiliate_Theme_Theme_seo_enabled() {
    return (bool) apply_filters( 'affiliate-theme_seo_enabled', '' === Affiliate_Theme_Theme_seo_plugin() );
}

/**
 * Keep Jetpack from printing a second set of Open Graph tags.
 *
 * @param bool $enabled True if Jetpack prints its tags.
 * @return bool
 */
function Affiliate_Theme_Theme_seo_jetpack_og( $enabled ) {
    return Affiliate_Theme_Theme_seo_enabled() ? false : $enabled;
}
add_filter( 'jetpack_enable_open_graph', 'Affiliate_Theme_Theme_seo_jetpack_og', 99 );

/* -------------------------------------------------------------------------
 * The description
 * ---------------------------------------------------------------------- */

/**
 * Make one line of plain text from a piece of HTML.
 *
 * @param string $html The HTML.
 * @return string
 */
function Affiliate_Theme_Theme_seo_text( $html ) {
    $text = wp_strip_all_tags( strip_shortcodes( (string) $html ) );
    $text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

    return trim( (string) preg_replace( '/[\s\x{00A0}]+/u', ' ', $text ) );
}

/**
 * Cut a description to a length that a results page shows in full.
 *
 * @param string $text The plain text.
 * @return string At most 160 characters.
 */
function Affiliate_Theme_Theme_seo_trim( $text ) {
    if ( mb_strlen( $text ) <= 160 ) {
        return $text;
    }

    $cut = mb_substr( $text, 0, 159 );

    // Back up to the last space after the 80th character. A regex, not
    // mb_strrpos(): WordPress polyfills mb_substr() and mb_strlen() for
    // hosts without mbstring, but not mb_strrpos().
    if ( preg_match( '/^(.{81,}) /su', $cut, $m ) ) {
        $cut = $m[1];
    }

    return (string) preg_replace( '/[\s,.;:\x{2013}\x{2014}-]+$/u', '', $cut ) . '…';
}

/**
 * Find the first paragraph long enough to describe a page.
 *
 * The blocks are parsed, never rendered. A render would run the opt-in
 * form's render.php inside <head>. A paragraph under 50 characters is
 * passed over. That skips the eyebrow line of a landing page, such as
 * FREE INSTANT ACCESS, and the effective date of a legal page, and lands
 * on the first real sentence: on a landing page, the line under the
 * headline.
 *
 * @param string $content The post content.
 * @return string Plain text, or an empty string.
 */
function Affiliate_Theme_Theme_seo_first_paragraph( $content ) {
    if ( ! has_blocks( $content ) ) {
        return Affiliate_Theme_Theme_seo_text( $content );
    }

    return Affiliate_Theme_Theme_seo_find_paragraph( parse_blocks( $content ) );
}

/**
 * Walk a block list, inner blocks included, for the first paragraph of
 * 50 characters or more.
 *
 * @param array $blocks Parsed blocks.
 * @return string Plain text, or an empty string.
 */
function Affiliate_Theme_Theme_seo_find_paragraph( $blocks ) {
    foreach ( $blocks as $block ) {
        if ( 'core/paragraph' === $block['blockName'] ) {
            $text = Affiliate_Theme_Theme_seo_text( $block['innerHTML'] );

            if ( mb_strlen( $text ) >= 50 ) {
                return $text;
            }
        }

        if ( ! empty( $block['innerBlocks'] ) ) {
            $text = Affiliate_Theme_Theme_seo_find_paragraph( $block['innerBlocks'] );

            if ( '' !== $text ) {
                return $text;
            }
        }
    }

    return '';
}

/**
 * Make the description of one post or page.
 *
 * An excerpt that the buyer wrote comes first. The automatic excerpt of
 * WordPress is never used: it starts at the top of the content, which on
 * a landing page is the eyebrow line and the headline.
 *
 * @param WP_Post $post The post.
 * @return string
 */
function Affiliate_Theme_Theme_seo_description( $post ) {
    // A password protects the whole post, its excerpt too. Test the
    // password itself, not the visitor's cookie: a page cache can keep the
    // page that one visitor unlocked.
    if ( '' !== (string) $post->post_password ) {
        return '';
    }

    $text = Affiliate_Theme_Theme_seo_text( $post->post_excerpt );

    if ( '' === $text ) {
        $text = Affiliate_Theme_Theme_seo_first_paragraph( $post->post_content );
    }

    return Affiliate_Theme_Theme_seo_trim( $text );
}

/* -------------------------------------------------------------------------
 * The images
 * ---------------------------------------------------------------------- */

/**
 * Choose the picture that a shared link shows.
 *
 * The featured image comes first. A landing page never displays its
 * featured image, because page-blank has no block for it, so there it is
 * only the share picture. The site icon is the fallback.
 *
 * @param WP_Post|null $post The post, or null.
 * @return array|null The keys url, width, height, alt, featured and large, or null.
 */
function Affiliate_Theme_Theme_seo_image( $post ) {
    if ( $post instanceof WP_Post && has_post_thumbnail( $post ) ) {
        $id  = (int) get_post_thumbnail_id( $post );
        $src = wp_get_attachment_image_src( $id, 'full' );

        if ( $src ) {
            return array(
                'url'      => $src[0],
                'width'    => (int) $src[1],
                'height'   => (int) $src[2],
                'alt'      => Affiliate_Theme_Theme_seo_text( get_post_meta( $id, '_wp_attachment_image_alt', true ) ),
                'featured' => true,
                // X shows the large card only for an image at least 300 x 157.
                'large'    => ( (int) $src[1] >= 300 && (int) $src[2] >= 157 ),
            );
        }
    }

    $icon = (int) get_option( 'site_icon' );
    $src  = $icon ? wp_get_attachment_image_src( $icon, 'full' ) : false;

    if ( $src ) {
        return array(
            'url'      => $src[0],
            'width'    => (int) $src[1],
            'height'   => (int) $src[2],
            'alt'      => '',
            'featured' => false,
            'large'    => false,
        );
    }

    return null;
}

/**
 * Give the site logo, or else the site icon, as a schema.org image.
 *
 * A block theme keeps the logo in the site_logo option. The custom_logo
 * theme mod reads that option.
 *
 * @return array|null
 */
function Affiliate_Theme_Theme_seo_logo() {
    foreach ( array( (int) get_theme_mod( 'custom_logo' ), (int) get_option( 'site_icon' ) ) as $id ) {
        $src = $id ? wp_get_attachment_image_src( $id, 'full' ) : false;

        if ( $src ) {
            return array(
                '@type'  => 'ImageObject',
                'url'    => $src[0],
                'width'  => (int) $src[1],
                'height' => (int) $src[2],
            );
        }
    }

    return null;
}

/* -------------------------------------------------------------------------
 * The head tags
 * ---------------------------------------------------------------------- */

/**
 * Give the site language in the form that Open Graph uses, such as en_US.
 *
 * @return string
 */
function Affiliate_Theme_Theme_seo_locale() {
    return preg_match( '/^[a-z]{2,3}_[A-Z]{2}/', get_locale(), $match ) ? $match[0] : '';
}

/**
 * Work out what the head tags say on this request.
 *
 * The front page, the posts page and every single post or page get the
 * full set. An archive gets its description alone. Search results, a
 * date archive and the 404 page get nothing.
 *
 * @return array|null Null prints nothing.
 */
function Affiliate_Theme_Theme_seo_context() {
    if ( is_front_page() ) {
        // A static front page is the landing page. The latest posts are not one post.
        $post = is_singular() ? get_queried_object() : null;
        $url  = home_url( '/' );
    } elseif ( is_home() ) {
        // The posts page. Its own page holds the excerpt and the featured image.
        $post = get_post( (int) get_option( 'page_for_posts' ) );
        $url  = $post ? (string) get_permalink( $post ) : '';
    } elseif ( is_singular() ) {
        $post = get_queried_object();

        // The same URL as the canonical link that WordPress prints. A draft
        // has no canonical URL, so its preview takes the permalink.
        $url = wp_get_canonical_url( $post );

        if ( ! $url ) {
            $url = (string) get_permalink( $post );
        }
    } elseif ( is_archive() && ! is_date() ) {
        return array(
            'social'      => false,
            'description' => Affiliate_Theme_Theme_seo_trim( Affiliate_Theme_Theme_seo_text( get_the_archive_description() ) ),
        );
    } else {
        return null;
    }

    $post        = $post instanceof WP_Post ? $post : null;
    $description = $post ? Affiliate_Theme_Theme_seo_description( $post ) : '';

    if ( '' === $description && is_front_page() ) {
        $description = Affiliate_Theme_Theme_seo_trim( Affiliate_Theme_Theme_seo_text( get_bloginfo( 'description' ) ) );
    }

    return array(
        'social'      => true,
        'post'        => $post,
        'type'        => is_singular( 'post' ) ? 'article' : 'website',
        // The title tag's own text, so a share and a search result agree.
        'title'       => Affiliate_Theme_Theme_seo_text( wp_get_document_title() ),
        'description' => $description,
        'url'         => $url,
        'image'       => Affiliate_Theme_Theme_seo_image( $post ),
    );
}

/**
 * Print the description, the social tags and the structured data.
 *
 * @return void
 */
function Affiliate_Theme_Theme_seo_head() {
    if ( ! Affiliate_Theme_Theme_seo_enabled() ) {
        return;
    }

    $context = Affiliate_Theme_Theme_seo_context();

    if ( null === $context ) {
        return;
    }

    if ( '' !== $context['description'] ) {
        printf( '<meta name="description" content="%s" />' . "\n", esc_attr( $context['description'] ) );
    }

    if ( empty( $context['social'] ) ) {
        return;
    }

    $image = $context['image'];
    $tags  = array(
        'og:locale'      => Affiliate_Theme_Theme_seo_locale(),
        'og:type'        => $context['type'],
        'og:title'       => $context['title'],
        'og:description' => $context['description'],
        'og:url'         => $context['url'],
        'og:site_name'   => Affiliate_Theme_Theme_seo_text( get_bloginfo( 'name' ) ),
    );

    if ( $image ) {
        $tags['og:image']        = $image['url'];
        $tags['og:image:width']  = $image['width'] ? (string) $image['width'] : '';
        $tags['og:image:height'] = $image['height'] ? (string) $image['height'] : '';
        $tags['og:image:alt']    = $image['alt'];
    }

    if ( 'article' === $context['type'] ) {
        $tags['article:published_time'] = get_post_time( 'c', true, $context['post'] );
        $tags['article:modified_time']  = get_post_modified_time( 'c', true, $context['post'] );
    }

    foreach ( $tags as $property => $value ) {
        if ( ! is_string( $value ) || '' === $value ) {
            continue;
        }

        printf(
            '<meta property="%s" content="%s" />' . "\n",
            esc_attr( $property ),
            in_array( $property, array( 'og:url', 'og:image' ), true ) ? esc_url( $value ) : esc_attr( $value )
        );
    }

    printf( '<meta name="twitter:card" content="%s" />' . "\n", ( $image && $image['large'] ) ? 'summary_large_image' : 'summary' );

    $schema = Affiliate_Theme_Theme_seo_schema( $context );
    $json   = $schema ? wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) : false;

    // JSON_HEX_TAG writes < and > as \u003C and \u003E, so no text in the
    // data can close the script tag.
    if ( $json ) {
        printf( '<script type="application/ld+json">%s</script>' . "\n", $json ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON with every < and > escaped.
    }
}
add_action( 'wp_head', 'Affiliate_Theme_Theme_seo_head', 5 );

/* -------------------------------------------------------------------------
 * The structured data
 * ---------------------------------------------------------------------- */

/**
 * Build the structured data for this request.
 *
 * The front page describes the site and who publishes it. A blog post
 * describes the article. Nothing else gets any. There is no Product or
 * Review markup on purpose: markup for offers that the buyer does not
 * sell breaks Google's structured data rules. There is no FAQ, HowTo,
 * BreadcrumbList or SearchAction either: the site shows none of those.
 *
 * @param array $context The values from Affiliate_Theme_Theme_seo_context().
 * @return array|null
 */
function Affiliate_Theme_Theme_seo_schema( $context ) {
    $home         = home_url( '/' );
    $organization = array(
        '@type' => 'Organization',
        '@id'   => $home . '#organization',
        'name'  => Affiliate_Theme_Theme_seo_text( get_bloginfo( 'name' ) ),
        'url'   => $home,
    );
    $logo         = Affiliate_Theme_Theme_seo_logo();

    if ( $logo ) {
        $organization['logo'] = $logo;
    }

    if ( is_front_page() ) {
        $website = array(
            '@type'      => 'WebSite',
            '@id'        => $home . '#website',
            'url'        => $home,
            'name'       => $organization['name'],
            'inLanguage' => get_bloginfo( 'language' ),
            'publisher'  => array( '@id' => $organization['@id'] ),
        );
        $tagline = Affiliate_Theme_Theme_seo_text( get_bloginfo( 'description' ) );

        if ( '' !== $tagline ) {
            $website['description'] = $tagline;
        }

        return array(
            '@context' => 'https://schema.org',
            '@graph'   => array( $website, $organization ),
        );
    }

    if ( 'article' !== $context['type'] || ! $context['post'] instanceof WP_Post ) {
        return null;
    }

    $post    = $context['post'];
    $author  = Affiliate_Theme_Theme_seo_text( get_the_author_meta( 'display_name', (int) $post->post_author ) );
    $article = array(
        '@context'         => 'https://schema.org',
        '@type'            => 'BlogPosting',
        '@id'              => $context['url'] . '#article',
        'mainEntityOfPage' => $context['url'],
        'headline'         => Affiliate_Theme_Theme_seo_text( get_the_title( $post ) ),
        'datePublished'    => get_post_time( 'c', true, $post ),
        'dateModified'     => get_post_modified_time( 'c', true, $post ),
        'publisher'        => $organization,
        'inLanguage'       => get_bloginfo( 'language' ),
    );

    // A post imported without a user has no author. An empty name is
    // invalid, so leave the author out.
    if ( '' !== $author ) {
        $article['author'] = array(
            '@type' => 'Person',
            'name'  => $author,
            'url'   => get_author_posts_url( (int) $post->post_author ),
        );
    }

    if ( '' !== $context['description'] ) {
        $article['description'] = $context['description'];
    }

    if ( $context['image'] && $context['image']['featured'] ) {
        $article['image'] = $context['image']['url'];
    }

    return $article;
}

/* -------------------------------------------------------------------------
 * The excerpt on pages
 * ---------------------------------------------------------------------- */

/**
 * Give pages the excerpt field.
 *
 * A page's excerpt is its description in search results and in a shared
 * link, in place of the first paragraph. WordPress gives the field to
 * posts only.
 *
 * @return void
 */
function Affiliate_Theme_Theme_seo_page_excerpts() {
    add_post_type_support( 'page', 'excerpt' );
}
add_action( 'init', 'Affiliate_Theme_Theme_seo_page_excerpts' );

/* -------------------------------------------------------------------------
 * Sponsored affiliate links
 * ---------------------------------------------------------------------- */

/**
 * Give the host of a URL in the form that the sponsored links compare.
 *
 * @param mixed $url The URL.
 * @return string The host in lowercase without a leading www., or an empty string.
 */
function Affiliate_Theme_Theme_seo_host( $url ) {
    $host = is_string( $url ) ? strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) : '';

    return str_starts_with( $host, 'www.' ) ? substr( $host, 4 ) : $host;
}

/**
 * Give the hosts whose links count as affiliate links.
 *
 * The host of the affiliate link is one, unless it is the site's
 * own host. A buyer who cloaks links, such as example.com/go/offer, would
 * otherwise have every link to their own site marked. The filter adds
 * the hosts of other affiliate programs.
 *
 * @return array
 */
function Affiliate_Theme_Theme_sponsored_hosts() {
    $settings = Affiliate_Theme_Theme_get_settings();
    $host     = Affiliate_Theme_Theme_seo_host( $settings['redirect_url'] );
    $hosts    = array();

    if ( '' !== $host && Affiliate_Theme_Theme_seo_host( home_url() ) !== $host ) {
        $hosts[] = $host;
    }

    $clean = array();

    foreach ( (array) apply_filters( 'affiliate-theme_sponsored_hosts', $hosts ) as $item ) {
        $item = strtolower( trim( (string) $item ) );
        $item = str_starts_with( $item, 'www.' ) ? substr( $item, 4 ) : $item;

        if ( '' !== $item ) {
            $clean[ $item ] = true;
        }
    }

    return array_keys( $clean );
}

/**
 * Mark the affiliate links in post content as sponsored.
 *
 * Google asks that an affiliate link carry rel="sponsored". The nofollow
 * beside it serves search engines that know only that. The words already
 * in rel, such as noopener, stay.
 *
 * This covers post and page content, the buttons in it included. It does
 * not reach the navigation menu.
 *
 * @param string $content The post content.
 * @return string
 */
function Affiliate_Theme_Theme_sponsored_links( $content ) {
    if ( ! is_string( $content ) || false === stripos( $content, '<a' ) ) {
        return $content;
    }

    $hosts = Affiliate_Theme_Theme_sponsored_hosts();

    if ( empty( $hosts ) ) {
        return $content;
    }

    $tags = new WP_HTML_Tag_Processor( $content );

    while ( $tags->next_tag( 'a' ) ) {
        if ( ! in_array( Affiliate_Theme_Theme_seo_host( $tags->get_attribute( 'href' ) ), $hosts, true ) ) {
            continue;
        }

        $rel = $tags->get_attribute( 'rel' );
        $rel = preg_split( '/\s+/', strtolower( is_string( $rel ) ? $rel : '' ), -1, PREG_SPLIT_NO_EMPTY );

        $tags->set_attribute( 'rel', implode( ' ', array_unique( array_merge( $rel, array( 'sponsored', 'nofollow' ) ) ) ) );
    }

    return $tags->get_updated_html();
}
add_filter( 'the_content', 'Affiliate_Theme_Theme_sponsored_links', 25 );

/* -------------------------------------------------------------------------
 * Font preloads
 * ---------------------------------------------------------------------- */

/**
 * Start the two main fonts downloading before the stylesheet asks for them.
 *
 * WARNING: each href must be exactly the URL that WordPress prints for the
 * fontFace src in theme.json: get_theme_file_uri() of the file, with no
 * ?ver. Any difference and the browser fetches the font twice. Rename or
 * move a font file and this list must follow.
 *
 * A font is preloaded only while Global Styles still use it, so a buyer
 * who picks other fonts in the Site Editor downloads nothing extra.
 *
 * @param array $resources The resources to preload.
 * @return array
 */
function Affiliate_Theme_Theme_preload_fonts( $resources ) {
    $fonts = array(
        'archivo'    => array(
            'path' => array( 'elements', 'heading', 'typography', 'fontFamily' ),
            'file' => 'assets/fonts/Archivo/Archivo-VariableFont_wdth_wght.woff2',
        ),
        'newsreader' => array(
            'path' => array( 'typography', 'fontFamily' ),
            'file' => 'assets/fonts/Newsreader/Newsreader-VariableFont_opsz_wght.woff2',
        ),
    );

    foreach ( $fonts as $slug => $font ) {
        // A path that is not set returns the whole styles array, not a string.
        $family = wp_get_global_styles( $font['path'] );

        if ( ! is_string( $family ) || false === stripos( $family, $slug ) ) {
            continue;
        }

        $resources[] = array(
            'href'        => get_theme_file_uri( $font['file'] ),
            'as'          => 'font',
            'type'        => 'font/woff2',
            'crossorigin' => 'anonymous',
        );
    }

    return $resources;
}
add_filter( 'wp_preload_resources', 'Affiliate_Theme_Theme_preload_fonts' );

/* -------------------------------------------------------------------------
 * The settings page
 * ---------------------------------------------------------------------- */

/**
 * Print the search and social part of the settings page.
 *
 * @return void
 */
function Affiliate_Theme_Theme_seo_render_settings_section() {
    echo '<h2>Search and social</h2>';

    if ( ! get_option( 'blog_public' ) ) {
        printf(
            '<div class="notice notice-warning inline"><p>Search engines are asked not to index this site. When the site is ready, go to <a href="%s">Settings &rarr; Reading</a> and clear &#8220;Discourage search engines from indexing this site&#8221;.</p></div>',
            esc_url( admin_url( 'options-reading.php' ) )
        );
    }

    $plugin = Affiliate_Theme_Theme_seo_plugin();

    if ( '' !== $plugin ) {
        printf(
            '<p><strong>%s is active.</strong> It writes the page descriptions, the social previews and the structured data, so the theme&#8217;s own are off.</p>',
            esc_html( $plugin )
        );
    } elseif ( ! Affiliate_Theme_Theme_seo_enabled() ) {
        echo '<p>The theme&#8217;s page descriptions, social previews and structured data are turned off on this site.</p>';
    }

    $hosts = Affiliate_Theme_Theme_sponsored_hosts();

    if ( ! empty( $hosts ) ) {
        printf(
            '<p>Links to %s in your posts and pages are marked <code>rel="sponsored nofollow"</code>, as Google asks of affiliate links.</p>',
            esc_html( implode( ', ', $hosts ) )
        );
    }
}
