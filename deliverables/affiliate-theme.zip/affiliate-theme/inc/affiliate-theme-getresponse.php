<?php
/**
 * Affiliate Theme — GetResponse integration.
 *
 * Contains the settings page, the list check, the GetResponse client,
 * the REST routes, the activation seeder, the landing patterns, and the
 * opt-in block registration.
 *
 * @package affiliate-theme
 */

defined( 'ABSPATH' ) || exit;

const AFFILIATE_THEME_OPTION       = 'affiliate-theme_settings';
const AFFILIATE_THEME_SEED_FLAG    = 'affiliate-theme_pages_created';
const AFFILIATE_THEME_REST_NS      = 'affiliate-theme/v1';
const AFFILIATE_THEME_GR_BASE      = 'https://api.getresponse.com/v3';
const AFFILIATE_THEME_RATE_SECONDS = 60;
const AFFILIATE_THEME_KEY_MASK     = '••••••••';

/* -------------------------------------------------------------------------
 * Shared helpers
 * ---------------------------------------------------------------------- */

/**
 * Read the theme settings with the defaults applied.
 *
 * @return array
 */
function Affiliate_Theme_Theme_get_settings() {
    $defaults = array(
        'gr_api_key'      => '',
        'gr_campaign_id'  => '',
        'redirect_url'    => '',
        'success_message' => 'Thanks! Check your inbox for the next step.',
        'page_ids'        => array(),
        'legal_page_ids'  => array(),
    );

    $settings = get_option( AFFILIATE_THEME_OPTION, array() );

    if ( ! is_array( $settings ) ) {
        $settings = array();
    }

    return wp_parse_args( $settings, $defaults );
}

/**
 * Tell if the theme has the settings that the form needs.
 *
 * @return bool
 */
function Affiliate_Theme_Theme_is_configured() {
    $settings = Affiliate_Theme_Theme_get_settings();

    return ( '' !== $settings['gr_api_key'] && '' !== $settings['gr_campaign_id'] );
}

/**
 * Make the masked form of an API key.
 *
 * @param string $key The API key.
 * @return string
 */
function Affiliate_Theme_Theme_mask_key( $key ) {
    if ( '' === $key ) {
        return '';
    }

    return AFFILIATE_THEME_KEY_MASK . substr( $key, -4 );
}

/* -------------------------------------------------------------------------
 * Section c — the GetResponse client
 * ---------------------------------------------------------------------- */

/**
 * Send one request to the GetResponse API.
 *
 * The API key stays in PHP. No caller sends it to the browser.
 *
 * @param string     $method  The HTTP method.
 * @param string     $path    The path after /v3.
 * @param array|null $body    The body to encode, or null.
 * @param string     $api_key An API key that replaces the stored key.
 * @return array|WP_Error
 */
function Affiliate_Theme_Theme_gr_request( $method, $path, $body = null, $api_key = '' ) {
    if ( '' === $api_key ) {
        $settings = Affiliate_Theme_Theme_get_settings();
        $api_key  = $settings['gr_api_key'];
    }

    if ( '' === $api_key ) {
        return new WP_Error( 'affiliate_theme_no_key', 'No GetResponse API key is set.' );
    }

    $args = array(
        'method'  => $method,
        'timeout' => 15,
        'headers' => array(
            'X-Auth-Token' => 'api-key ' . $api_key,
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        ),
    );

    if ( null !== $body ) {
        $args['body'] = wp_json_encode( $body );
    }

    return wp_remote_request( AFFILIATE_THEME_GR_BASE . $path, $args );
}

/**
 * Read the JSON body of a GetResponse reply.
 *
 * GetResponse sends booleans as text, for example "isDefault":"true".
 * Test those values for truth. Do not use a strict comparison.
 *
 * @param array $response A wp_remote_request reply.
 * @return array
 */
function Affiliate_Theme_Theme_gr_body( $response ) {
    $decoded = json_decode( wp_remote_retrieve_body( $response ), true );

    return is_array( $decoded ) ? $decoded : array();
}

/* -------------------------------------------------------------------------
 * Section b — check the list token
 * ---------------------------------------------------------------------- */

/**
 * Check one list token against the GetResponse API.
 *
 * @param string $api_key The API key.
 * @param string $token   The list token, for example 7qhMJ.
 * @param bool   $force   True reads past the cache.
 * @return array An array with the keys ok, name, and message.
 */
function Affiliate_Theme_Theme_validate_list( $api_key, $token, $force = false ) {
    $fail_note = 'GetResponse did not accept that list token. A list token looks like 7qhMJ. Find it in your GetResponse account, in the list settings, under the box with the label "List name".';

    if ( '' === $api_key || '' === $token ) {
        return array(
            'ok'      => false,
            'name'    => '',
            'message' => 'Add your API key and your list token, then save. The list appears after both values are correct.',
        );
    }

    $cache_key = 'affiliate-theme_gr_list_' . md5( $api_key . '|' . $token );

    if ( ! $force ) {
        $cached = get_transient( $cache_key );

        if ( is_array( $cached ) ) {
            return $cached;
        }
    }

    $response = Affiliate_Theme_Theme_gr_request( 'GET', '/campaigns/' . rawurlencode( $token ), null, $api_key );

    if ( is_wp_error( $response ) ) {
        // Do not cache a network fault. The next page load tries again.
        return array(
            'ok'      => false,
            'name'    => '',
            'message' => 'WordPress could not reach GetResponse: ' . $response->get_error_message(),
        );
    }

    $code = (int) wp_remote_retrieve_response_code( $response );
    $body = Affiliate_Theme_Theme_gr_body( $response );

    if ( 200 === $code && ! empty( $body['campaignId'] ) ) {
        $result = array(
            'ok'      => true,
            'name'    => isset( $body['name'] ) ? (string) $body['name'] : (string) $body['campaignId'],
            'token'   => (string) $body['campaignId'],
            'message' => '',
        );

        set_transient( $cache_key, $result, 10 * MINUTE_IN_SECONDS );

        return $result;
    }

    if ( 401 === $code ) {
        $result = array(
            'ok'      => false,
            'name'    => '',
            'message' => 'GetResponse rejected the API key. Make a new key in GetResponse, in Integrations & API, then paste it again. An unused key stops after 90 days.',
        );
    } else {
        $result = array(
            'ok'      => false,
            'name'    => '',
            'message' => $fail_note,
        );
    }

    set_transient( $cache_key, $result, MINUTE_IN_SECONDS );

    return $result;
}

/**
 * Delete every cached list check.
 *
 * @return void
 */
function Affiliate_Theme_Theme_flush_list_cache() {
    global $wpdb;

    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            $wpdb->esc_like( '_transient_affiliate-theme_gr_list_' ) . '%',
            $wpdb->esc_like( '_transient_timeout_affiliate-theme_gr_list_' ) . '%'
        )
    );
}

/* -------------------------------------------------------------------------
 * Section a — the settings page
 * ---------------------------------------------------------------------- */

/**
 * Register the setting and its fields.
 *
 * @return void
 */
function Affiliate_Theme_Theme_register_settings() {
    register_setting(
        'affiliate-theme_settings_group',
        AFFILIATE_THEME_OPTION,
        array(
            'type'              => 'array',
            'sanitize_callback' => 'Affiliate_Theme_Theme_sanitize_settings',
            'show_in_rest'      => false,
            'default'           => array(),
        )
    );

    add_settings_section(
        'affiliate-theme_section_getresponse',
        'GetResponse',
        'Affiliate_Theme_Theme_section_getresponse',
        'affiliate-theme-settings'
    );

    add_settings_field(
        'gr_api_key',
        'GetResponse API key',
        'Affiliate_Theme_Theme_field_api_key',
        'affiliate-theme-settings',
        'affiliate-theme_section_getresponse',
        array( 'label_for' => 'affiliate-theme-gr-api-key' )
    );

    add_settings_field(
        'gr_campaign_id',
        'GetResponse list token',
        'Affiliate_Theme_Theme_field_campaign_token',
        'affiliate-theme-settings',
        'affiliate-theme_section_getresponse',
        array( 'label_for' => 'affiliate-theme-gr-token' )
    );

    add_settings_field(
        'gr_campaign_select',
        'GetResponse list',
        'Affiliate_Theme_Theme_field_campaign_select',
        'affiliate-theme-settings',
        'affiliate-theme_section_getresponse',
        array( 'label_for' => 'affiliate-theme-gr-list' )
    );

    add_settings_section(
        'affiliate-theme_section_funnel',
        'Funnel',
        'Affiliate_Theme_Theme_section_funnel',
        'affiliate-theme-settings'
    );

    add_settings_field(
        'redirect_url',
        'Affiliate redirect URL',
        'Affiliate_Theme_Theme_field_redirect_url',
        'affiliate-theme-settings',
        'affiliate-theme_section_funnel',
        array( 'label_for' => 'affiliate-theme-redirect-url' )
    );

    add_settings_field(
        'success_message',
        'Success message',
        'Affiliate_Theme_Theme_field_success_message',
        'affiliate-theme-settings',
        'affiliate-theme_section_funnel',
        array( 'label_for' => 'affiliate-theme-success-message' )
    );
}
add_action( 'admin_init', 'Affiliate_Theme_Theme_register_settings' );

/**
 * Clean the submitted settings.
 *
 * An empty key field, or a masked key field, keeps the stored key. This
 * keeps the key safe from browser autofill and from an accidental save.
 *
 * @param mixed $input The submitted values.
 * @return array
 */
function Affiliate_Theme_Theme_sanitize_settings( $input ) {
    $old = Affiliate_Theme_Theme_get_settings();
    $new = $old;

    if ( ! is_array( $input ) ) {
        $input = array();
    }

    // The API key.
    $submitted_key = isset( $input['gr_api_key'] ) ? sanitize_text_field( wp_unslash( $input['gr_api_key'] ) ) : '';
    $submitted_key = trim( $submitted_key );

    if ( '' === $submitted_key || Affiliate_Theme_Theme_mask_key( $old['gr_api_key'] ) === $submitted_key ) {
        $new['gr_api_key'] = $old['gr_api_key'];
    } elseif ( preg_match( '/^[A-Za-z0-9._-]{16,128}$/', $submitted_key ) ) {
        $new['gr_api_key'] = $submitted_key;
    } else {
        $new['gr_api_key'] = $old['gr_api_key'];
        add_settings_error(
            AFFILIATE_THEME_OPTION,
            'affiliate-theme_bad_key',
            'That does not look like a GetResponse API key. A key is 16 characters or more, with letters and numbers only. The theme kept the key that was there.'
        );
    }

    // The list token. The dropdown wins when it has a value.
    $token = '';

    if ( ! empty( $input['gr_campaign_select'] ) ) {
        $token = sanitize_text_field( wp_unslash( $input['gr_campaign_select'] ) );
    } elseif ( isset( $input['gr_campaign_id'] ) ) {
        $token = sanitize_text_field( wp_unslash( $input['gr_campaign_id'] ) );
    }

    $new['gr_campaign_id'] = trim( $token );

    // The affiliate redirect URL.
    $url = isset( $input['redirect_url'] ) ? esc_url_raw( trim( wp_unslash( $input['redirect_url'] ) ) ) : '';

    if ( '' !== $url && ! wp_http_validate_url( $url ) ) {
        add_settings_error(
            AFFILIATE_THEME_OPTION,
            'affiliate-theme_bad_url',
            'The affiliate redirect URL is not a usable address. Start it with https://.'
        );
        $url = '';
    }

    $new['redirect_url'] = $url;

    // The success message.
    if ( isset( $input['success_message'] ) ) {
        $new['success_message'] = sanitize_text_field( wp_unslash( $input['success_message'] ) );
    }

    // Never let the form write the seeded page IDs.
    $new['page_ids']       = isset( $old['page_ids'] ) && is_array( $old['page_ids'] ) ? $old['page_ids'] : array();
    $new['legal_page_ids'] = isset( $old['legal_page_ids'] ) && is_array( $old['legal_page_ids'] ) ? $old['legal_page_ids'] : array();

    Affiliate_Theme_Theme_flush_list_cache();

    return $new;
}

/**
 * Print the text of the GetResponse section.
 *
 * @return void
 */
function Affiliate_Theme_Theme_section_getresponse() {
    echo '<p>Make an API key in GetResponse, in <strong>Integrations &amp; API &rarr; API</strong>. Copy the list token from the list settings. GetResponse automation workflows need a paid plan. New accounts get them free for the first 14 days.</p>';
}

/**
 * Print the text of the funnel section.
 *
 * @return void
 */
function Affiliate_Theme_Theme_section_funnel() {
    echo '<p>The browser goes to this address after the form sends the contact. The address is never in the page HTML.</p>';
}

/**
 * Print the API key field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_api_key() {
    $settings = Affiliate_Theme_Theme_get_settings();
    $mask     = Affiliate_Theme_Theme_mask_key( $settings['gr_api_key'] );

    printf(
        '<input type="password" id="affiliate-theme-gr-api-key" class="regular-text" name="%s[gr_api_key]" value="%s" autocomplete="off" spellcheck="false" />',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $mask )
    );

    if ( '' === $settings['gr_api_key'] ) {
        echo '<p class="description">No key is stored yet.</p>';
    } else {
        echo '<p class="description">A key is stored. Leave this field as it is to keep that key. Type a new key to replace it.</p>';
    }
}

/**
 * Print the list token field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_campaign_token() {
    $settings = Affiliate_Theme_Theme_get_settings();

    printf(
        '<input type="text" id="affiliate-theme-gr-token" class="regular-text code" name="%s[gr_campaign_id]" value="%s" autocomplete="off" spellcheck="false" placeholder="7qhMJ" />',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $settings['gr_campaign_id'] )
    );

    echo ' <button type="button" class="button" id="affiliate-theme-check-list">Check list</button>';
    echo '<p class="description">A list token looks like <code>7qhMJ</code>. Find it in your GetResponse account, in the list settings, under the box with the label &#8220;List name&#8221;.</p>';
}

/**
 * Print the list dropdown.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_campaign_select() {
    $settings = Affiliate_Theme_Theme_get_settings();
    $check    = Affiliate_Theme_Theme_validate_list( $settings['gr_api_key'], $settings['gr_campaign_id'] );

    echo '<select id="affiliate-theme-gr-list" name="' . esc_attr( AFFILIATE_THEME_OPTION ) . '[gr_campaign_select]"';

    if ( empty( $check['ok'] ) ) {
        echo ' disabled="disabled"';
    }

    echo '>';

    if ( ! empty( $check['ok'] ) ) {
        printf(
            '<option value="%1$s" selected="selected">%2$s (%1$s)</option>',
            esc_attr( $settings['gr_campaign_id'] ),
            esc_html( $check['name'] )
        );
    } else {
        echo '<option value="">No list is available</option>';
    }

    echo '</select>';

    echo '<p class="description" id="affiliate-theme-list-note">';

    if ( ! empty( $check['ok'] ) ) {
        echo 'GetResponse accepted this list.';
    } else {
        echo esc_html( $check['message'] );
    }

    echo '</p>';
}

/**
 * Print the affiliate URL field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_redirect_url() {
    $settings = Affiliate_Theme_Theme_get_settings();

    printf(
        '<input type="url" id="affiliate-theme-redirect-url" class="regular-text" name="%s[redirect_url]" value="%s" placeholder="https://" />',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $settings['redirect_url'] )
    );

    echo '<p class="description">Leave this empty to show the success message on the page instead.</p>';
}

/**
 * Print the success message field.
 *
 * @return void
 */
function Affiliate_Theme_Theme_field_success_message() {
    $settings = Affiliate_Theme_Theme_get_settings();

    printf(
        '<input type="text" id="affiliate-theme-success-message" class="large-text" name="%s[success_message]" value="%s" />',
        esc_attr( AFFILIATE_THEME_OPTION ),
        esc_attr( $settings['success_message'] )
    );
}

/**
 * Add the settings page under Settings.
 *
 * @return void
 */
function Affiliate_Theme_Theme_admin_menu() {
    add_options_page(
        'Affiliate Theme Settings',
        'Affiliate Theme Settings',
        'manage_options',
        'affiliate-theme-settings',
        'Affiliate_Theme_Theme_render_settings_page'
    );
}
add_action( 'admin_menu', 'Affiliate_Theme_Theme_admin_menu' );

/**
 * Print the settings page.
 *
 * @return void
 */
function Affiliate_Theme_Theme_render_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $settings = Affiliate_Theme_Theme_get_settings();

    echo '<div class="wrap">';
    echo '<h1>Affiliate Theme Settings</h1>';

    settings_errors( AFFILIATE_THEME_OPTION );

    echo '<form action="options.php" method="post">';
    settings_fields( 'affiliate-theme_settings_group' );
    do_settings_sections( 'affiliate-theme-settings' );
    submit_button();
    echo '</form>';

    if ( ! empty( $settings['page_ids'] ) ) {
        echo '<h2>Your landing pages</h2>';
        echo '<p>The theme made these pages as drafts. Edit the copy, then publish the page that you want.</p>';
        Affiliate_Theme_Theme_render_page_list( $settings['page_ids'] );
    }

    if ( ! empty( $settings['legal_page_ids'] ) ) {
        echo '<h2>Your legal pages</h2>';
        echo '<p>The theme made these pages as drafts too.</p>';
        echo '<ol>';
        echo '<li>Replace every bracketed placeholder on all four pages: <code>[Your Business Name]</code>, <code>[yoursite.com]</code>, <code>[you@example.com]</code>, <code>[Your Mailing Address]</code>, <code>[Your State/Country]</code> and <code>[Month Day, Year]</code>. The Analytics and Advertising section below has a seventh, <code>[Provider Name]</code>.</li>';
        echo '<li>Keep each legal page true to your business.</li>';
        echo '<li>Then publish. A published legal page adds itself to the site footer and there is a footer at the bottom of every landing page.</li>';
        echo '</ol>';
        echo '<h3>If you add analytics, advertising or cookies</h3>';
        echo '<p>The Privacy Policy says you do not sell or share your visitors&#8217; information. That is true only while the site runs no analytics, no advertising pixels and no tracking cookies. If you start using Google Analytics, any advertising platform or cookies, replace its &#8220;We Do Not Sell Or Share Your Information&#8221; section:</p>';
        echo '<ol>';
        echo '<li>Edit the Privacy Policy page.</li>';
        echo '<li>Remove the &#8220;We Do Not Sell Or Share Your Information&#8221; heading block and the paragraph block after it.</li>';
        echo '<li>Click the <strong>+</strong> box in the upper left corner.</li>';
        echo '<li>Switch from the <strong>Blocks</strong> tab to the <strong>Patterns</strong> tab.</li>';
        echo '<li>Select <strong>Affiliate Theme</strong>.</li>';
        echo '<li>Insert <strong>Legal &#8212; Privacy: Analytics and Advertising</strong> where the removed section was, after &#8220;Who We Share It With&#8221;, and replace <code>[Provider Name]</code> with each provider you use.</li>';
        echo '</ol>';
        echo '<p><strong>This text is a starting template, not legal advice.</strong></p>';
        Affiliate_Theme_Theme_render_page_list( $settings['legal_page_ids'] );
    }

    echo '</div>';
}

/**
 * Print a list of seeded pages with their edit links and their status.
 *
 * @param array $page_ids The page IDs.
 * @return void
 */
function Affiliate_Theme_Theme_render_page_list( $page_ids ) {
    echo '<ul>';

    foreach ( (array) $page_ids as $page_id ) {
        $page = get_post( (int) $page_id );

        if ( ! $page ) {
            continue;
        }

        printf(
            '<li><a href="%s">%s</a> &mdash; %s</li>',
            esc_url( get_edit_post_link( $page->ID ) ),
            esc_html( get_the_title( $page->ID ) ),
            esc_html( $page->post_status )
        );
    }

    echo '</ul>';
}

/**
 * Load the settings page script.
 *
 * @param string $hook The current admin page.
 * @return void
 */
function Affiliate_Theme_Theme_admin_enqueue( $hook ) {
    if ( 'settings_page_affiliate-theme-settings' !== $hook ) {
        return;
    }

    wp_enqueue_script(
        'affiliate-theme-admin-settings',
        get_template_directory_uri() . '/assets/js/admin-settings.js',
        array(),
        AFFILIATE_THEME_VERSION,
        true
    );

    wp_localize_script(
        'affiliate-theme-admin-settings',
        'affiliateThemeAdmin',
        array(
            'restUrl' => esc_url_raw( rest_url( AFFILIATE_THEME_REST_NS . '/validate-list' ) ),
            'nonce'   => wp_create_nonce( 'wp_rest' ),
            'mask'    => Affiliate_Theme_Theme_mask_key( Affiliate_Theme_Theme_get_settings()['gr_api_key'] ),
        )
    );
}
add_action( 'admin_enqueue_scripts', 'Affiliate_Theme_Theme_admin_enqueue' );

/* -------------------------------------------------------------------------
 * Sections b and d — the REST routes
 * ---------------------------------------------------------------------- */

/**
 * Register the theme REST routes.
 *
 * @return void
 */
function Affiliate_Theme_Theme_register_rest_routes() {
    register_rest_route(
        AFFILIATE_THEME_REST_NS,
        '/subscribe',
        array(
            'methods'             => 'POST',
            'callback'            => 'Affiliate_Theme_Theme_subscribe_handler',
            'permission_callback' => '__return_true',
        )
    );

    register_rest_route(
        AFFILIATE_THEME_REST_NS,
        '/validate-list',
        array(
            'methods'             => 'POST',
            'callback'            => 'Affiliate_Theme_Theme_validate_list_handler',
            'permission_callback' => 'Affiliate_Theme_Theme_admin_permissions',
        )
    );
}
add_action( 'rest_api_init', 'Affiliate_Theme_Theme_register_rest_routes' );

/**
 * Let an administrator through.
 *
 * @return bool
 */
function Affiliate_Theme_Theme_admin_permissions() {
    return current_user_can( 'manage_options' );
}

/**
 * Check a list token for the settings page.
 *
 * @param WP_REST_Request $request The request.
 * @return WP_REST_Response
 */
function Affiliate_Theme_Theme_validate_list_handler( WP_REST_Request $request ) {
    $settings = Affiliate_Theme_Theme_get_settings();

    $api_key = (string) $request->get_param( 'api_key' );
    $api_key = trim( sanitize_text_field( $api_key ) );
    $token   = trim( sanitize_text_field( (string) $request->get_param( 'token' ) ) );

    // An empty or masked key means "use the key that is stored".
    if ( '' === $api_key || Affiliate_Theme_Theme_mask_key( $settings['gr_api_key'] ) === $api_key ) {
        $api_key = $settings['gr_api_key'];
    }

    $check = Affiliate_Theme_Theme_validate_list( $api_key, $token, true );

    return new WP_REST_Response(
        array(
            'ok'      => ! empty( $check['ok'] ),
            'name'    => isset( $check['name'] ) ? $check['name'] : '',
            'token'   => $token,
            'message' => ! empty( $check['ok'] ) ? 'GetResponse accepted this list.' : $check['message'],
        ),
        200
    );
}

/**
 * Take one opt-in form submission.
 *
 * @param WP_REST_Request $request The request.
 * @return WP_REST_Response
 */
function Affiliate_Theme_Theme_subscribe_handler( WP_REST_Request $request ) {
    $settings = Affiliate_Theme_Theme_get_settings();
    $generic  = 'Something went wrong. Please try again.';

    // Step 1. The honeypot. A robot filled it. Report success and do nothing.
    $honeypot = (string) $request->get_param( 'website' );

    if ( '' !== trim( $honeypot ) ) {
        return new WP_REST_Response(
            array(
                'ok'      => true,
                'message' => $settings['success_message'],
            ),
            200
        );
    }

    // Step 2. The email address.
    $email = sanitize_email( (string) $request->get_param( 'email' ) );

    if ( ! is_email( $email ) ) {
        return new WP_REST_Response(
            array(
                'ok'      => false,
                'message' => 'Please enter a valid email address.',
            ),
            400
        );
    }

    $name = sanitize_text_field( (string) $request->get_param( 'name' ) );

    // Step 3. The rate limit for this address.
    $rate_key = 'affiliate-theme_rl_' . md5( strtolower( $email ) );

    if ( get_transient( $rate_key ) ) {
        return new WP_REST_Response(
            array(
                'ok'      => false,
                'message' => 'Please try again in a moment.',
            ),
            429
        );
    }

    // Step 4. The settings.
    if ( '' === $settings['gr_api_key'] || '' === $settings['gr_campaign_id'] ) {
        error_log( 'Affiliate Theme: a visitor sent the opt-in form, but the GetResponse API key or the list token is missing.' );

        return new WP_REST_Response(
            array(
                'ok'      => false,
                'message' => $generic,
            ),
            500
        );
    }

    // Step 5. The GetResponse call.
    $body = array(
        'email'    => $email,
        'campaign' => array( 'campaignId' => $settings['gr_campaign_id'] ),
    );

    if ( '' !== $name ) {
        $body['name'] = $name;
    }

    $response = Affiliate_Theme_Theme_gr_request( 'POST', '/contacts', $body );

    if ( is_wp_error( $response ) ) {
        error_log( 'Affiliate Theme: GetResponse is unreachable: ' . $response->get_error_message() );

        return new WP_REST_Response(
            array(
                'ok'      => false,
                'message' => 'Service unavailable. Please try again shortly.',
            ),
            502
        );
    }

    // GetResponse answered. Hold this address for a moment. A caller who
    // reached nothing is never limited, so the advice above stays honest.
    set_transient( $rate_key, 1, AFFILIATE_THEME_RATE_SECONDS );

    // Step 6. Map the reply.
    $code    = (int) wp_remote_retrieve_response_code( $response );
    $decoded = Affiliate_Theme_Theme_gr_body( $response );
    $gr_code = isset( $decoded['code'] ) ? (int) $decoded['code'] : 0;

    // 202 means that the contact is in a queue. 409 or code 1008 means a
    // duplicate contact. A person who subscribed before must still get to
    // the affiliate link.
    if ( 202 === $code || 409 === $code || 1008 === $gr_code ) {
        return Affiliate_Theme_Theme_success_response( $settings );
    }

    error_log( sprintf( 'Affiliate Theme: GetResponse returned HTTP %d. Body: %s', $code, wp_remote_retrieve_body( $response ) ) );

    if ( 401 === $code ) {
        error_log( 'Affiliate Theme: check the GetResponse API key in Settings > Affiliate Theme Settings.' );

        return new WP_REST_Response(
            array(
                'ok'      => false,
                'message' => $generic,
            ),
            400
        );
    }

    if ( 429 === $code ) {
        return new WP_REST_Response(
            array(
                'ok'      => false,
                'message' => 'Please try again in a moment.',
            ),
            400
        );
    }

    return new WP_REST_Response(
        array(
            'ok'      => false,
            'message' => $generic,
        ),
        400
    );
}

/**
 * Make the success reply, with the redirect when there is one.
 *
 * @param array $settings The theme settings.
 * @return WP_REST_Response
 */
function Affiliate_Theme_Theme_success_response( $settings ) {
    $payload = array(
        'ok'      => true,
        'message' => $settings['success_message'],
    );

    if ( '' !== $settings['redirect_url'] && wp_http_validate_url( $settings['redirect_url'] ) ) {
        $payload['redirect'] = $settings['redirect_url'];
    }

    return new WP_REST_Response( $payload, 200 );
}

/* -------------------------------------------------------------------------
 * The landing patterns
 *
 * One function makes the markup. The pattern files echo it and the
 * activation seeder copies it. Thus the two can never disagree.
 * ---------------------------------------------------------------------- */

/**
 * Give the list of landing pages that the theme makes.
 *
 * @return array
 */
function Affiliate_Theme_Theme_landing_pages() {
    return array(
        1 => array(
            'slug'  => 'landing-1',
            'title' => 'Landing Page — Centered',
        ),
        2 => array(
            'slug'  => 'landing-2',
            'title' => 'Landing Page — Split',
        ),
        3 => array(
            'slug'  => 'landing-3',
            'title' => 'Landing Page — Long Form',
        ),
    );
}

/**
 * Make the block markup of one landing page.
 *
 * The markup uses real values for the spacing and the colors. Pattern
 * markup is copied into post_content at activation and frozen there, so a
 * preset redefined in a later theme version could never reach it. Real
 * values cannot be invalidated that way. Theme files use presets;
 * frozen content uses real values.
 *
 * @param int $index The landing page number, 1 to 3.
 * @return string
 */
function Affiliate_Theme_Theme_landing_pattern( $index ) {
    $form = '<!-- wp:affiliate-theme/optin-form {"lock":{"move":false,"remove":false}} /-->';

    switch ( (int) $index ) {
        case 2:
            return Affiliate_Theme_Theme_landing_pattern_split( $form );

        case 3:
            return Affiliate_Theme_Theme_landing_pattern_long( $form );

        default:
            return Affiliate_Theme_Theme_landing_pattern_centered( $form );
    }
}

/**
 * The fine print under the form in every landing pattern.
 *
 * An earnings disclaimer and an affiliate-commission disclosure, in a group
 * with a muted text color. The color is a real value, not a preset, because
 * this markup is frozen into post_content with the rest of the pattern.
 *
 * @param string $color The literal text color, chosen for the band behind it.
 * @return string
 */
function Affiliate_Theme_Theme_landing_fineprint( $color ) {
    return <<<MARKUP
<!-- wp:group {"style":{"color":{"text":"{$color}"},"spacing":{"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group has-text-color" style="color:{$color}"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">Results vary. There is no guarantee that you will earn any money. Your results depend on your own effort, skill and circumstances.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">When you buy through our links, the seller may pay us a commission. It adds nothing to what you pay.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
MARKUP;
}

/**
 * Landing page 1. A centered hero above a benefit list.
 *
 * @param string $form The opt-in form block markup.
 * @return string
 */
function Affiliate_Theme_Theme_landing_pattern_centered( $form ) {
    $fineprint = Affiliate_Theme_Theme_landing_fineprint( '#9aa3b5' );

    return <<<MARKUP
<!-- wp:group {"style":{"spacing":{"padding":{"top":"6rem","right":"1.5rem","bottom":"6rem","left":"1.5rem"}},"color":{"text":"#f5f7fb","background":"#0b1220"}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group has-text-color has-background" style="color:#f5f7fb;background-color:#0b1220;padding-top:6rem;padding-right:1.5rem;padding-bottom:6rem;padding-left:1.5rem"><!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.875rem"}}} -->
<p class="has-text-align-center" style="font-size:0.875rem">FREE INSTANT ACCESS</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"3rem"}}} -->
<h1 class="wp-block-heading has-text-align-center" style="font-size:3rem">The Simple System That Puts Commissions On Autopilot</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.25rem"}}} -->
<p class="has-text-align-center" style="font-size:1.25rem">Enter your best email below and I will send you the exact steps I use to promote offers and get paid — no list, no product, and no experience needed.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"templateLock":"insert","style":{"spacing":{"padding":{"top":"1rem","right":"0rem","bottom":"0rem","left":"0rem"}}},"layout":{"type":"constrained","contentSize":"420px"}} -->
<div class="wp-block-group" style="padding-top:1rem;padding-right:0rem;padding-bottom:0rem;padding-left:0rem">{$form}</div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">We respect your privacy. Unsubscribe at any time.</p>
<!-- /wp:paragraph -->

{$fineprint}</div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"4.5rem","right":"1.5rem","bottom":"4.5rem","left":"1.5rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group" style="padding-top:4.5rem;padding-right:1.5rem;padding-bottom:4.5rem;padding-left:1.5rem"><!-- wp:heading {"textAlign":"center","level":2,"style":{"typography":{"fontSize":"1.875rem"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:1.875rem">Here Is What You Get</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>The one-page plan that turns traffic into commissions.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The offers that pay the most for the least work.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The first email to send, word for word.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The mistake that costs new affiliates their first 90 days.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->
MARKUP;
}

/**
 * Landing page 2. Copy at the left, a form card at the right.
 *
 * @param string $form The opt-in form block markup.
 * @return string
 */
function Affiliate_Theme_Theme_landing_pattern_split( $form ) {
    $fineprint = Affiliate_Theme_Theme_landing_fineprint( '#5b6577' );

    return <<<MARKUP
<!-- wp:group {"style":{"spacing":{"padding":{"top":"5rem","right":"1.5rem","bottom":"5rem","left":"1.5rem"}},"color":{"text":"#111827","background":"#f4f6fb"}},"layout":{"type":"constrained","contentSize":"1100px"}} -->
<div class="wp-block-group has-text-color has-background" style="color:#111827;background-color:#f4f6fb;padding-top:5rem;padding-right:1.5rem;padding-bottom:5rem;padding-left:1.5rem"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"55%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:55%"><!-- wp:paragraph {"style":{"typography":{"fontSize":"0.875rem"}}} -->
<p style="font-size:0.875rem">FREE 5-DAY EMAIL COURSE</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"style":{"typography":{"fontSize":"2.75rem"}}} -->
<h1 class="wp-block-heading" style="font-size:2.75rem">Get Your First Affiliate Commission In The Next 30 Days</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"1.125rem"}}} -->
<p style="font-size:1.125rem">One short email each day. Each one gives you a single step to do. By day five you have a live offer, a page that captures leads, and traffic on the way to it.</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Day 1 — Pick the offer that pays.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Day 2 — Put your page up.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Day 3 — Write the email that sells.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Day 4 — Send your first traffic.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Day 5 — Do it again, and again.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"45%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:45%"><!-- wp:group {"templateLock":"insert","style":{"spacing":{"padding":{"top":"2.25rem","right":"2rem","bottom":"2.25rem","left":"2rem"}},"color":{"text":"#111827","background":"#ffffff"}},"layout":{"type":"constrained","contentSize":"360px"}} -->
<div class="wp-block-group has-text-color has-background" style="color:#111827;background-color:#ffffff;padding-top:2.25rem;padding-right:2rem;padding-bottom:2.25rem;padding-left:2rem"><!-- wp:heading {"textAlign":"center","level":2,"style":{"typography":{"fontSize":"1.375rem"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:1.375rem">Start Day 1 Now</h2>
<!-- /wp:heading -->

{$form}

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">No spam. Unsubscribe at any time.</p>
<!-- /wp:paragraph -->

{$fineprint}</div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
MARKUP;
}

/**
 * Landing page 3. A long sales page with the form at the top and the bottom.
 *
 * @param string $form The opt-in form block markup.
 * @return string
 */
function Affiliate_Theme_Theme_landing_pattern_long( $form ) {
    $fineprint = Affiliate_Theme_Theme_landing_fineprint( '#9aa3b5' );

    return <<<MARKUP
<!-- wp:group {"style":{"spacing":{"padding":{"top":"4.5rem","right":"1.5rem","bottom":"3rem","left":"1.5rem"}}},"layout":{"type":"constrained","contentSize":"720px"}} -->
<div class="wp-block-group" style="padding-top:4.5rem;padding-right:1.5rem;padding-bottom:3rem;padding-left:1.5rem"><!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"2.75rem"}}} -->
<h1 class="wp-block-heading has-text-align-center" style="font-size:2.75rem">Read This Before You Promote One More Offer</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.25rem"}}} -->
<p class="has-text-align-center" style="font-size:1.25rem">Most affiliates send traffic straight to a sales page, and they never see that visitor again. Here is what to do instead.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"templateLock":"insert","style":{"spacing":{"padding":{"top":"1.5rem","right":"0rem","bottom":"0rem","left":"0rem"}}},"layout":{"type":"constrained","contentSize":"420px"}} -->
<div class="wp-block-group" style="padding-top:1.5rem;padding-right:0rem;padding-bottom:0rem;padding-left:0rem">{$form}</div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","right":"1.5rem","bottom":"3rem","left":"1.5rem"}}},"layout":{"type":"constrained","contentSize":"680px"}} -->
<div class="wp-block-group" style="padding-top:3rem;padding-right:1.5rem;padding-bottom:3rem;padding-left:1.5rem"><!-- wp:heading {"level":2,"style":{"typography":{"fontSize":"1.875rem"}}} -->
<h2 class="wp-block-heading" style="font-size:1.875rem">The Traffic Is Not The Problem</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"1.0625rem"}}} -->
<p style="font-size:1.0625rem">You can buy clicks. You can post all day. But if the visitor leaves without giving you an email address, you paid for one look at your offer and nothing more.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"1.0625rem"}}} -->
<p style="font-size:1.0625rem">The affiliates who make real money keep the lead first. They send the offer second, then a third time, then a fourth. The same click is worth many times more.</p>
<!-- /wp:paragraph -->

<!-- wp:separator {"className":"is-style-wide"} -->
<hr class="wp-block-separator has-alpha-channel-opacity is-style-wide"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":2,"style":{"typography":{"fontSize":"1.875rem"}}} -->
<h2 class="wp-block-heading" style="font-size:1.875rem">What Is In The Guide</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>How to choose an offer that pays you again each month.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The page layout that turns traffic into subscribers.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>The seven emails that do the selling for you.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Where to get your first 100 clicks for very little money.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>How to read your numbers, so you know what to do next.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"4.5rem","right":"1.5rem","bottom":"4.5rem","left":"1.5rem"}},"color":{"text":"#f5f7fb","background":"#0b1220"}},"layout":{"type":"constrained","contentSize":"560px"}} -->
<div class="wp-block-group has-text-color has-background" style="color:#f5f7fb;background-color:#0b1220;padding-top:4.5rem;padding-right:1.5rem;padding-bottom:4.5rem;padding-left:1.5rem"><!-- wp:heading {"textAlign":"center","level":2,"style":{"typography":{"fontSize":"2rem"}}} -->
<h2 class="wp-block-heading has-text-align-center" style="font-size:2rem">Send Me The Guide</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.0625rem"}}} -->
<p class="has-text-align-center" style="font-size:1.0625rem">Enter your best email address. The guide arrives in the next few minutes.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"templateLock":"insert","style":{"spacing":{"padding":{"top":"1rem","right":"0rem","bottom":"0rem","left":"0rem"}}},"layout":{"type":"constrained","contentSize":"420px"}} -->
<div class="wp-block-group" style="padding-top:1rem;padding-right:0rem;padding-bottom:0rem;padding-left:0rem">{$form}</div>
<!-- /wp:group -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"0.8125rem"}}} -->
<p class="has-text-align-center" style="font-size:0.8125rem">We respect your privacy. Unsubscribe at any time.</p>
<!-- /wp:paragraph -->

{$fineprint}</div>
<!-- /wp:group -->
MARKUP;
}

/**
 * Add the pattern category that the pattern files use.
 *
 * @return void
 */
function Affiliate_Theme_Theme_register_pattern_category() {
    register_block_pattern_category(
        'affiliate-theme',
        array( 'label' => 'Affiliate Theme' )
    );
}
add_action( 'init', 'Affiliate_Theme_Theme_register_pattern_category', 8 );

/* -------------------------------------------------------------------------
 * Section e — the activation seeder
 * ---------------------------------------------------------------------- */

/**
 * Make one seeded page as a draft.
 *
 * Both halves of the seeder share this. An existing page at the slug is
 * taken as it is, never copied, and its content is left alone.
 *
 * @param string $slug     The page slug.
 * @param string $title    The page title.
 * @param string $content  The block markup for a page that does not exist yet.
 * @param string $template A page template to stamp, or an empty string for none.
 * @return int The page ID, or 0.
 */
function Affiliate_Theme_Theme_seed_page( $slug, $title, $content, $template = '' ) {
    $existing = get_page_by_path( $slug, OBJECT, 'page' );

    if ( $existing instanceof WP_Post ) {
        // Take the page that is there. Never make a copy of it.
        $page_id = $existing->ID;
    } else {
        $page_id = wp_insert_post(
            array(
                'post_type'    => 'page',
                'post_status'  => 'draft',
                'post_title'   => $title,
                'post_name'    => $slug,
                'post_content' => wp_slash( $content ),
            )
        );
    }

    if ( is_wp_error( $page_id ) || ! $page_id ) {
        return 0;
    }

    if ( '' !== $template ) {
        update_post_meta( $page_id, '_wp_page_template', $template );
    }

    return (int) $page_id;
}

/**
 * Make the landing pages and the legal pages one time, when the buyer
 * activates the theme.
 *
 * The routine is idempotent. The hook runs at every theme switch.
 *
 * This is the one hooked seeder. Both sets of pages share
 * AFFILIATE_THEME_SEED_FLAG, so a second hooked handler would race this
 * one: whichever ran first would set the flag and the other would return
 * early, silently seeding nothing. Affiliate_Theme_Theme_seed_legal_pages()
 * is therefore called from here and never hooked.
 *
 * @return void
 */
function Affiliate_Theme_Theme_seed_pages() {
    if ( get_option( AFFILIATE_THEME_SEED_FLAG ) ) {
        return;
    }

    $settings = Affiliate_Theme_Theme_get_settings();
    $page_ids = array();

    foreach ( Affiliate_Theme_Theme_landing_pages() as $index => $page ) {
        $page_id = Affiliate_Theme_Theme_seed_page(
            $page['slug'],
            $page['title'],
            Affiliate_Theme_Theme_landing_pattern( $index ),
            'page-blank'
        );

        if ( $page_id ) {
            $page_ids[] = $page_id;
        }
    }

    $settings['page_ids'] = $page_ids;

    // The legal pages take no page template, which leaves them on page.html.
    $settings['legal_page_ids'] = Affiliate_Theme_Theme_seed_legal_pages();

    update_option( AFFILIATE_THEME_OPTION, $settings );
    update_option( AFFILIATE_THEME_SEED_FLAG, 1 );
}
add_action( 'after_switch_theme', 'Affiliate_Theme_Theme_seed_pages' );

/* -------------------------------------------------------------------------
 * The opt-in block
 * ---------------------------------------------------------------------- */

/**
 * Register the block scripts and then the block.
 *
 * The scripts must have their handles before register_block_type() runs,
 * because block.json names the handles.
 *
 * @return void
 */
function Affiliate_Theme_Theme_register_optin_block() {
    wp_register_script(
        'affiliate-theme-optin-editor',
        get_theme_file_uri( '/blocks/optin-form/index.js' ),
        array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render' ),
        AFFILIATE_THEME_VERSION,
        true
    );

    wp_register_script(
        'affiliate-theme-optin',
        get_theme_file_uri( '/assets/js/optin.js' ),
        array(),
        AFFILIATE_THEME_VERSION,
        true
    );

    register_block_type( get_theme_file_path( '/blocks/optin-form' ) );
}
add_action( 'init', 'Affiliate_Theme_Theme_register_optin_block' );
