<?php
/**
 * Title: Landing Page — Long Form
 * Slug: affiliate-theme/landing-3
 * Categories: affiliate-theme
 * Description: A long sales page with the opt-in form near the top and again at the bottom.
 * Keywords: landing, optin, sales
 * Inserter: true
 */

echo Affiliate_Theme_Theme_landing_pattern( 3 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Block markup.
