<?php
/**
 * Title: Landing Page — Centered
 * Slug: affiliate-theme/landing-1
 * Categories: affiliate-theme
 * Description: A centered hero with the opt-in form under the headline, above a benefit list.
 * Keywords: landing, optin, hero
 * Inserter: true
 */

echo Affiliate_Theme_Theme_landing_pattern( 1 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Block markup.
