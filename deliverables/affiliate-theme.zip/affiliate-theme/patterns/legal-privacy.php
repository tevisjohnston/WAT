<?php
/**
 * Title: Legal — Privacy
 * Slug: affiliate-theme/legal-privacy
 * Categories: affiliate-theme
 * Description: A U.S. privacy policy covering what the funnel collects, the GetResponse processor, no sale or sharing, Global Privacy Control, Do Not Track, and the visitor's rights and appeals.
 * Keywords: legal, privacy, ccpa, gpc
 * Inserter: true
 */

echo Affiliate_Theme_Theme_legal_pattern( 'privacy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Block markup.
