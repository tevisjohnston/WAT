<?php
/**
 * Title: 404 — Back To Home
 * Slug: affiliate-theme/hidden-404-home
 * Inserter: no
 *
 * The home button of templates/404.html. A template file cannot run PHP, and
 * a literal href="/" misses a WordPress that lives in a folder, such as
 * example.com/blog/. This pattern prints the real home URL.
 *
 * @package affiliate-theme
 */

?>
<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( home_url( '/' ) ); ?>">Back to Home</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
