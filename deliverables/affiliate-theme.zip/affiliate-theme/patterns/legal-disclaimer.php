<?php
/**
 * Title: Legal — Earnings Disclaimer
 * Slug: affiliate-theme/legal-disclaimer
 * Categories: affiliate-theme
 * Description: An earnings disclaimer stating that there is no guarantee of income, that no typical result is claimed, and how testimonials are handled.
 * Keywords: legal, disclaimer, earnings, income
 * Inserter: true
 */

echo Affiliate_Theme_Theme_legal_pattern( 'disclaimer' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Block markup.
