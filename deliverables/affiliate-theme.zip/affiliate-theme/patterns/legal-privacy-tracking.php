<?php
/**
 * Title: Legal — Privacy: Analytics and Advertising
 * Slug: affiliate-theme/legal-privacy-tracking
 * Categories: affiliate-theme
 * Description: Insert this into the Privacy Policy page, after "Who We Share It With", when you add analytics or advertising pixels. Replace [PROVIDER NAME] with each provider you use and delete the "We Do Not Sell Or Share Your Information" section, which it replaces.
 * Keywords: legal, privacy, analytics, advertising, pixel, cookies, gpc
 * Inserter: true
 */

echo Affiliate_Theme_Theme_legal_pattern( 'privacy-tracking' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Block markup.
