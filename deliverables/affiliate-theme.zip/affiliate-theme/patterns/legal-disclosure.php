<?php
/**
 * Title: Legal — Affiliate Disclosure
 * Slug: affiliate-theme/legal-disclosure
 * Categories: affiliate-theme
 * Description: An FTC 16 CFR Part 255 affiliate disclosure covering commissions and other material connections, and where they are disclosed.
 * Keywords: legal, disclosure, affiliate, ftc
 * Inserter: true
 */

echo Affiliate_Theme_Theme_legal_pattern( 'disclosure' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Block markup.
