<?php
/**
 * Title: Legal — Terms of Service
 * Slug: affiliate-theme/legal-terms
 * Categories: affiliate-theme
 * Description: Terms covering acceptance, permitted use, third-party offers, warranty, a capped liability, informal dispute resolution and governing law. No arbitration clause.
 * Keywords: legal, terms, conditions
 * Inserter: true
 */

echo Affiliate_Theme_Theme_legal_pattern( 'terms' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Block markup.
