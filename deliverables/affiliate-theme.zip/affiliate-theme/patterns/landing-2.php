<?php
/**
 * Title: Landing Page — Split
 * Slug: affiliate-theme/landing-2
 * Categories: affiliate-theme
 * Description: Sales copy at the left and the opt-in form in a card at the right.
 * Keywords: landing, optin, columns
 * Inserter: true
 */

echo Affiliate_Theme_Theme_landing_pattern( 2 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Block markup.
