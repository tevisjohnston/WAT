<?php
/**
 * Affiliate Theme — the opt-in form, server render.
 *
 * WARNING: Never write the affiliate URL into this markup. The REST reply
 * carries it, so a person cannot read it without a form submission.
 *
 * @package affiliate-theme
 *
 * @var array    $attributes The block attributes.
 * @var string   $content    The block inner content.
 * @var WP_Block $block      The block instance.
 */

defined( 'ABSPATH' ) || exit;

$affiliate_theme_settings = Affiliate_Theme_Theme_get_settings();

// The theme has no key or no list. Tell an administrator. Show a visitor nothing.
if ( ! Affiliate_Theme_Theme_is_configured() ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    printf(
        '<div %1$s><p><strong>Opt-in form is not ready.</strong> Add your GetResponse API key and your list token in <a href="%2$s">Settings &rarr; Affiliate Theme Settings</a>. Only administrators see this note.</p></div>',
        get_block_wrapper_attributes( array( 'class' => 'affiliate-theme-optin affiliate-theme-optin--notice' ) ),
        esc_url( admin_url( 'options-general.php?page=affiliate-theme-settings' ) )
    );

    return;
}

$affiliate_theme_uid    = wp_unique_id( 'affiliate-theme-optin-' );
$affiliate_theme_button = ! empty( $attributes['buttonText'] ) ? $attributes['buttonText'] : 'Get Instant Access';
$affiliate_theme_email  = ! empty( $attributes['emailLabel'] ) ? $attributes['emailLabel'] : 'Email address';
$affiliate_theme_name   = ! empty( $attributes['nameLabel'] ) ? $attributes['nameLabel'] : 'First name';
$affiliate_theme_ask    = ! empty( $attributes['showNameField'] );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'affiliate-theme-optin' ) ); ?>>
	<form
		class="affiliate-theme-optin__form"
		method="post"
		novalidate
		data-affiliate-theme-optin
		data-endpoint="<?php echo esc_url( rest_url( AFFILIATE_THEME_REST_NS . '/subscribe' ) ); ?>"
		data-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
	>
		<?php if ( $affiliate_theme_ask ) : ?>
			<p class="affiliate-theme-optin__field">
				<label for="<?php echo esc_attr( $affiliate_theme_uid ); ?>-name"><?php echo esc_html( $affiliate_theme_name ); ?></label>
				<input
					type="text"
					id="<?php echo esc_attr( $affiliate_theme_uid ); ?>-name"
					name="name"
					autocomplete="given-name"
				/>
			</p>
		<?php endif; ?>

		<p class="affiliate-theme-optin__field">
			<label for="<?php echo esc_attr( $affiliate_theme_uid ); ?>-email"><?php echo esc_html( $affiliate_theme_email ); ?></label>
			<input
				type="email"
				id="<?php echo esc_attr( $affiliate_theme_uid ); ?>-email"
				name="email"
				autocomplete="email"
				required
			/>
		</p>

		<?php /* The honeypot. A person never sees it. A robot fills it in. */ ?>
		<p class="affiliate-theme-optin__hp" aria-hidden="true">
			<label for="<?php echo esc_attr( $affiliate_theme_uid ); ?>-website">Leave this field empty</label>
			<input
				type="text"
				id="<?php echo esc_attr( $affiliate_theme_uid ); ?>-website"
				name="website"
				tabindex="-1"
				autocomplete="off"
			/>
		</p>

		<p class="affiliate-theme-optin__submit">
			<button type="submit" class="affiliate-theme-optin__button"><?php echo esc_html( $affiliate_theme_button ); ?></button>
		</p>

		<p class="affiliate-theme-optin__status" role="status" aria-live="polite"></p>
	</form>
</div>
