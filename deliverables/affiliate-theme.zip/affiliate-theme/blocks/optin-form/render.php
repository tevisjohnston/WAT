<?php
/**
 * Affiliate Theme — the opt-in form, server render.
 *
 * WARNING: Never write the affiliate URL into this markup. The REST reply
 * carries it, so a person cannot read it without a form submission.
 *
 * WARNING: Never write a nonce into this markup either. WordPress answers
 * 403 to any REST request whose nonce has expired, before the route runs,
 * even for a visitor who is not logged in. A page cache serves old nonces,
 * so one would block every sign-up. A public sign-up route needs none.
 *
 * The form shows only while the emails it starts are live in Resend. Until
 * then a visitor sees nothing, and an administrator sees a note naming
 * what is missing above the form with its button turned off, which is also
 * the editor preview. Nothing here calls Resend.
 *
 * @package affiliate-theme
 *
 * @var array    $attributes The block attributes.
 * @var string   $content    The block inner content.
 * @var WP_Block $block      The block instance.
 */

defined( 'ABSPATH' ) || exit;

$affiliate_theme_index = Affiliate_Theme_Theme_optin_sequence(
    isset( $attributes['sequence'] ) ? $attributes['sequence'] : 'auto',
    isset( $block->context['postId'] ) ? (int) $block->context['postId'] : (int) get_the_ID()
);

// In inc/affiliate-theme-resend.php.
$affiliate_theme_reason = Affiliate_Theme_Theme_optin_not_ready( $affiliate_theme_index );
$affiliate_theme_ready  = '' === $affiliate_theme_reason;

if ( ! $affiliate_theme_ready && ! current_user_can( 'manage_options' ) ) {
    return;
}

$affiliate_theme_uid    = wp_unique_id( 'affiliate-theme-optin-' );
$affiliate_theme_button = ! empty( $attributes['buttonText'] ) ? $attributes['buttonText'] : 'Get Instant Access';
$affiliate_theme_email  = ! empty( $attributes['emailLabel'] ) ? $attributes['emailLabel'] : 'Email address';
$affiliate_theme_name   = ! empty( $attributes['nameLabel'] ) ? $attributes['nameLabel'] : 'First name';
$affiliate_theme_ask    = ! empty( $attributes['showNameField'] );
?>
<div <?php echo get_block_wrapper_attributes( array( 'class' => 'affiliate-theme-optin' ) ); ?>>
	<?php if ( ! $affiliate_theme_ready ) : ?>
		<p class="affiliate-theme-optin__notice"><strong>Opt-in form is not ready:</strong> <?php echo esc_html( $affiliate_theme_reason ); ?>. Open <a href="<?php echo esc_url( admin_url( 'options-general.php?page=affiliate-theme-settings#affiliate-theme-sequences' ) ); ?>">Affiliate Theme Settings</a>. Only administrators see this note.</p>
	<?php endif; ?>
	<form
		class="affiliate-theme-optin__form"
		method="post"
		novalidate
		data-affiliate-theme-optin
		<?php if ( $affiliate_theme_ready ) : ?>
		data-endpoint="<?php echo esc_url( rest_url( AFFILIATE_THEME_REST_NS . '/subscribe' ) ); ?>"
		data-sequence="<?php echo (int) $affiliate_theme_index; ?>"
		<?php endif; ?>
	>
		<?php if ( $affiliate_theme_ask ) : ?>
			<p class="affiliate-theme-optin__field">
				<label for="<?php echo esc_attr( $affiliate_theme_uid ); ?>-name"><?php echo esc_html( $affiliate_theme_name ); ?></label>
				<input
					type="text"
					id="<?php echo esc_attr( $affiliate_theme_uid ); ?>-name"
					name="name"
					autocomplete="given-name"
				/>
			</p>
		<?php endif; ?>

		<p class="affiliate-theme-optin__field">
			<label for="<?php echo esc_attr( $affiliate_theme_uid ); ?>-email"><?php echo esc_html( $affiliate_theme_email ); ?></label>
			<input
				type="email"
				id="<?php echo esc_attr( $affiliate_theme_uid ); ?>-email"
				name="email"
				autocomplete="email"
				required
			/>
		</p>

		<?php /* The honeypot. A person never sees it. A robot fills it in. */ ?>
		<p class="affiliate-theme-optin__hp" aria-hidden="true">
			<label for="<?php echo esc_attr( $affiliate_theme_uid ); ?>-website">Leave this field empty</label>
			<input
				type="text"
				id="<?php echo esc_attr( $affiliate_theme_uid ); ?>-website"
				name="website"
				tabindex="-1"
				autocomplete="off"
			/>
		</p>

		<p class="affiliate-theme-optin__submit">
			<button type="submit" class="affiliate-theme-optin__button"<?php echo $affiliate_theme_ready ? '' : ' disabled'; ?>><?php echo esc_html( $affiliate_theme_button ); ?></button>
		</p>

		<p class="affiliate-theme-optin__status" role="status" aria-live="polite"></p>
	</form>
	<?php if ( $affiliate_theme_ready && Affiliate_Theme_Theme_is_editor_render() ) : ?>
		<?php /* In the editor only, so the buyer sees which emails "This page's emails" picked. In inc/affiliate-theme-legal.php. */ ?>
		<p class="affiliate-theme-optin__hint">Sign-ups here start the <?php echo esc_html( Affiliate_Theme_Theme_sequence_label( $affiliate_theme_index ) ); ?> emails.</p>
	<?php endif; ?>
</div>
