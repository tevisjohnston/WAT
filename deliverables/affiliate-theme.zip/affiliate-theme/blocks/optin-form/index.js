/**
 * Affiliate Theme — the opt-in form block, editor side.
 *
 * This file is plain JavaScript. It uses no JSX and needs no build step.
 * The edit function shows a server render, so the buyer sees the real form
 * with the real settings.
 */
( function ( blocks, element, blockEditor, components, serverSideRender ) {
	'use strict';

	var el = element.createElement;
	var useBlockProps = blockEditor.useBlockProps;
	var InspectorControls = blockEditor.InspectorControls;
	var ServerSideRender = serverSideRender;

	blocks.registerBlockType( 'affiliate-theme/optin-form', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;

			function update( key ) {
				return function ( value ) {
					var next = {};
					next[ key ] = value;
					setAttributes( next );
				};
			}

			var panel = el(
				InspectorControls,
				null,
				el(
					components.PanelBody,
					{ title: 'Form', initialOpen: true },
					el( components.TextControl, {
						label: 'Button text',
						value: attributes.buttonText,
						onChange: update( 'buttonText' ),
						__nextHasNoMarginBottom: true
					} ),
					el( components.TextControl, {
						label: 'Email field label',
						value: attributes.emailLabel,
						onChange: update( 'emailLabel' ),
						__nextHasNoMarginBottom: true
					} ),
					el( components.ToggleControl, {
						label: 'Ask for a first name',
						checked: attributes.showNameField,
						onChange: update( 'showNameField' ),
						__nextHasNoMarginBottom: true
					} ),
					attributes.showNameField
						? el( components.TextControl, {
								label: 'Name field label',
								value: attributes.nameLabel,
								onChange: update( 'nameLabel' ),
								__nextHasNoMarginBottom: true
						  } )
						: null
				)
			);

			var preview = el( ServerSideRender, {
				block: 'affiliate-theme/optin-form',
				attributes: attributes
			} );

			return el( 'div', useBlockProps(), panel, preview );
		},

		// The block is server rendered. Nothing goes into post_content.
		save: function () {
			return null;
		}
	} );
} )(
	window.wp.blocks,
	window.wp.element,
	window.wp.blockEditor,
	window.wp.components,
	window.wp.serverSideRender
);
