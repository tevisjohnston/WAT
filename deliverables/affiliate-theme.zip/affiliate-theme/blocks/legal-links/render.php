<?php
/**
 * Affiliate Theme — the legal links, server render.
 *
 * The block is server rendered so that publishing a legal page updates
 * every place the block appears, frozen landing post_content included.
 * A draft page is never linked.
 *
 * @package affiliate-theme
 *
 * @var array    $attributes The block attributes.
 * @var string   $content    The block inner content.
 * @var WP_Block $block      The block instance.
 */

defined( 'ABSPATH' ) || exit;

$affiliate_theme_links = Affiliate_Theme_Theme_legal_links();

// No legal page is published. Show a visitor nothing at all, so that an
// unpublished set leaves no empty strip on a landing page.
if ( empty( $affiliate_theme_links ) ) {
    if ( ! Affiliate_Theme_Theme_is_editor_render() ) {
        return;
    }

    printf(
        '<div %1$s><p>Your legal pages are still drafts. Publish them and their links appear here. Only the editor shows this note.</p></div>',
        get_block_wrapper_attributes( array( 'class' => 'affiliate-theme-legal-links affiliate-theme-legal-links--notice' ) )
    );

    return;
}
?>
<nav <?php echo get_block_wrapper_attributes( array( 'class' => 'affiliate-theme-legal-links' ) ); ?> aria-label="Legal">
	<?php
	$affiliate_theme_first = true;

	foreach ( $affiliate_theme_links as $affiliate_theme_link ) {
		if ( ! $affiliate_theme_first ) {
			echo '<span class="affiliate-theme-legal-links__sep" aria-hidden="true">&middot;</span>';
		}

		printf(
			'<a class="affiliate-theme-legal-links__link" href="%1$s">%2$s</a>',
			esc_url( $affiliate_theme_link['url'] ),
			esc_html( $affiliate_theme_link['title'] )
		);

		$affiliate_theme_first = false;
	}
	?>
</nav>
