/**
 * Affiliate Theme — the legal links block, editor side.
 *
 * Plain JavaScript. No JSX and no build step. The edit function shows a
 * server render, so the buyer sees exactly which pages are published.
 */
( function ( blocks, element, blockEditor, components, serverSideRender ) {
	'use strict';

	var el = element.createElement;
	var useBlockProps = blockEditor.useBlockProps;
	var ServerSideRender = serverSideRender;

	blocks.registerBlockType( 'affiliate-theme/legal-links', {
		edit: function ( props ) {
			// The preview holds live links. Disabled makes it inert, so a
			// click selects the block. Without it, a click followed the link
			// and loaded the page into the editor canvas.
			return el(
				'div',
				useBlockProps(),
				el(
					components.Disabled,
					null,
					el( ServerSideRender, {
						block: 'affiliate-theme/legal-links',
						attributes: props.attributes
					} )
				)
			);
		},

		// The block is server rendered. Nothing goes into post_content.
		save: function () {
			return null;
		}
	} );
} )(
	window.wp.blocks,
	window.wp.element,
	window.wp.blockEditor,
	window.wp.components,
	window.wp.serverSideRender
);
