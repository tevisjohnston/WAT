/**
 * Affiliate Theme — the legal links block, editor side.
 *
 * Plain JavaScript. No JSX and no build step. The edit function shows a
 * server render, so the buyer sees exactly which pages are published.
 */
( function ( blocks, element, blockEditor, serverSideRender ) {
	'use strict';

	var el = element.createElement;
	var useBlockProps = blockEditor.useBlockProps;
	var ServerSideRender = serverSideRender;

	blocks.registerBlockType( 'affiliate-theme/legal-links', {
		edit: function ( props ) {
			return el(
				'div',
				useBlockProps(),
				el( ServerSideRender, {
					block: 'affiliate-theme/legal-links',
					attributes: props.attributes
				} )
			);
		},

		// The block is server rendered. Nothing goes into post_content.
		save: function () {
			return null;
		}
	} );
} )(
	window.wp.blocks,
	window.wp.element,
	window.wp.blockEditor,
	window.wp.serverSideRender
);
